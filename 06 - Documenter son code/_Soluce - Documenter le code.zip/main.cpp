//------------------------------------------------------------------------------
/** @file		main.cpp
* @brief		Calcul du montant dela dernière échéance d'un prêt à taux 0.
*
* @author		Ch. Cruzol
* @author		STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since		2016/11/21
* @version	1.0
* @date		2016/11/21
*
* Andy Fikulté a emprunté à Guy Mauve une somme de 2 500 € (prêt sans intérêts).
* Pour rembourser son ami, il prévoit de lui remettre110 € par mois. Mais comme cela ne
* correspond pas à un nombre pile-poil de mois, il se demande quel sera le montant à rembourser le
* dernier mois.
*
*/
//------------------------------------------------------------------------------

#include <iostream>
using namespace std ;

/** Programme principal réalisant le traitement du calcul de la dernière échéance.<br/>
* Pour cela, on utilise une boucle REPETER JUSQU'À qui va décrémenter la somme restant à régler jusqu'à ce
* que cette somme soit inférieure (ou égale… au cas où…) à la somme rendue chaque mois.<br/>
* À ce moment là, on sait que l'on a réalisé des remboursemments complets durant un certain nombre de mois
* pleins, et qu'il en reste un dernier dont le rembourssement sera plus léger.<br/>
* Finalement, le montant de la dernière échéance est affiché.
*
* @pre				Pas de précondition requise.
* @post			La dernière échéance est calculée et affichée.
*
* @param			Ce main() n'utilise aucun paramètre.
*
* @return			Le programme principal retourne automatiquement, et obligatoirement, la valeur 0 à la console
*						d'appel pour lui spécifier que sont traitement c'est bien passé.
*/
int main()
{
	float		fEmprunt					(0.0) ;	//	Somme totale empruntée.
	float		fRemboursemment	(0.0) ;	//	Montant du remboursemment mensuel.
	float		fSommeAPayer			(0.0) ;	//	tenir à jour le montant total restant à payer.
	float		fDerniereEcheance		(0.0) ;	//	Montant de la dernière échéance.
	int			nNbreMois					(0) ;		//	Compteur de la durée du rembourssement en mois.

	fEmprunt					= 2500.0 ;
	fRemboursemment	= 110.0 ;
	fSommeAPayer			= fEmprunt ;

	do
	{
		nNbreMois++ ;
		fSommeAPayer	= fSommeAPayer - fRemboursemment ;
	}
	while(!( fSommeAPayer <= fRemboursemment )) ;
	nNbreMois++ ;
	fDerniereEcheance = fSommeAPayer ;

	cout << "La derniere echeance sera de " << fDerniereEcheance << " euros, au cours du " ;
	cout << nNbreMois << "eme mois." << endl ;

	return 0 ;
}
