//------------------------------------------------------------------------------
/** @file         MaClasse.cpp
 *  @brief        Description rapide du fichier MaClasse.cpp
 *
 *  @author       Moi, moi et encore moi
 *  @author       SII Lycee Nicolas APPERT, ORVAULT (FRANCE)
 *  @since        2002-09-01
 *  @version      0.1
 *  @date         2002-09-23
 *
 *  Description d�taill�e du fichier MaClasse.cpp
 *
 *  Fabrication   C++ Builder v4.0, projet   .BPR
 *
 *  @todo         Liste des choses restant � faire.
 *  @todo         Liste des choses restant � faire.
 *
 *  @bug          2002-09-21 - Premier essai d'homog�n�isation du codage
 *  @bug          2002-09-23 - Second essai d'homog�n�isation du codage
 */
//------------------------------------------------------------------------------
#ifndef _MA_CLASSE_CPP
#define _MA_CLASSE_CPP
// En-t�tes standards (ATTENTION : garder toujours le meme ordre) --------------
#include <iostream>
using namespace std ;

// En-t�te propre � l'application ----------------------------------------------


// En-t�te propre � l'objet ----------------------------------------------------
#include "MaClasse.H"


/** Description d�taill�e des CONSTRUCTEURs
 *  @pre    Description des pr�conditions n�cessaires � la m�thode
 *  @post   Description des postconditions n�cessaires � la m�thode
 *  @param  Y'a pas
 *  @retval Valeurs de retour
 *  @return  Y'a pas
 *  @test   Voir la proc�dure dans le fichier associ�.
 *  @see    afficherAttributs
 */
MaClasse::MaClasse()
{

}

/** Description d�taill�e des DESTRUCTEURs
 *  @pre    Description des pr�conditions n�cessaires � la m�thode
 *  @post   Description des postconditions n�cessaires � la m�thode
 *  @param  Y'a pas
 *  @retval Valeurs de retour
 *  @return  Y'a pas
 *  @test   Voir la proc�dure dans le fichier associ�.
 *  @see    afficherAttributs
 */
MaClasse::~MaClasse()
{

}

//---------------------------------------------------------------------------
// METHODEs PUBLIQUEs
//---------------------------------------------------------------------------

/** Description d�taill�e de la m�thode
 *  @pre    Description des pr�conditions n�cessaires � la m�thode
 *  @post   Description des postconditions n�cessaires � la m�thode
 *  @param  Y'a pas
 *  @retval Valeurs de retour
 *  @return Y'a pas
 *  @test   Voir la proc�dure dans le fichier associ�.
 *  @see    afficherAttributs
 */
void MaClasse::initAttributs()
{

/** @brief Essai de commentaire interne des m�thodes
 */

 cout << m_Attribut_Structure.nToto ;

}

/** Affichage des valeurs des attributs de l?objet
 *  @pre        L?objet est cr�� et ses attributs correctement initialis�s
 *  @post       Les valeurs des attributs sont affich�es sur la console
 *  @param[in]  sNomObjet   Le nom de variable, au format texte, de l?objet concern�
 *  @test       Voir la proc�dure de test dans la [fiche associ�e](../Fiches/AfficherAttributs.pdf).
 *  @see        InitialiserAttributs
 */
void MaClasse::AfficherAttributs(char * sNomObjet)
{
    // Contenu de la m�thode
}


//---------------------------------------------------------------------------
// METHODEs PROTEGEEs
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
// METHODEs PRIVEEs
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
#endif  // _MA_CLASSE_CPP
//---------------------------------------------------------------------------

