#include	<iostream>
#include	<time.h>
#include    "Tab1D_Dynamique.h"

using namespace std ;

unsigned int * CreerTab1D(unsigned int nTaille)
{
    unsigned int *  pTab    (nullptr) ;

    pTab = new unsigned int [nTaille] ;

    InitTab1D(pTab, nTaille) ;

    return pTab ;
}

bool LibererTab1D(unsigned int * pTab, unsigned int nTaille)
{
    bool    bRetour (false) ;
    if(pTab != nullptr)
    {
        InitTab1D(pTab, nTaille) ;
        delete [] pTab ;
        pTab = nullptr ;
        bRetour = true ;
    }

    return  bRetour ;
}

void InitTab1D(unsigned int pTab[], unsigned int nTaille, unsigned int nInit)
{
    for (unsigned int i = 0; i < nTaille; i++)
    {
        pTab[i] = nInit ;
    }
}

void AfficherTab1D(unsigned int pTab[], unsigned int nTaille)
{
    for (unsigned int i = 0; i < nTaille; i++)
    {
        cout << "pTab[" << i << "] = " << pTab[i] << endl ;
    }
}

void AcquerirTab1D(unsigned int pTab[], unsigned int nTaille)
{
    int nMax    (1000) ;
    int nMin    (100) ;

	srand(2023) ;
    //srand(time(nullptr)) ;
    for (unsigned int i = 0; i < nTaille; i++)
    {
        pTab[i] = (rand()%(nMax-nMin)) + nMin;
    }
}

void TrierTab1D(unsigned int pTab[], unsigned int nTaille)
{
    bool            bPermutation    (false) ;
    unsigned int    nTemporaire     (0) ;
    // Tri à bulle
    /*  On doit parcourir tout le tableau à la recherche de permutation potentielles
        jusqu'à ce qu'aucune permutation n'ait été faite : le tableau est trié !
    */
    do
    {
        // Il n'y a pas encore eu de permutation pour le parcours qui débute.
        bPermutation = false ;
        for(unsigned int i = 0; i <= (nTaille - 2); i++)
        {
            // Chaque élément i du tableau est-il supérieur à son suivant i+1 ?
            if(pTab[i] > pTab[i + 1])
            {
                /*  Dans ce cas, on permute les deux valeurs, au moyen d'une
                    variable temporaire…
                */
                nTemporaire		= pTab[i] ;
                pTab[i]		= pTab[i + 1] ;
                pTab[i + 1]	= nTemporaire ;
                /*  Une permutation a été faite… on le mémorise !
                    Remarque : même si on avait déjà permuter précédement durant
                    ce parcours, on le mémorise à nouveau… Ici, on pourrait même
                    compter le nombre de permutations faites !
                */
                bPermutation	= true ;
            }
        }
    }
    while(!(bPermutation == false)) ;
}

unsigned int    TrouverMedianeTab1D(unsigned int pTab[], unsigned int nTaille)
{
    unsigned int    nMediane    (0) ;
    unsigned int    nMilieu     (0) ;

    nMilieu = nTaille / 2 ;

    if (nTaille%2 == 0)
    {
        // Nbre d'acquisition pair : la médiane est la moyenne des deux valeurs
        // du milieu !
        nMediane = (pTab[nMilieu-1] + pTab[nMilieu]) / 2.0 ;

    }
    else
    {
        // Nbre d'acquisition impair : la médiane est la valeur du milieu !
        nMediane = pTab[nMilieu] ;
    }


    return  nMediane ;
}
