#ifndef TAB1D_DYNAMIQUE_H
#define TAB1D_DYNAMIQUE_H

unsigned int *  CreerTab1D          (unsigned int nTaille) ;

bool            LibererTab1D        (unsigned int * pTab,
                                     unsigned int nTaille) ;

void            InitTab1D           (unsigned int pTab[],
                                     unsigned int nTaille,
                                     unsigned int nInit = 0) ;

void            AfficherTab1D       (unsigned int pTab[],
                                     unsigned int nTaille) ;

void            AcquerirTab1D       (unsigned int pTab[],
                                     unsigned int nTaille) ;

void            TrierTab1D          (unsigned int pTab[],
                                     unsigned int nTaille) ;

unsigned int    TrouverMedianeTab1D  (unsigned int pTab[],
                                      unsigned int nTaille) ;
#endif // TAB1D_DYNAMIQUE_H
