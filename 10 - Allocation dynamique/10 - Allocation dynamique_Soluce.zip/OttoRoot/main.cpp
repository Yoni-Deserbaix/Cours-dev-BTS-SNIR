#include	<iostream>
#include    "Tab1D_Dynamique.h"

using namespace std ;


int main()
{
    unsigned int *  pTabOtto            (nullptr) ;
    unsigned int    nNbreAcquisition    (0) ;
    unsigned int    nMediane            (0) ;
//    unsigned int    nDuree              (5) ;
//    unsigned int    nPeriode            (11) ;

    unsigned int    nDuree              (0) ;
    unsigned int    nPeriode            (0) ;

    cout << "Donnez la duree totale de l'acquisition : " ;
    do
    {
        cin >> nDuree ;
    } while(!(  (1 <= nDuree) && (nDuree <= 48) )) ;
    cout << "Donnez la periode de l'acquisition : " ;
    do
    {
        cin >> nPeriode ;
    } while(!(  (1 <= nPeriode) && (nPeriode <= 15) )) ;

    nNbreAcquisition = (nDuree * 60) / nPeriode ;
    cout    << "Des acquisitions durant " << nDuree
			<< " heure(s) a la periode de " << nPeriode
            << " fournirront " << nNbreAcquisition << " donnees." << endl ;

    pTabOtto = CreerTab1D(nNbreAcquisition) ;
    AcquerirTab1D(pTabOtto, nNbreAcquisition) ;
    cout << "Le tableau initial : " << endl ;
    AfficherTab1D(pTabOtto, nNbreAcquisition) ;

    TrierTab1D(pTabOtto, nNbreAcquisition) ;
    cout << "Le tableau trie : " << endl ;
    AfficherTab1D(pTabOtto, nNbreAcquisition) ;

    nMediane = TrouverMedianeTab1D(pTabOtto, nNbreAcquisition) ;
    cout << "La valeur mediane des acquisitions est " << nMediane << endl ;

    if (LibererTab1D(pTabOtto, nNbreAcquisition))
    {
        cout << "Super ! Le tableau a bien ete des-alloue ! Bravo !" << endl;
    }
    else
    {
        cout << "Arrggg ! Le tableau n'a pu etre des-alloue ! Too bad !" << endl;
    }
    return 0 ;
}
