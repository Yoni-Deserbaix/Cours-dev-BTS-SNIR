// TCercle.h      1.0       2019-10-04      Ch. Cruzol
#if !defined(_TCERCLE_H)
#define _TCERCLE_H

#include "TForme.h"
#include "TPoint.h"

class TCercle : public TForme
{
public :
    TCercle() ;
    TCercle(const TCercle & oCercleACopier) ;
    TCercle(TPoint oCentre, double fRayon) ;
    ~TCercle() ;

    TCercle &   operator =(const TCercle & oCercleACopier) ;

    double  Get_fRayon() ;
    void    Set_fRayon(double fRayon) ;
    double  Get_Perimetre() ;
    double  Get_Aire() ;

	friend ostream & operator <<(ostream & oFluxDeSortie, const TCercle & oCercle) ;

private:
    double fRayon ;
};

#endif  //_TCERCLE_H
