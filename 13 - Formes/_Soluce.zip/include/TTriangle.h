// TTriangle.h      1.0       2019-10-04      Ch. Cruzol
#if !defined(_TTRIANGLE_H)
#define _TTRIANGLE_H

#include "TForme.h"

class TTriangle : public TForme
{
public :
    TTriangle() ;
    TTriangle(const TTriangle & oTriangleACopier) ;
    TTriangle(TPoint oS1, TPoint oS2, TPoint oS3) ;
    ~TTriangle() ;
    TTriangle & operator =(const TTriangle & oTriangleACopier) ;

    double Get_Perimetre() ;
    double Get_Aire() ;

	friend ostream & operator <<(ostream & oFluxDeSortie, const TTriangle & oTriangle) ;

} ;

#endif  //_TTRIANGLE_H
