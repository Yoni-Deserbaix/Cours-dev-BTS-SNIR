// TQuadri.h      1.0       2019-10-04      Ch. Cruzol
#if !defined(_TQUADRI_H)
#define _TQUADRI_H

#include "TForme.h"

class TQuadri : public TForme
{
public :
    TQuadri() ;
    TQuadri(const TQuadri & oQuadriACopier) ;
    ~TQuadri() ;
    TQuadri & operator =(const TQuadri & oQuadriACopier) ;

    double Get_Perimetre() ;
    double Get_Aire() ;

	friend ostream & operator <<(ostream & oFluxDeSortie, const TQuadri & oQuadri) ;

};

#endif  //_TQUADRI_H
