// TPoint.h      1.0       2019-10-04      Ch. Cruzol


#if !defined(_TPOINT_H)
#define _TPOINT_H

#include <iostream>
using namespace std ;

class TPoint
{
public:
    // COPLIEN
    TPoint() ;
    TPoint(const TPoint &oPointARecopier) ;
    ~TPoint() ;
    TPoint & operator=(const TPoint & oPointARecopier) ;

    TPoint(double fX, double fY) ;

    // Affichage
    void Afficher() ;
    friend ostream & operator <<(ostream & oFluxDeSortie, const TPoint & oPoint) ;

    // Accesseurs
    void Get_XY(double &fX, double &fY) ;
    void Set_XY(double fX, double fY) ;

    // Méthodes de métier
	double CalculerDistance(TPoint oPoint) ;
    TPoint Ajouter(TPoint oPoint) ;

private:
    double  fX ;
    double  fY ;
};

#endif  //_TPOINT_H
