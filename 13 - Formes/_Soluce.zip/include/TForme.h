// TForme.h      1.0       2019-10-04      Ch. Cruzol

#if !defined(_TFORME_H)
#define _TFORME_H

#include "TPoint.h"

class TForme
{
public :
        // COPLIEN
    TForme() ;
    TForme(const TForme & oFormeACopier) ;
    ~TForme() ;
    TForme &    operator =(TForme & oFormeACopier) ;

    TForme(int nNbreSommets) ;

    bool            Set_Point(int i, TPoint oPoint) ;
    TPoint &        Get_Point(int i) ;


    void            Afficher() ;
    friend ostream & operator <<(ostream & oFluxDeSortie, const TForme & oPoint) ;

    // Méthodes virtuelles pures

    /// Cette métode doit calculer le périmètre de la forme géométrique,
    /// ce qui diffère selon le type de forme :
    /// on laisse donc les filles la définir correctement !
    virtual double  Get_Perimetre() = 0 ;

    /// Cette métode doit calculer la surface de la forme géométrique,
    /// ce qui diffère selon le type de forme :
    /// on laisse donc les filles la définir correctement !
    virtual double  Get_Aire()      = 0 ;


    int             Get_nNbreSommets() ;
    void            Translater(TPoint oPoint) ;

protected :
    int         nNbreSommets ;
    TPoint *    pSommets ;
};

#endif  //_TFORME_H
