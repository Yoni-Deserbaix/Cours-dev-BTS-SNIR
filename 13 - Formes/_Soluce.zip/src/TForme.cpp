//------------------------------------------------------------------------------
/** @file       TForme.cpp
 * @brief        Définition d'une forme géométrique.
 *
 * @author       Ch. Cruzol
 * @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
 * @since        2019-10-04
 * @version      1.0
 * @date         2019-10-04
 *
 * Une forme géométrique, de façon globale, est définie par un certain nombre
 * de points représentants ses sommets ! Un attribut permet de mémoriser le
 * nombre total de sommets et un tableau, créé dynamiquement, stocke les points,
 * de façon ordonnée, en parcourant le périmètre.
 *
 * Fabrication   Formes.pro
 *
 */
//------------------------------------------------------------------------------


#include "TForme.h"
#include "TPoint.h"

/** Constructeur par défaut, obligatoire pour la forme canonique de Coplien, qui
 * va initialiser tous les attributs avec des valeurs cohérentes.
 * Par défaut, une forme aura trois sommets, qui ont tous les coordonnées
 * (0.0 ; 0.0) !
*/
TForme::TForme() :
    nNbreSommets    (3) ,
	pSommets        (nullptr)
{
    this->pSommets = new TPoint [this->nNbreSommets] ;
}

/** Constructeur de recopie, obligatoire pour la forme canonique de Coplien, qui
 * va initialiser tous les attributs avec les valeurs de l'objet passé en
 * paramètre.
 * Cette méthode est requise dés qu'un passage de paramètre par valeur doit être
 * effectué pour un objet de cette classe.
 * De même, ce constructeur est utilisé lors de l'ajout d'un objet de cette classe
 * dans un contener quelconque de la STL.
 * Si l'objet à recopier ne possède pas de sommet, un triangle est créé, mais
 * ses trois sommets sont confondus aux coordonnées (0.0 ; 0.0).
 *
 * @param[in]   oFormeACopier Objet de même classe dont les valeurs sont à
 *              copier dans nos propres attributs.
*/
TForme::TForme(const TForme & oFormeACopier) :
    nNbreSommets    (0) ,
	pSommets        (nullptr)
{
    if(oFormeACopier.nNbreSommets >= 1)
    {
        this->nNbreSommets = oFormeACopier.nNbreSommets ;
        this->pSommets = new TPoint [this->nNbreSommets] ;
        for(int i = 0 ; i < this->nNbreSommets ; i++)
        {
            this->pSommets[i] = oFormeACopier.pSommets[i] ;
        }
    }
    else
    {
        this->nNbreSommets = 3 ;
        this->pSommets = new TPoint [this->nNbreSommets] ;
    }
}

/** Constructeur paramétré, qui va initialiser tous les attributs grâce aux
 *  valeurs passées en paramètres.
 * Si le nombre de sommets est inférieur à 1, un triangle est créé.
 * Lors de la création, Tous les sommets ont des coordonnées (0.0 ; 0.0) !
 *
 * param [in]       nNbreSommets    nombre de sommets que doit avoir la forme.
 *                  Le tableau des sommets est créé de cette taille.
 *
 * @see     Set_Point
*/
TForme::TForme(int nNbreSommets) :
	nNbreSommets    (nNbreSommets) ,
	pSommets        (nullptr)
{
	if(nNbreSommets < 1)
	{
		this->nNbreSommets = 3 ;
	}
	this->pSommets = new TPoint [this->nNbreSommets] ;
}

/** Destructeur, obligatoirement rempli pour se conformer à la forme canonique
 * de coplien. Il réinitialise tous les attributs à des valeurs par défaut, et
 * libère les zones mémoires allouées dynamiquement au besoin (ici, c'est bien
 * le cas !)
*/
TForme::~TForme()
{
	if (this->pSommets != nullptr)
    {
        delete [] this->pSommets ;
		this->pSommets = nullptr ;
    }
    this->nNbreSommets = 0 ;
}

/** Opérateur de recopie, obligatoire pour la forme canonique de coplien.
 * Il permet de libérer les zones mémoires allouée dynamiquement au préalable,
 * d'en recréer de nouvelles plus adaptées, et finalement de recopier les valeurs
 * des attributs de l'objet (de même type) passé en paramètre dans ses propres
 * attributs.
 *
 * @param[in]   oFormeACopier Objet de même classe dont les valeurs sont à
 *              copier dans nos propres attributs.
 *
 * @note        Ne pas oublier de retourner la référence de l'objet !
*/
TForme & TForme::operator =(TForme & oFormeACopier)
{
    if( this != &oFormeACopier )
	{
		// Même code que le destructeur !
		if (this->pSommets != nullptr)
		{
			delete [] this->pSommets ;
			this->pSommets = nullptr ;
		}
		this->nNbreSommets = 0 ;


		// Même code que le constructeur de recopie !
		if(oFormeACopier.nNbreSommets >= 1)
		{
			this->nNbreSommets = oFormeACopier.nNbreSommets ;
			this->pSommets = new TPoint [this->nNbreSommets] ;
			for(int i = 0 ; i < this->nNbreSommets ; i++)
			{
				this->pSommets[i] = oFormeACopier.pSommets[i] ;
			}
		}
		else
		{
			this->nNbreSommets = 3 ;
			this->pSommets = new TPoint [this->nNbreSommets] ;
		}
	}
	
    return *this ;
}


/** Méthode d'affichage de l'adresse de l'objet et des valeurs tous ses
 * attributs.
*/
void TForme::Afficher()
{
    cout << "Cette forme possede " << this->nNbreSommets << " sommets." << endl ;
    for(int i = 0 ; i < this->nNbreSommets ; i++)
    {
        cout << "\t\t" ;
        this->pSommets[i].Afficher() ;
    }
}

/** Surcharge de l'opérateur << du flux de sortie standard (cout).
 *  Il permet l'affichage de l'adresse de l'objet et des valeurs tous ses
 *  attributs de façon classique en utilisant la ligne de code :<br/>
 *  <code>cout << oMaForme << endl ;</code>
*/
ostream & operator <<(ostream & oFluxDeSortie, const TForme & oPoint)
{
    oFluxDeSortie << "Cette forme possede " << oPoint.nNbreSommets << " sommets." << endl ;
    for(int i = 0 ; i < oPoint.nNbreSommets ; i++)
    {
        oFluxDeSortie << "\t\t" ;
        oFluxDeSortie << oPoint.pSommets[i] ;
    }
    return oFluxDeSortie ;
}


/** Accesseur d'écriture, qui permet d'initialiser les coordonnées du sommet,
 * correspondant au rang indiqué par le paramètre i, avec celles du oPoint donné
 * en paramètre.
 * Si l'indice n'a pas une valeur valide, les coordonnées du sommet concerné ne
 * peuvent, forcément, pas être modifiées !
 *
 * @param [in]  i Rang du point à modifier, par rapport au parcours du périmètre.
 *              Le point de départ aura le rang 1. Il s'agit ici, de le placer
 *              dans tableau contenant tous les sommets à la case correspondante
 *              à i-1 !
 * @param [in]  oPoint Contient les coordoonées qui doivent être appliquée au
 *              sommet correspondant au rang i.
 * @return      True si les coordonnées du sommet ont été effectivement
 *              modifiées. False sinon !
 */
bool TForme::Set_Point(int i, TPoint oPoint)
{
    bool    bRetour (false) ;
    if ((i >= 1) && (i <= this->nNbreSommets))
    {
        this->pSommets[i-1] = oPoint ;
        bRetour = true ;
    }
    return bRetour ;
}

/** Accesseur de lecture d'un sommet.
 * Retourne les coordonnées du sommet dont le rang est indiqué par le
 * paramètre i.
 * Si le rang du somment n'est pas valide, les coordonnées (0.0, 0.0) sont
 * retournées.
 *
 * @note        Le retour s'effectue par référence, en passant par un pointeur
 *              de façon à récupérer la vraie référence de la case du tableau,
 *              et non celle de la variable locale, qui sera détruite en fin de
 *              cette méthode. Une autre possibilité, aurait été de déclarer
 *              une variable locale en static de façon à ce qu'elle reste en
 *              mémoire tout au long de l'exécution du programme !
 *
 * @param[in]   i Rang du point à récupérer, par rapport au parcours du
 *              périmètre. Le point de départ aura le rang 1. Il s'agit ici,
 *              de l'indice+1 du tableau contenant tous les sommets.
 *
 * @return       La référence <b>directe</b> au sommet contenu dans le tableau
 *               des sommets.
*/
TPoint & TForme::Get_Point(int i)
{
	TPoint * oPointARetourner (nullptr) ;
    TPoint  oPointVide ;

    if ((i >= 1) && (i <= this->nNbreSommets))
    {
        oPointARetourner = &(this->pSommets[i-1]) ;
    }
    else
    {
        oPointARetourner = &oPointVide ;
    }
    return *oPointARetourner ;
}

/** Accesseur de lecture du nombre total de sommets.
*
* @return       Le nombre total de sommets que possède la forme géométrique.
*/
int TForme::Get_nNbreSommets()
{
    return this->nNbreSommets ;
}

/** Déplace la forme sur le plan cartésien selon les coordonnées indiquées en
 * paramètre. Chaque sommet est affecté par la même translation : la forme est
 * déplacée, pas déformée !
 *
 * @param[in]    oPoint Fourni les coordonnées permettant de réaliser la
 *               translation.
 *
 * @see          TPoint::Ajouter
*/
void TForme::Translater(TPoint oPoint)
{
    for(int i = 0 ; i < this->nNbreSommets ; i++)
    {
        this->pSommets[i].Ajouter(oPoint) ;
    }
}


