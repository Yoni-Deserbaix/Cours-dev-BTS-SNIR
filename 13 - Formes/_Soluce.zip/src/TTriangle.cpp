//------------------------------------------------------------------------------
/** @file       TTriangle.cpp
 * @brief        Définition d'un triangle
 *
 * @author       Ch. Cruzol
 * @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
 * @since        2019-10-04
 * @version      1.0
 * @date         2019-10-04
 *
 * Un triangle est défini par trois sommets !
 *
 * Fabrication   Formes.pro
 *
 */
//------------------------------------------------------------------------------


#include    <iostream>
#include    <math.h>
#include    "TTriangle.h"
#include    "TPoint.h"

using namespace std ;


/** Constructeur par défaut, obligatoire pour la forme canonique de Coplien, qui
 * va initialiser tous les attributs avec des valeurs cohérentes.
 * Obligatoirement, un triangle est une forme géométrique ayant exactement trois
 * sommets, qui ont tous, au départ, les coordonnées (0.0 ; 0.0) !
*/
TTriangle::TTriangle():
    TForme(3)
{

}

/** Constructeur de recopie, obligatoire pour la forme canonique de Coplien, qui
 * va initialiser tous les attributs avec les valeurs de l'objet passé en
 * paramètre.
 * Cette méthode est requise dès qu'un passage de paramètre par valeur doit être
 * effectué pour un objet de cette classe.
 * De même, ce constructeur est utilisé lors de l'ajout d'un objet de cette classe
 * dans un contener quelconque de la STL.
 *
 * @param[in]   oTriangleACopier Objet de même classe dont les valeurs sont à
 *              copier dans nos propres attributs. Il n'est pas besoin, ici,
 *              de tester la validité du nomnbre de sommet du paramètre : c'est
 *              aussi un triangle et il a été construit correctement !
*/
TTriangle::TTriangle(const TTriangle & oTriangleACopier):
	TForme(3)
{
    for(int i = 0 ; i < this->nNbreSommets ; i++)
    {
        this->Set_Point(i+1, oTriangleACopier.pSommets[i]) ;
    }
}


/** Constructeur paramétré, qui va initialiser tous les attributs grâce aux
 *  valeurs passées en paramètres.
 * Le triangle comporte trois sommets dont il faut initialiser les coordonnées.
 * Celles-ci sont données par les trois paramètres.
 *
 * @param [in]      oS1 Contient les coordonnées du premier sommet (rang 0 dans
 *                  le tableau).
 * @param [in]      oS2 Contient les coordonnées du second sommet (rang 1 dans
 *                  le tableau).
 * @param [in]      oS3 Contient les coordonnées du troisième sommet (rang 2
 *                  dans le tableau).
 *
 * @see     Set_Point
*/
TTriangle::TTriangle(TPoint oS1, TPoint oS2, TPoint oS3):
    TForme(3)
{
    this->Set_Point(1, oS1) ;
    this->Set_Point(2, oS2) ;
    this->Set_Point(3, oS3) ;
}

/** Destructeur, obligatoirement rempli pour se conformer à la forme canonique
 * de coplien. Il réinitialise tous les attributs à des valeurs par défaut, et
 * libère les zones mémoires allouées dynamiquement au besoin.
 * Ici, la classe Triangle n'a pas d'attributs propres à réinitialiser !
 * Le destructeur est donc laissé vide. Mais il ne faut pas oublier que le
 * destructeur est automatiquement appelé : c'est lui qui fait tout le boulot
 * sur le nombre de sommets et le tableau de sommets !
*/
TTriangle::~TTriangle()
{
}

/** Opérateur de recopie, obligatoire pour la forme canonique de coplien.
 * Il permet de libérer les zones mémoires allouée dynamiquement au préalable,
 * d'en recréer de nouvelles plus adaptées, et finalement de recopier les valeurs
 * des attributs de l'objet (de même type) passé en paramètre dans ses propres
 * attributs.
 * Comme, ici, l'objet à copier possède aussi trois sommets, notre tableau
 * interne a la bonne dimension : il n'est pas nécessaire de le détruire pour
 * le recrée de la même taille !
 * Il en va de même pour le nombre de sommets, que nous ne mettons pas à jour.
 * Seules les coordonnées des points sont ajustées !
 *
 * @param[in]   oTriangleACopier Objet de même classe dont les valeurs sont à
 *              copier dans nos propres attributs.
 *
 * @note        Ne pas oublier de retourner la référence de l'objet !
*/
TTriangle & TTriangle::operator =(const TTriangle & oTriangleACopier)
{
    if( this != &oTriangleACopier )
	{
		for(int i = 0 ; i < this->nNbreSommets ; i++)
		{
			this->Set_Point(i+1, oTriangleACopier.pSommets[i]) ;
		}
	}
	//this->TForme::operator = (oTriangleACopier) ;
    return *this ;
}

/** Calcul de la longueur totale du périmètre du triangle.
 * Pour cela, on doit mesurer la distance entre le premier sommet et le second…
 * celle entre le second et le troisième et enfin entre le troisième et le
 * premier. La somme de ces distances forme le périmètre !
 *
 * @return       La longueur totale du périmètre du triangle.
 *
*/
double TTriangle::Get_Perimetre()
{
    double  fPerimetre  (0.0) ;
    int     j           (0) ;

    for(int i = 0 ; i < this->nNbreSommets ; i++)
    {
        if (i < this->nNbreSommets-1)
        {
            j = i+1 ;
        }
        else
        {
            j = 0 ;
        }
		fPerimetre += this->pSommets[i].CalculerDistance(this->pSommets[j]) ;
    }

    return fPerimetre ;
}

/** Calcul de la surface totale du triangle en utilisant la formule de Héron.
 * Pour cela, on doit mesurer la longueur de chaque côté et connaître le
 * périmètre !
 *
 * @return       La surface totale du triangle.
 *
 * @see         TPoin::CalculerDistance, Get_Perimetre
*/
double TTriangle::Get_Aire()
{
    double  fDemiPerimetre  (0.0) ;
    double  fA              (0.0) ;
    double  fB              (0.0) ;
    double  fC              (0.0) ;
    double  fAire           (0.0) ;

    fDemiPerimetre  = this->Get_Perimetre()/2.0 ;
	fA              = this->pSommets[0].CalculerDistance(this->pSommets[1]) ;
	fB              = this->pSommets[1].CalculerDistance(this->pSommets[2]) ;
	fC              = this->pSommets[2].CalculerDistance(this->pSommets[0]) ;
    fAire           = sqrt(     fDemiPerimetre
                             *  (fDemiPerimetre-fA)
                             *  (fDemiPerimetre-fB)
                             *  (fDemiPerimetre-fC)  ) ;

    return fAire ;
}

/** Surcharge de l'opérateur << du flux de sortie standard (cout).
 *  Il permet l'affichage de l'adresse de l'objet et des valeurs tous ses
 *  attributs de façon classique en utilisant la ligne de code :<br/>
 *  <code>cout << oMonTriangle << endl ;</code>
 *
 * @note    La méthode Afficher n'a pas été surchargée dans la fille : il est
 *          plus Pro d'utiliser un flux qu'une méthode pour ça ! Par contre,
 *          l'instruction <code>oMonTriangle.Afficher()</code> fonctionne :
 *          c'est la méthode de la mère qui est appelée ! Elle ne permet
 *          d'afficher que les attributs liés à la mère… Le périmètre et l'aire
 *          ne le seront pas !
*/
ostream & operator <<(ostream & oFluxDeSortie, const TTriangle & oTriangle)
{
	oFluxDeSortie << "Le triangle (" << &oTriangle << ") a " ;
	oFluxDeSortie<< const_cast<TTriangle &>(oTriangle).Get_nNbreSommets() << " sommets :" << endl ;
	for(int i = 0 ; i < const_cast<TTriangle &>(oTriangle).Get_nNbreSommets() ; i++)
    {
		oFluxDeSortie << "\t\t" << const_cast<TTriangle &>(oTriangle).Get_Point(i+1) ;
    }
	oFluxDeSortie << "\t\tSon perimetre est " << const_cast<TTriangle &>(oTriangle).Get_Perimetre() << endl ;
	oFluxDeSortie << "\t\tSon aire est " << const_cast<TTriangle &>(oTriangle).Get_Aire() << endl ;
    return oFluxDeSortie ;
}

