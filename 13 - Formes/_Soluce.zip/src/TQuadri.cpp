//------------------------------------------------------------------------------
/** @file       TQuadri.cpp
 * @brief        Définition d'un quadrilatère
 *
 * @author       Ch. Cruzol
 * @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
 * @since        2019-10-04
 * @version      1.0
 * @date         2019-10-04
 *
 * Un quadrilatère est défini par quatre sommets !
 *
 * Fabrication   Formes.pro
 *
 * @note        Cette classe n'est pas commentée : voir la classe TTriangle !
 */
//------------------------------------------------------------------------------


#include "TQuadri.h"
#include "TTriangle.h"

TQuadri::TQuadri():
    TForme  (4)
{

}

TQuadri::TQuadri(const TQuadri & oQuadriACopier):
    TForme  (4)
{
    for(int i = 0 ; i < this->nNbreSommets ; i++)
    {
        this->Set_Point(i+1, oQuadriACopier.pSommets[i]) ;
    }
}

TQuadri::~TQuadri()
{

}

TQuadri & TQuadri::operator =(const TQuadri & oQuadriACopier)
{
    if( this != &oQuadriACopier )
	{
		for(int i = 0 ; i < this->nNbreSommets ; i++)
		{
			this->Set_Point(i+1, oQuadriACopier.pSommets[i]) ;
		}
	}
	
    return  *this ;
}


double TQuadri::Get_Perimetre()
{
    double  fPerimetre  (0.0) ;
    int     j           (0) ;

    for(int i = 0 ; i < this->nNbreSommets ; i++)
    {
        if (i < this->nNbreSommets-1)
        {
            j = i+1 ;
        }
        else
        {
            j = 0 ;
        }
		fPerimetre += this->pSommets[i].CalculerDistance(this->pSommets[j]) ;
    }

    return fPerimetre ;
}

double TQuadri::Get_Aire()
{
	/* Ici, on a besoin d'objets instance de TTriangle, d'où la liaison
	 * agregation du diagramme de classe !
	 */
    TTriangle   oTriangle1  (this->Get_Point(1), this->Get_Point(2), this->Get_Point(4)) ;
    TTriangle   oTriangle2  (this->Get_Point(2), this->Get_Point(3), this->Get_Point(4)) ;

    double  fAire   (0.0) ;

    fAire = oTriangle1.Get_Aire() ;
    fAire += oTriangle2.Get_Aire() ;

    return fAire ;
}


ostream & operator <<(ostream & oFluxDeSortie, const TQuadri & oQuadri)
{
	oFluxDeSortie << "Le quadrilataire (" << &oQuadri << ") a " ;
	oFluxDeSortie << const_cast<TQuadri &>(oQuadri).Get_nNbreSommets() << " sommets :" << endl ;
	for(int i = 0 ; i < const_cast<TQuadri &>(oQuadri).Get_nNbreSommets() ; i++)
    {
		oFluxDeSortie << "\t\t" << const_cast<TQuadri &>(oQuadri).Get_Point(i+1) ;
    }
	oFluxDeSortie << "\t\tSon perimetre est " << const_cast<TQuadri &>(oQuadri).Get_Perimetre() << endl ;
	oFluxDeSortie << "\t\tSon aire est " << const_cast<TQuadri &>(oQuadri).Get_Aire() << endl ;
    return oFluxDeSortie ;
}
