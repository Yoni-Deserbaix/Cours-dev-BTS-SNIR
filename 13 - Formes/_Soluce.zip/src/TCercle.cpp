//------------------------------------------------------------------------------
/** @file       TCercle.cpp
 * @brief        Définition d'un cercle.
 *
 * @author       Ch. Cruzol
 * @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
 * @since        2019-10-04
 * @version      1.0
 * @date         2019-10-04
 *
 * Un cercle est défini par un point qui est le centre et un rayon !
 *
 * Fabrication   Formes.pro
 *
 * @note        Cette classe n'est pas commentée : voir la classe TTriangle !
 */
//------------------------------------------------------------------------------


#include <math.h>
#include <iostream>
#include "TCercle.h"

using namespace std ;


TCercle::TCercle():
    TForme  (1),
    fRayon  (0.0)
{
}

TCercle::TCercle(const TCercle & oCercleACopier):
    TForme(1),
    fRayon  (0.0)
{
    this->Set_Point(1, oCercleACopier.pSommets[0]) ;
    this->fRayon = oCercleACopier.fRayon ;
}

TCercle::TCercle(TPoint oCentre, double fRayon):
    TForme(1),
    fRayon  (0.0)
{
    this->Set_Point(1, oCentre) ;
    if (fRayon < 0)
    {
        fRayon = -fRayon ;
    }
    this->fRayon = fRayon ;

}

TCercle::~TCercle()
{
    fRayon  = 0.0 ;
}

TCercle & TCercle::operator =(const TCercle & oCercleACopier)
{
    if( this != &oCercleACopier )
	{
		this->Set_Point(1, oCercleACopier.pSommets[0]) ;
		this->fRayon = oCercleACopier.fRayon ;
	}
	
    return *this ;
}

double TCercle::Get_fRayon()
{
    return  this->fRayon ;
}

void TCercle::Set_fRayon(double fRayon)
{
    if (fRayon < 0)
    {
        fRayon = -fRayon ;
    }
    this->fRayon = fRayon ;
}

double TCercle::Get_Perimetre()
{
    // PI est défini dans maths.h par la constante symbolique M_PI
    double  fPerimetre  (0.0) ;

    fPerimetre  = 2.0*M_PI*this->fRayon ;

    return  fPerimetre ;
}

double TCercle::Get_Aire()
{
	double  fAire   (0.0) ;
	// Dans le cas où PI n'est pas défini dans maths.h, on peut le déclarer :
	double  PI      (0.0) ;
	PI = atan(1.0)*4;

    fAire   = PI*this->fRayon*this->fRayon ;

    return  fAire ;
}

ostream & operator <<(ostream & oFluxDeSortie, const TCercle & oCercle)
{
	oFluxDeSortie << "Le cercle (" << &oCercle << ") a un rayon de " ;
	oFluxDeSortie << const_cast<TCercle &>(oCercle).Get_fRayon() ;
    oFluxDeSortie << " et son centre :" << endl ;
	oFluxDeSortie << "\t\t" << const_cast<TCercle &>(oCercle).Get_Point(1) ;
	oFluxDeSortie << "\t\tSon perimetre est " << const_cast<TCercle &>(oCercle).Get_Perimetre() << endl ;
	oFluxDeSortie << "\t\tSon aire est " << const_cast<TCercle &>(oCercle).Get_Aire() << endl ;

    return oFluxDeSortie ;
}
