//------------------------------------------------------------------------------
/** @file       TPoint.cpp
 * @brief        Définition d'un point repéré dans un plan cartésien
 *
 * @author       Ch. Cruzol
 * @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
 * @since        2019-10-04
 * @version      1.0
 * @date         2019-10-04
 *
 * Un point est défini par deux coordonnées, X et Y !
 *
 * Fabrication   Formes.pro
 *
 */
//------------------------------------------------------------------------------



#include <iostream>
#include <math.h>
using namespace std ;

#include "TPoint.h"
/** Constructeur par défaut, obligatoire pour la forme canonique de Coplien, qui
 * va initialiser tous les attributs avec des valeurs cohérentes.
*/
TPoint::TPoint() :
    fX  (0.0) ,
    fY  (0.0)
{

}

/** Constructeur de recopie, obligatoire pour la forme canonique de Coplien, qui
 * va initialiser tous les attributs avec les valeurs de l'objet passé en
 * paramètre.
 * Cette méthode est requise dés qu'un passage de paramètre par valeur doit être
 * effectué pour un objet de cette classe.
 * De même, ce constructeur est utilisé lors de l'ajout d'un objet de cette classe
 * dans un contener quelconque de la STL.
 *
 * @param[in]   oPointARecopier Objet de même classe dont les valeurs sont à
 *              copier dans nos propres attributs.
*/
TPoint::TPoint(const TPoint & oPointARecopier) :
    fX  (oPointARecopier.fX) ,
    fY  (oPointARecopier.fY)
{
}

/** Constructeur paramétré, qui va initialiser tous les attributs avec des
 *  valeurs passées en paramètres.
*/
TPoint::TPoint(double fX, double fY) :
	fX  (fX) ,
	fY  (fY)
{

}

/** Destructeur, obligatoirement rempli pour se conformer à la forme canonique
 * de coplien. Il réinitialise tous les attributs à des valeurs par défaut, et
 * libère les zones mémoires allouées dynamiquement au besoin (ici, ce n'est
 * pas le cas !)
*/
TPoint::~TPoint()
{
    this->Set_XY(0.0, 0.0) ;
}

/** Opérateur de recopie, obligatoire pour la forme canonique de coplien.
 * Il permet de libérer les zones mémoires allouée dynamiquement au préalable,
 * d'en recréer de nouvelles plus adaptées (ces deux opérations sont inutiles
 * dans cette classe) et finalement de recopier les valeurs
 * des attributs de l'objet (de même type) passé en paramètre dans ses propres
 * attributs.
 *
 * @param[in]   oPointARecopier Objet de même classe dont les valeurs sont à
 *              copier dans nos propres attributs.
 *
 * @note        Ne pas oublier de retourner la référence de l'objet !
*/
TPoint & TPoint::operator =(const TPoint & oPointARecopier)
{
    if( this != &oPointARecopier )
	{
		this->Set_XY(oPointARecopier.fX, oPointARecopier.fY) ;
	}
	
    return *this ;
}

/** Méthode d'affichage de l'adresse de l'objet et des valeurs tous ses
 * attributs.
*/
void TPoint::Afficher()
{
    cout << "Le point (" << this << ") est aux coordonnees [ " << this->fX << " ; " << this->fY << " ]" << endl ;
}

/** Surcharge de l'opérateur << du flux de sortie standard (cout).
 *  Il permet l'affichage de l'adresse de l'objet et des valeurs tous ses
 *  attributs de façon classique en utilisant la ligne de code :<br/>
 *  <code>cout << oMonPoint << endl ;</code>
*/
ostream & operator<<(ostream & oFluxDeSortie, const TPoint & oPoint)
{
    oFluxDeSortie << "Le point (" << &oPoint << ") est aux coordonnees [ " << oPoint.fX << " ; " << oPoint.fY << " ]" << endl ;
    return oFluxDeSortie ;
}

/** Accesseurs de lecture des attributs de la classe
 */
void TPoint::Get_XY(double &fX, double &fY)
{
    fX = this->fX ;
    fY = this->fY ;
}

/** Mutateur d'écriture des attributs de la classe
 */
void TPoint::Set_XY(double fX, double fY)
{
    this->fX = fX ;
    this->fY = fY ;
}

/** Calcul de la distance entre le point courant (attributs fX et fY) et un
 *  autre point passé en paramètre. On utilise ici le théorème de Pythagore !
 *
 * @param[in]    oPoint fourni les coordonnées du point à partir duquel la
 *               distance doit être calculée.
 *
 * @return       La distance entre ce point et celui passé en paramètre.
*/
double TPoint::CalculerDistance(TPoint oPoint)
{
    double  fDistance   (0.0) ;

    fDistance = sqrt( (this->fX - oPoint.fX)*(this->fX - oPoint.fX)
                    + (this->fY - oPoint.fY)*(this->fY - oPoint.fY) ) ;

    return fDistance ;
}

/** Réalise la translation du point en fonction d'un autre point de référence.
 * Les deux coordonnées X s'ajoutent entre elles. Les deux coordonnées Y
 * s'ajoutent entre elles. Les coordonnées du point actuel sont modifiées.
 *
 * @param[in]    oPoint Fourni les coordonnées permettant de réaliser la
 *               translation.
 *
 * @return       Une copie de l'objet du point courant.
*/
TPoint TPoint::Ajouter(TPoint oPoint)
{
    this->fX += oPoint.fX ;
    this->fY += oPoint.fY ;

    return *this ;
}

