/** @file       main.cpp
* @brief        Programme de mise au point et de test des diverses formes créées.
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019-10-04
* @version      1.0
* @date         2019-10-04
*
* Fabrication   Formes.pro
*/
//------------------------------------------------------------------------------

#include <iostream>

using namespace std;

#include    "TPoint.h"
#include    "TForme.h"
#include    "TTriangle.h"
#include    "TCercle.h"
#include    "TQuadri.h"

int main()
{
    /*TPoint  oAutrePoint (10.0, -5.2) ;
    TPoint  oPoint ;
    double  fDistance   (0.0) ;

    oPoint.Afficher() ;
    cout << oPoint << endl ;
    cout << oAutrePoint << endl ;
    cout << "La distance entre les deux points est de " << oPoint.MesurerDistance(oAutrePoint) << endl ;

    oPoint.Ajouter(oAutrePoint) ;
    cout << oPoint << endl ;

    cout << "La distance entre les deux points est de " << oPoint.MesurerDistance(oAutrePoint) << endl ;

    */

    /*
    TForme  oForme ;
    oForme.Afficher() ;
    cout << oForme ;
    oForme.Set_Point(1, oAutrePoint) ;
    cout << oForme ;
    oForme.Translater(oAutrePoint) ;
    cout << oForme ;
    */


    TPoint      oS1         (0.0, 0.0) ;
    TPoint      oS2         (1.0, 1.0) ;
    TPoint      oS3         (0.0, 2.0) ;

    TTriangle   oTriangle   (oS1, oS2, oS3) ;
    TTriangle   oTriangle2   ;
    cout << oTriangle << endl ;

    cout << oTriangle.Get_Point(2) << endl ;

    oTriangle.Afficher() ;
/*    cout << oTriangle2 ;

    oTriangle2 = oTriangle ;

    cout << oTriangle2 ;
    cout << "Le perimetre du triangle 1 : " << oTriangle.Get_Perimetre() << endl ;
    cout << "L'aire du triangle 1 : " << oTriangle.Get_Aire() << endl ;
*/

/*
    TPoint  oCentre (2.0, 3.5) ;

    TCercle oCercle ;
    TCercle oCercle2    (oCentre, 8.0) ;

    cout << oCercle2 << endl ;

    oCercle = oCercle2 ;
    cout << "Le perimetre du cercle : " << oCercle.Get_Perimetre() << endl ;
    cout << "L'aire du cercle : " << oCercle.Get_Aire() << endl ;
*/

/*
    TQuadri     oQuadri ;
    TQuadri     oQuadri2 ;
    TPoint      oS1         (0.0, 0.0) ;
    TPoint      oS2         (1.0, 0.0) ;
    TPoint      oS3         (1.0, 1.0) ;
    TPoint      oS4         (0.0, 1.0) ;

    oQuadri.Set_Point(1, oS1) ;
    oQuadri.Set_Point(2, oS2) ;
    oQuadri.Set_Point(3, oS3) ;
    oQuadri.Set_Point(4, oS4) ;

    oQuadri2 = oQuadri ;

    cout << oQuadri << endl ;
    cout << oQuadri2 << endl ;
*/

    system("PAUSE") ;
    return 0;
}

