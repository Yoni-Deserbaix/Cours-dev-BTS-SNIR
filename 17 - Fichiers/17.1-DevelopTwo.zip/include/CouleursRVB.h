// CouleursRVB.h      1.0       2019-01-13      Ch. Cruzol

#ifndef COULEURSRVB_H
#define COULEURSRVB_H

// Constantes symboliques pour les couleurs utilisÃ©es
/** @def	NOIR
*  @brief	Codage RGB du noir 0x000000
*/
#define	NOIR	(0x000000)
/** @def	BLANC
*  @brief	Codage RGB du blanc 0xFFFFFF
*/
#define	BLANC	(0xFFFFFF)
/** @def	ROUGE
*  @brief	Codage RGB du rouge 0xFF0000
*/
#define	ROUGE	(0xFF0000)
/** @def	ORANGE
*  @brief	Codage RGB dde l'orange 0xFF7300
*/
#define	ORANGE	(0xFF7300)
/** @def	JAUNE
*  @brief	Codage RGB du jaune 0xFFFF00
*/
#define	JAUNE	(0xFFFF00)
/** @def	VERT
*  @brief	Codage RGB du vert 0x00FF00
*/
#define	VERT	(0x00FF00)
/** @def	BLEU
*  @brief	Codage RGB du bleu 0x0000FF
*/
#define	BLEU	(0x0000FF)
/** @def	INDIGO
*  @brief	Codage RGB de l'indigo 0x000071
*/
#define	INDIGO	(0x000071)
/** @def	MAGENTA
*  @brief	Codage RGB du magenta 0xFF0080
*/
#define	MAGENTA	(0xFF0080)


// Constantes symboliques pour l'affichage
/** @def	ETEINT
*  @brief	Symbole Ã  afficher si le spot est Ã©teint (de couleur NOIR)
*/
#define	ETEINT	(" ")
/** @def	ALLUME
*  @brief	Symbole Ã  afficher si le spot est allumÃ© (autre couleur que NOIR)
*/
#define	ALLUME	(".")


unsigned int	RVB				(unsigned int wR,
								 unsigned int wV,
								 unsigned int wB) ;

void			AfficherImage	(unsigned int * * tabLogo,
								  unsigned int wHauteur,
								  unsigned int wLargeur) ;



#endif // COULEURSRVB_H
