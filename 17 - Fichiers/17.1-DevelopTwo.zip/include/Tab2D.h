// Tab2D.h      1.0       2019-01-13      Ch. Cruzol
#ifndef TAB2D_H
#define TAB2D_H

unsigned int * *	CreerTab2D	(unsigned int wHauteur,
								 unsigned int wLargeur) ;

void AfficherTab2D	(unsigned int **wTab,
					 unsigned int wHauteur,
					 unsigned int wLargeur) ;

unsigned int * *	LibererTab2D	(unsigned int **wTab,
									 unsigned int wHauteur,
									 unsigned int wLargeur) ;

#endif // TAB2D_H
