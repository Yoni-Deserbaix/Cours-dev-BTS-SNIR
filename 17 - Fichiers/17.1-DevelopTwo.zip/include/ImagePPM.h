// ImagePPM.h      1.0       2019-01-13      Ch. Cruzol
#ifndef IMAGEPPM_H
#define IMAGEPPM_H


bool	EstPPM_RVB			(char * sNomImage) ;

void	LirePPM_Dimensions	(char * sNomImage,
							unsigned int & wHauteur,
							unsigned int & wLargeur) ;

bool	EstDeTaille			(char * sNomImage,
							unsigned int wHauteur,
							unsigned int wLargeur) ;

void	LireImagePPM		(char * sNomImage,
							  unsigned int * * wTab,
							  unsigned int wHauteur,
							  unsigned int wLargeur) ;


#endif // IMAGEPPM_H
