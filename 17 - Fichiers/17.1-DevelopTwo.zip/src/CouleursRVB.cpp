//------------------------------------------------------------------------------
/** @file       CouleursRVB.cpp
* @brief        Bibliothèque de gestion des couleurs au format RVB 8 bits
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019-01-13
* @version      1.0
* @date         2019-01-13
*
* Cette librairie offre des fonctionnalités simplifiant le traitement des
* couleurs des pixels, du moment où ils sont codés en RVB 8 bits, c'est à dire
* sur un entier de 32 bits, dont les trois octets de poids les plus faibles
* correspondent à la composante Rouge, Vert et Bleu de la couleur.
*
* Fabrication   DevelopTwo.pro
*/
//------------------------------------------------------------------------------

#include	<iostream>
#include	"CouleursRVB.h"
using namespace std ;

/** Cette fonction fait la synthèque de trois composantes de couleur de base,
*  le rouge, le vert et le bleu, pour obtenir une valeur RVB cohérente.
*
* @param[in]    wR valeur de la composante ROUGE. La valeur doit être comprise
*               entre 0 et 255 : seuls les 8 bits de poids faibles sont utilisés.
* @param[in]    wV valeur de la composante VERTE. La valeur doit être comprise
*               entre 0 et 255 : seuls les 8 bits de poids faibles sont utilisés.
* @param[in]    wB valeur de la composante BLEUE. La valeur doit être comprise
*               entre 0 et 255 : seuls les 8 bits de poids faibles sont utilisés.
*
* @return       wRvb la couleur 32 bits codée en RVB
*
* @see          <a href="https://fr.wikipedia.org/wiki/Codage_informatique_des_couleurs">https://fr.wikipedia.org/wiki/Codage_informatique_des_couleurs</a>
*/
unsigned int	RVB(unsigned int wR, unsigned int wV, unsigned int wB)
{
	unsigned int	wRvb	(0) ;

	wRvb = (wR & 0x000000FF) << 16 ;
	wRvb = wRvb | ((wV & 0x000000FF) << 8) ;
	wRvb = wRvb | (wB & 0x000000FF) ;

	return wRvb ;
}



/** Affichage d'une image dans la console texte.
*
* @param[in]    wTab tableau à deux dimensions contenant l'image, la couleur de
*               chaque pixel étant codée en RVB dans une des cases de ce tableau.
* @param[in]    wHauteur taille de la dimension correspondant à y de l'image.
*               Utilisé pour la première dimension du tableau <code>wTab</code>.
*               Représente les lignes !
* @param[in]    wLargeur taille de la dimension correspondant à x de l'image.
*               Utilisé pour la seconde dimension du tableau <code>wTab</code>.
*               Représente les colonnes !
*/
void AfficherImage(unsigned int * * wTab,
					  unsigned int wHauteur,
					  unsigned int wLargeur)
{
	if((wTab != NULL) && (wHauteur != 0) && (wLargeur != 0))
	{
		for(unsigned int y = 0 ; y < wHauteur ; y++)
		{
			for(unsigned int x = 0 ; x < wLargeur ; x++)
			{
				switch(wTab[y][x])
				{
					case NOIR		:	cout << ETEINT ;	break ;

					case BLANC		:	cout << "." ;		break ;
					case ROUGE		:	cout << "R" ;		break ;
					case ORANGE		:	cout << "O" ;		break ;
					case JAUNE		:	cout << "J" ;		break ;
					case VERT		:	cout << "V" ;		break ;
					case BLEU		:	cout << "B" ;		break ;
					case INDIGO		:	cout << "I" ;		break ;
					case MAGENTA	:	cout << "M" ;		break ;

					default			:	cout << ALLUME ;	break ;
				}
			}
			cout << endl ;
		}
	}
	else
	{
		cout << "Le tableau n'est pas alloue !" << endl ;
	}
}
