//------------------------------------------------------------------------------
/** @file       Tab2D.cpp
* @brief        Bibliothèque de gestion d'un tableau à deux dimensions.
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019-01-13
* @version      1.0
* @date         2019-01-13
*
* Librairie proposant de modules lociels de traitement d'un tableau à deux
* dimensions.<br/> Cela passe par la création dynamique du tableau et de sa
* dés-allocation de façon à laisser la mémoire dans un état correct.<br/>
* Forcément, l'incontournable affichage est disponible !
*
* Fabrication   DevelopTwo.pro
*/
//------------------------------------------------------------------------------

#include	<iostream>
#include	<mem.h>
#include "Tab2D.h"

using namespace std ;

/** Cette fonction est chargée de créer <b>dynamiquement</b> un tableau à deux
* dimensions, dont les tailles sont passées en paramètres.<br/> Elle commence
* par créer dynamiquement un tableau "vertical" qu'elle affecte à sa variable
* locale <code>wTab</code> ( double pointeur sur des entiers non signés).
* Puis dans chacune de ses cases,
* elle affecte un autre tableau "horizontal", créé lui-aussi dynamiquement !<br/>
* Une fois tout cela fait, elle initialise chaque case du tableau global avec la
* valeur 0<br/> En fin de traitement, elle retourne <code>wTab</code> pour le
* module qui l'a appelée.
*
* @pre          Le programme appelant doit avoir déclaré un double pointeur sur
*               des entirs non signés, qu'il affectera avec l'appel de la
*               fonction. Par exemple :<br/><code>
*               unsigned int * * wMonTableau (NULL) ;<br/>
*               …<br/>
*               wMonTableau = CreerTab2D(8, 8) ;</code>
*
* @param[in]    wHauteur représente la taille de la première dimension, celle
*               que l'on peut imaginer être la taille verticale du tableau, soit
*               les lignes. Attention : cette donnée ne doit pas être nulle !
* @param[in]    wLargeur représente la taille de la seconde dimension, celle
*               que l'on peut imaginer être la taille horizontale du tableau,
*               soit les colonnes. Attention : cette donnée ne doit pas être
*               nulle !
*
* @return       wTab un double pointeur sur des entiers non signés, contenant
*               l'adresse de la première case du tableau créé dynamiquement,
*               soit <code>&wTab[0][0]</code>.
*
* @see          Les commentaires dans la fonction !
* @see          LibererTab2D
*/
unsigned int * *	CreerTab2D(unsigned int wHauteur,
							   unsigned int wLargeur)
{
	// Double pointeur sur entiers non signés déclaré pour un travail local.
	unsigned int ** wTab (NULL) ;

	// On ne peut travailler que si les dimensions ne sont pas nulles !
	if ((wHauteur != 0) && (wLargeur != 0))
	{
		// Allocation dynamique de la première dimension : les lignes.
		wTab = new unsigned int * [wHauteur] ;
		if(wTab == NULL)
		{
			cout << "Erreur d'allocation memoire Dim 1 !" << endl ;
		}
		else
		{
			/* L'allocation de la première dimension est effective…
			* on passe en revue chaque case pour y placer un tableau
			* représentant la seconde dimension : les colonnes !
			*/
			for(unsigned int y = 0 ; y < wHauteur ; y++)
			{
				// Allocation dynamique de la seconde dimension dans chaque case
				wTab[y] = new unsigned int [wLargeur] ;
				if(wTab[y] == NULL)
				{
					 cout << "Erreur d'allocation memoire Dim 2 !" << endl ;
				}
				else
				{
					// L'allocation de la seconde dimension est effective…
					// on initialise toutes les cases de cette dimension à 0
					for(register unsigned int x = 0 ; x < wLargeur ; x++)
					{
						wTab[y][x] = 0 ;
					}
				}
			}
		}
	}
	else
	{
		// Si les dimensions ne conviennent pas : le tableau n'a pas été créé !
		wTab = NULL ;
	}

	// On retourne l'adresse du tableau 2D créé dynamiquement pour le programme
	// appelant.
	return wTab ;
}


/** Affichage d'un tableau à deux dimensions.
*
* @pre          Le tableau à afficher doit avoir été alloué et ses dimensions
*               correctement définies.
*
* @param[in]    wTab double pointeur sur des entiers non signés contenant
*               l'adresse de la première case du tableau 2D à afficher.
*               Ce pointeur ne doit pas être NULL !
* @param[in]    wHauteur représente la taille de la première dimension, celle
*               que l'on peut imaginer être la taille verticale du tableau, soit
*               les lignes. Attention : cette donnée ne doit pas être nulle !
* @param[in]    wLargeur représente la taille de la seconde dimension, celle
*               que l'on peut imaginer être la taille horizontale du tableau,
*               soit les colonnes. Attention : cette donnée ne doit pas être
*               nulle !
*
* @note         Si le tableau n'est pas alloué ou une de ses dimensions est
*               nulle, on affiche juste un message d'erreur !
*
* @attention    Ce module n'a aucun moyen de savoir si les dimensions qu'il
*               reçoit sont valides par rapport au tableau fourni ! C'est au
*               programme appelant de faire attention aux données transmises !
*/
void AfficherTab2D(unsigned int * * wTab,
				   unsigned int wHauteur,
				   unsigned int wLargeur)
{
	if((wTab != NULL) && (wHauteur != 0) && (wLargeur != 0))
	{
		for(unsigned int y = 0 ; y < wHauteur ; y++)
		{
			for(unsigned int x = 0 ; x < wLargeur ; x++)
			{
				cout << wTab[y][x] << " " ;
			}
			cout << endl ;
		}
	}
	else
	{
		cout << "Le tableau n'est pas alloue !" << endl ;
	}
}


/** Cette méthode permet de libérer l'espace mémoire alloué dynamiquement pour
* le tableau par la fonction <code>CreerTab2D</code>.<br/>
* La première étape est de réinitialiser la valeur de chaque case du tableau
* avec la valeur <code>0</code> afin d'effacer toute traces de nos valeurs dans la mémoire.<br/>
* Ensuite, chaque tableau de la seconde dimension est dés-alloué et la case lui
* faisant référence de la première dimension est réinitialisée à <code>NULL</code>.<br/>
* Finalement, la première dimension est libérée et le double pointeur
* <code>wTab</code> est placé à <code>NULL</code>.<br/>
* La fonction quitte en retourant l'adresse contenue dans <code>wTab</code>. Si
* tout s'est bien passé, elle retoure <code>NULL</code> !
*
* @pre          Le tableau à afficher doit avoir été alloué et ses dimensions
*               correctement définies.
*
* @param[in]    wTab double pointeur sur des entiers non signés contenant
*               l'adresse de la première case du tableau 2D à libérer.
*               Ce pointeur ne doit pas être NULL !
* @param[in]    wHauteur représente la taille de la première dimension, celle
*               que l'on peut imaginer être la taille verticale du tableau, soit
*               les lignes. Attention : cette donnée ne doit pas être nulle !
* @param[in]    wLargeur représente la taille de la seconde dimension, celle
*               que l'on peut imaginer être la taille horizontale du tableau,
*               soit les colonnes. Attention : cette donnée ne doit pas être
*               nulle !
*
* @return       wTab double pointeur sur des entiers non signés, contenant
*               <code>NULL</code> si la libérartion de la mémoire a été
*               réalisée avec succès.
*               Sinon, On retourne l'adresse reçue lors de l'appel.
*
* @attention    Ce module n'a aucun moyen de savoir si les dimensions qu'il
*               reçoit sont valides par rapport au tableau fourni ! C'est au
*               programme appelant de faire attention aux données transmises !
*
* @see          Les commentaires dans la fonction !
* @see          CreerTab2D
*/
unsigned int * * LibererTab2D(unsigned int * * wTab,
							  unsigned int wHauteur,
							  unsigned int wLargeur)
{
	// Le tableau et ses dimensions doivent être valides !
	if((wTab != NULL) && (wHauteur != 0) && (wLargeur != 0))
	{
		// On scrute la première dimension case par case
		for(unsigned int y = 0 ; y < wHauteur ; y++)
		{
			// Un tableau de seconde dimension doit être affecté à cette case…
			if(wTab[y] != NULL)
			{
				// Réinitialisation des cases de la seconde dimension à 0 :
				// on ne laisse pas de données sensibles en memoire !
				for(unsigned int x = 0 ; x < wLargeur ; x++)
				{
					wTab[y][x] = 0 ;
				}
				// Le tableau réinitialisé, on peut libérer son espace mémoire…
				delete [] wTab[y] ;
				// et effacer son adresse dans la case de la première dimension.
				wTab[y] = NULL ;
			}
		}
		// Tous les tableaux de seconde dimensions ont été libérés,
		// on peut libérer la première dimension !
		delete [] wTab ;
		// et effacer son adresse dans le double pointeur : plus de trace !
		wTab = NULL ;
	}
	// Retourne NULL si tout s'est bien passé, sinon l'adresse reçue n'a pas changé !
	return wTab ;
}

