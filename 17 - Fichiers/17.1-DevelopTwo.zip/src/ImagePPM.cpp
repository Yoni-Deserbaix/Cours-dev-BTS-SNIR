//------------------------------------------------------------------------------
/** @file       ImagePPM.cpp
* @brief        Bibliothèque de gestion d'une image au format PPM, RVB 255, ASCII
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019-01-13
* @version      1.0
* @date         2019-01-13
*
* Cette bibliothèque est destinée à proposer des outils de traitement des images
* couleur RVB 255, codées selon le format texte PPM (Portable PixMap).<br/>
* Seules les images de type P3 sont gérées pour le moment.
*
* Fabrication   DevelopTwo.pro
*
* @see          <a href="https://fr.wikipedia.org/wiki/Portable_pixmap">https://
*               fr.wikipedia.org/wiki/Portable_pixmap</a>
*/
//------------------------------------------------------------------------------

#include	<iostream>
#include	<fstream>
#include	<string.h>
#include "ImagePPM.h"
#include "CouleursRVB.h"

using namespace std ;


/** Fonction qui vérifie si le fichier dont le nom est passé en paramètre est
* au format PPM, RVB 255. Pour cela, elle ouvre le fichier dans un flux et lit
* la première ligne. Elle doit fournir la valeur <code>"P3"</code>.<br/>
* elle parcourt ensuite le fichier jusqu'à obtenir la données de la quatrième
* ligne d'en-tête. Théoriquement, cette valeur doit être <code>255</code>.<br/>
* Si les deux données lues effectivement dans le fichier sont conformes à ces
* valeurs, on considère que le fichier est du format attendu.
*
* @param[in]    sNomImage Chaîne de caractères au format C, contenant le nom du
*               fichier image à valider. Le chemin (relatif ou absolu) peut être
*               aussi indiqué !
*
* @return       bRetour ayant une valeur <code>true</code> si le fichier est
*               du format PPM RVB 255. Dans tous les autres cas (erreur
*               d'ouverture, format non valide…) <code>false</code> est retourné.
*
* @note         La valeur maximale d'une composante RVB (<code>255</code>) est
*               contenue dans la variable locale <code>wProfondeur</code>.
*/
bool	EstPPM_RVB(char * sNomImage)
{
	bool			bRetour		(false) ;
	ifstream		oFluxImage	(sNomImage) ;
	char			sCodage[3] ;
	char			sCommentaire[300] ;
	unsigned int	wHauteur	(0) ;
	unsigned int	wLargeur	(0) ;
	unsigned int	wProfondeur	(0) ;

	if (oFluxImage)
	{
		oFluxImage.getline(sCodage, 300) ;		//cout << sCodage << endl ;
		oFluxImage.getline(sCommentaire, 300) ;	//cout << sCommentaire << endl ;
		oFluxImage >> wLargeur ;				//cout << nLargeur << endl ;
		oFluxImage >> wHauteur ;				//cout << nHauteur << endl ;
		oFluxImage >> wProfondeur ;				//cout << nProfondeur << endl ;

		if((strcmp(sCodage, "P3")==0) && (wProfondeur == 255))
		{
			bRetour = true ;
		}
		oFluxImage.close() ;
	}
	return (bRetour) ;
}

/** Cette procédure recherche les dimensions de l'image. Elles sont contenus
* dans la troisième ligne de l'en-tête du fichier PPM.<br/>
* On valide donc que le fichier dont le nom est passé en paramètre est du format
* PPM RVB 255. Si c'est le cas, on parcourt le fichier jusqu'à la troisième
* ligne, et on lit la <code>wLargeur</code> puis la <code>wHauteur</code>.
*
* @param[in]    sNomImage Chaîne de caractères au format C, contenant le nom du
*               fichier image à analyser. Le chemin (relatif ou absolu) peut être
*               aussi indiqué !
* @param[out]   wLargeur est mise à jour avec la première valeur lue
*               dans la troisième ligne du
*               fichier. Elle correspond à la taille en x et est exprimée en
*               pixels. En cas de problème (fichier non PPM, flux invalide…),
*               ce paramètre est initialisé à <code>0</code>.
* @param[out]   wHauteur est mise à jour avec la seconde valeur lue
*               dans la troisième ligne du
*               fichier. Elle correspond à la taille en y et est exprimée en
*               pixels. En cas de problème (fichier non PPM, flux invalide…),
*               ce paramètre est initialisé à <code>0</code>.
*
* @note         Remarquez que cette procédure retourne deux valeurs par passage
*               de paramètres par référence :
*               <code>wLargeur</code> et <code>wHauteur</code> !
*
* @see          EstPPM_RVB
*/
void	LirePPM_Dimensions(char * sNomImage,
						   unsigned int & wHauteur,
						   unsigned int & wLargeur)
{
	ifstream		oFluxImage ;
	char			sCodage[3] ;
	char			sCommentaire[300] ;

	wHauteur = 0 ;
	wLargeur = 0 ;
	if(EstPPM_RVB(sNomImage))
	{
		oFluxImage.open(sNomImage) ;
		if (oFluxImage)
		{
			oFluxImage.getline(sCodage, 300) ;		//cout << sCodage << endl ;
			oFluxImage.getline(sCommentaire, 300) ;	//cout << sCommentaire << endl ;
			oFluxImage >> wLargeur ;				//cout << nLargeur << endl ;
			oFluxImage >> wHauteur ;				//cout << nHauteur << endl ;
			oFluxImage.close() ;
		}
	}
}

/** Cette fonction vérifie que les dimensions réelles de l'image correspondent
* aux dimensions recherchée par l'utilisateur. Ce dernier indique en paramètre
* les dimensions qu'il désire pour une image. La fonction recherche la taille
* de l'image dont le nom est passé en paramètre et confirme ou infirme la
* concordance.
*
* @param[in]    sNomImage Chaîne de caractères au format C, contenant le nom du
*               fichier image à analyser. Le chemin (relatif ou absolu) peut être
*               aussi indiqué !
* @param[in]    wLargeur contient la taille en x, exprimée en
*               pixels, que l'utilisateur veux avoir dans l'image.
* @param[in]    wHauteur contient la taille en y, exprimée en
*               pixels, que l'utilisateur veux avoir dans l'image.
*
* @return       bRetour sera de valeur <code>true</code> si l'image est de la
*               taille recherchée par l'utilisateur, et <code>false</code> sinon.
*
* @note         En cas d'erreur d'ouverture du fichier ou autre problème de
*               format, rien de spécial n'est indiqué au programme appelant :
*               seule la valeur <code>false</code> est retournée, mais on ne
*               saura pas si c'est à cause de dimensions incorrectes ou d'une
*               erreur !
*/
bool	EstDeTaille(char * sNomImage,
				   unsigned int wHauteur,
				   unsigned int wLargeur)
{
	bool			bRetour			(false) ;
	unsigned int	wHauteurImage	(0) ;
	unsigned int	wLargeurImage	(0) ;

	LirePPM_Dimensions(sNomImage, wHauteurImage, wLargeurImage) ;
	if((wHauteur == wHauteurImage) && (wLargeur == wLargeurImage))
	{
		bRetour = true ;
	}
	return	bRetour ;
}

/** Cette procédure réalise la lecture du fichier image et sa sauvegarde dans un
* tableau, passé en paramètre.<br/>
* Elle commence par valider qu'il s'agit bien d'un fichier PPM. Si c'est le cas,
* elle passe en revue les informations contenus dans l'en-tête, notamment les
* dimensions (variables locales <code>wLargeurImage</code> et
* <code>wHauteurImage</code>). Elle valide ensuite la concordance des dimensions
* reçues en paramètre avec celles lues. Si elles correspondent, la lecture
* débute.<br/>
* La couleur de chaque pixel est récupérée en trois lectures dans le fichier :
* une pour chaque composante R, V puis B. Avec ces valeurs, la couleur RVB est
* calculée par la fonction <code>RVB</code> puis placée dans la case du tableau
* aux coordonnées qui vont bien !<br/>
* Ce traitement se poursuit afin de lire toute l'image.
*
* @pre          Le tableau à remplir doit avoir été alloué et ses dimensions
*               correctement définies.
*
* @param[in]    sNomImage Chaîne de caractères au format C, contenant le nom du
*               fichier image à analyser. Le chemin (relatif ou absolu) peut être
*               aussi indiqué !
* @param[in]    wHauteur contient la taille de la première dimension du tableau
*               <code>wTab</code>. Elle correspond à y : les lignes !
* @param[in]    wLargeur contient la taille de la seconde dimension du tableau
*               <code>wTab</code>. Elle correspond à x : les colonnes !
* @param[out]   wTab double pointeur sur entiers non signés, qui pointe sur la
*               première case du tableau qui va recevoir les couleurs RVB de
*               chaque pixel de l'image.
*
* @retval       wTab contient les couleurs de chaque pixel de l'image si tout
*               se passe bien. Sinon, toutes ses cases sont réinitialisées avec
*               la valeur <code>0</code>, représentant une image noire !
*
* @attention    Ce module n'a aucun moyen de savoir si les dimensions qu'il
*               reçoit sont valides par rapport au tableau fourni ! C'est au
*               programme appelant de faire attention aux données transmises !
*
* @see          RVB
*/
void LireImagePPM(char * sNomImage,
				  unsigned int * * wTab,
				  unsigned int wHauteur,
				  unsigned int wLargeur)
{
	ifstream		oFluxImage ;
	char			sCodage[3] ;
	char			sCommentaire[300] ;
	unsigned int	wHauteurImage	(0) ;
	unsigned int	wLargeurImage	(0) ;
	unsigned int	wProfondeur		(0) ;
	unsigned int	wR				(0) ;
	unsigned int	wV				(0) ;
	unsigned int	wB				(0) ;

	// L'image n'est pas valide par défaut, jusqu'à preuve du contraire !
	for(unsigned int y = 0 ; y < wHauteur ; y++)
	{
		for(unsigned int x = 0 ; x < wLargeur ; x++)
		{
			wTab[y][x] = 0 ;
		}
	}

	// Est-ce un fichier au bon format ?
	if(EstPPM_RVB(sNomImage))
	{
		oFluxImage.open(sNomImage) ;
		if (oFluxImage)
		{
			// Le flux du fichier est ouvert, on lit son en-tête
			oFluxImage.getline(sCodage, 300) ;		//cout << sCodage << endl ;
			oFluxImage.getline(sCommentaire, 300) ;	//cout << sCommentaire << endl ;
			oFluxImage >> wLargeurImage ;			//cout << nLargeurImage << endl ;
			oFluxImage >> wHauteurImage ;			//cout << nHauteurImage << endl ;
			oFluxImage >> wProfondeur ;				//cout << nProfondeur << endl ;

			// Les dimensions sont-elles correctes ?
			if((wLargeur == wLargeurImage) && (wHauteur == wHauteurImage))
			{
				/* L'image est considérée valide, on peut la lire pixel par
				 * pixel… Sachant que la couleur est codée par trois composantes
				 * dans le fichier et qu'il faut reconstituer le RVB
				 * correspondant !
				 */
				for(unsigned int y = 0 ; y < wHauteur ; y++)
				{
					for(unsigned int x = 0 ; x < wLargeur ; x++)
					{
						oFluxImage >> wR ;
						oFluxImage >> wV ;
						oFluxImage >> wB ;
						wTab[y][x] = RVB(wR, wV, wB) ;
					}
				}
			}
			oFluxImage.close() ;
		}
	}
}



