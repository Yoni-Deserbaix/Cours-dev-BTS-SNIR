//------------------------------------------------------------------------------
/** @file       main.cpp
* @brief        Programme principal
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019-01-13
* @version      1.0
* @date         2019-01-13
*
* Programme de lecture et d'affichage des informations d'un fichier image au
* format PPM.<br/> Il ne gère pas directement le fichier mais fait appel aux
* procédures et fonctions prévues pour ça.
*
* Fabrication   DevelopTwo.pro
*
*/
//------------------------------------------------------------------------------

#include	<iostream>
#include	"CouleursRVB.h"
#include	"ImagePPM.h"
#include	"Tab2D.h"

using namespace std ;

/** Programme de lecture et d'affichage des informations d'un fichier image au
* format PPM.<br/> Il ne gère pas directement le fichier mais fait appel aux
* procédures et fonctions prévues pour ça.
*
* @pre          Il faut qu'il existe une image au format PPM, RVB 255.
*
* @return       O lors de la fin du programme
*
*/
int main()
{
	char				sNomImage[] = "V:/Coeur.PPM" ;
	//char				sNomImage[] = "V:/Smiley_Couleur.PPM" ;
	unsigned int		wHauteur	(0) ;
	unsigned int		wLargeur	(0) ;
	unsigned int * *	tabLogo		(nullptr) ;


	cout << sNomImage << (EstPPM_RVB(sNomImage) ? " est" : " n'est pas") ;
	cout << " un fichier PPM correct !" << endl ;

	LirePPM_Dimensions(sNomImage, wHauteur, wLargeur) ;
	cout << "Les dimensions de l'image sont " ;
	cout << wHauteur << " x " << wLargeur << " pixels !" << endl ;

	cout << "Est-il de taille 8x8 ?" << (EstDeTaille(sNomImage, 8, 8) ? " Oui" : " Non") ;
	cout << endl ;

	cout << "Est-il de taille 16x8 ?" << (EstDeTaille(sNomImage, 16, 8) ? " Oui" : " Non") ;
	cout << endl ;


	tabLogo = CreerTab2D(wHauteur, wLargeur) ;
	if(tabLogo != nullptr)
	{
		//AfficherTab2D(tabLogo, wHauteur, wLargeur) ;

		LireImagePPM(sNomImage, tabLogo, wHauteur, wLargeur) ;
		AfficherImage(tabLogo, wHauteur, wLargeur) ;


		tabLogo = LibererTab2D(tabLogo, wHauteur, wLargeur) ;
		//AfficherTab2D(tabLogo, wHauteur, wLargeur) ;
		cout << "Le tableau" ;
		cout << (tabLogo == nullptr ? " a " : " n'a pas ") ;
		cout << "bien ete des-alloue !" << endl ;
	}
	else
	{
		cout << "le tableau dynamique n'a pas pu etre cree ! Dommage !" << endl ;
	}

	return 0 ;
}
