#include    <iostream>
#include    <QString>
#include    <fstream>
#include    "TableauDynamique.h"

using namespace std ;

ifstream::pos_type    Get_nTaille(QString sNomFichier)
{
    ifstream::pos_type  nTaille     (0) ;
    ifstream            oFichier    (sNomFichier.toStdString()) ;

    if (oFichier)
    {
        oFichier.seekg(0, ios::end) ;
        nTaille = oFichier.tellg() ;
        oFichier.close() ;
    }
    return nTaille ;
}


char *  Lire(QString sNomFichier, streamsize & nNbreLu)
{
    ifstream::pos_type  nTaille     (0) ;
    ifstream            oFichier    (sNomFichier.toStdString(), ios::binary) ;
    char *              sContenu    (nullptr) ;

    if (oFichier)
    {
        nTaille = Get_nTaille(sNomFichier) ;

        sContenu = CreerTableau(static_cast<int>(nTaille)+1) ;

		oFichier.read(sContenu, nTaille) ;
		sContenu[nTaille] = '\0' ;

        nNbreLu = oFichier.gcount() ;

        oFichier.close() ;

    }
    return sContenu ;
}

bool Ecrire(QString sNomFichier, char * sContenu, streamsize nNbreAEcrire)
{
    bool                bEcritureOK (false) ;
    ofstream::pos_type  nTaille     (0) ;
    ofstream            oFichier    (sNomFichier.toStdString(), ios::binary) ;

    if (oFichier)
    {
        oFichier.clear() ;

        oFichier.write(sContenu, nNbreAEcrire) ;

        if((oFichier.rdstate() & ifstream::badbit) == 0)
        {
            bEcritureOK = true ;
        }

        oFichier.close() ;

    }
    return bEcritureOK ;
}
