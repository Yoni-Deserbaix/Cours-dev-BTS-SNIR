#include    <QString>
#include    "TableauDynamique.h"

char * Chiffrer(char * sOriginal, int nTaille, const char * sClef)
{
    char *  sChiffre    (nullptr) ;
    int     j           (0) ;           // Inutile pour la troisième soluce
    int     nTailleClef (0) ;           // Inutile pour la première soluce


    while(sClef[nTailleClef] != '\0')
    {
        nTailleClef++ ;
    }

    sChiffre = CreerTableau(nTaille+1) ;

    for (int i = 0; i < nTaille; i++)
    {
        /*
        //Première soluce

        sChiffre[i] = sOriginal[i] ^ sClef[j] ;

        j++ ;
        if (sClef[j] == '\0')
        {
            j = 0 ;
        }
        */

        /*
        //Deuxième soluce

        sChiffre[i] = sOriginal[i] ^ sClef[j] ;

        j++ ;
        if (j == nTailleClef)
        {
            j = 0 ;
        }
        */

        // Troisième soluce, bien plus jolie !!! Le J devient inutile !
        sChiffre[i] = sOriginal[i] ^ sClef[i % nTailleClef] ;

    }
    sChiffre[nTaille] = '\0' ;

    return sChiffre ;
}

char * Dechiffrer(char * sOriginal, int nTaille, const char * sClef)
{
    char *  sDechiffre    (nullptr) ;

    sDechiffre = Chiffrer(sOriginal, nTaille, sClef) ;

    return sDechiffre ;
}
