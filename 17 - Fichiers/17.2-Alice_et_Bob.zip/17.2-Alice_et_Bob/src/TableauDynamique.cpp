char * CreerTableau(int nTaille)
{
    char *  sTableau  (nullptr) ;

    sTableau = new  char [nTaille] ;

    return sTableau ;
}


void LibererTableau1D(char * sTableau)
{
    if (sTableau != nullptr)
    {
        delete [] sTableau ;
        sTableau = nullptr ;
    }
}
