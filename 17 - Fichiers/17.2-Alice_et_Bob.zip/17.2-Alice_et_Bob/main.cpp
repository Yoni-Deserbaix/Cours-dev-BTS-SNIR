#include    <iostream>         // cout
#include    <QString>          // QString !!!
#include    <fstream>          // ifstream::pos_type, streamsize
#include    "Fichiers.h"
#include    "Chiffrement.h"
#include    "TableauDynamique.h"

using namespace std ;

int main()
{
    QString             sNomFichierOriginal     ("V:\\Chanson.txt") ;
    QString             sNomFichierChiffre      ("") ;
    QString             sNomFichierDechiffre    ("") ;
    ifstream::pos_type  nTaille                 (0) ;
    char *              sContenuOriginal        (nullptr) ;
    streamsize          nNbreOctetsLus          (0) ;
    streamsize          nNbreOctetsChiffre      (0) ;
    streamsize          nNbreOctetsDechiffre    (0) ;

    bool                bEcritureOK             (false) ;
    char *              sContenuChiffre         (nullptr) ;
    char *              sContenuDechiffre       (nullptr) ;

    sNomFichierChiffre = sNomFichierOriginal.left(sNomFichierOriginal.length() - 3) + QString("bin") ;
    sNomFichierDechiffre = sNomFichierOriginal.left(sNomFichierOriginal.length() - 4) + QString("_2.txt") ;

    cout << sNomFichierChiffre.toStdString().c_str() << endl ;
    cout << sNomFichierDechiffre.toStdString().c_str() << endl ;

    // Chiffrement
    nTaille = Get_nTaille(sNomFichierOriginal) ;

    sContenuOriginal = Lire(sNomFichierOriginal, nNbreOctetsLus) ;
    cout << "Taille du fichier : " << nTaille << endl ;
    cout << "Nbre d'octets lus : " << nNbreOctetsLus << endl ;
    cout << sContenuOriginal << endl ;

    nNbreOctetsChiffre = nNbreOctetsLus ;
    sContenuChiffre = Chiffrer(sContenuOriginal, static_cast<int>(nNbreOctetsChiffre), "Bonjour") ;
    cout << sContenuChiffre << endl ;

    bEcritureOK = Ecrire(sNomFichierChiffre, sContenuChiffre, nNbreOctetsChiffre) ;
    cout << "Ecriture " << (bEcritureOK ? "OK" : "KO") << endl ;

    LibererTableau1D(sContenuOriginal) ;
    LibererTableau1D(sContenuChiffre) ;


    // Dechiffrement
    nTaille = Get_nTaille(sNomFichierChiffre) ;

    sContenuChiffre = Lire(sNomFichierChiffre, nNbreOctetsLus) ;
    cout << "Taille du fichier : " << nTaille << endl ;
    cout << "Nbre d'octets lus : " << nNbreOctetsLus << endl ;
    cout << sContenuChiffre << endl ;

    nNbreOctetsDechiffre = nNbreOctetsLus ;
    sContenuDechiffre = Dechiffrer(sContenuChiffre, static_cast<int>(nNbreOctetsDechiffre), "Bonjour") ;
    cout << sContenuDechiffre << endl ;

    bEcritureOK = Ecrire(sNomFichierDechiffre, sContenuDechiffre, nNbreOctetsDechiffre) ;
    cout << "Ecriture " << (bEcritureOK ? "OK" : "KO") << endl ;

    LibererTableau1D(sContenuChiffre) ;
    LibererTableau1D(sContenuDechiffre) ;

    return 0 ;
}
