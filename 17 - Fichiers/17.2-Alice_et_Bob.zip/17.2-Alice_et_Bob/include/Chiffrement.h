#ifndef CHIFFREMENT_H
#define CHIFFREMENT_H

#include    <QString>

char * Chiffrer(char * sOriginal, int nTaille, const char * sClef) ;
char * Dechiffrer(char * sOriginal, int nTaille, const char * sClef) ;

#endif // CHIFFREMENT_H
