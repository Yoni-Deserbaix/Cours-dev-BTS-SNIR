#ifndef FICHIERS_H
#define FICHIERS_H

#include <QString>
#include <fstream>
using namespace std ;


ifstream::pos_type  Get_nTaille(QString sNomFichier) ;
char *  Lire(QString sNomFichier, streamsize & nNbreLu) ;
bool    Ecrire(QString sNomFichier, char * sContenu, streamsize nNbreAEcrire) ;


#endif // FICHIERS_H
