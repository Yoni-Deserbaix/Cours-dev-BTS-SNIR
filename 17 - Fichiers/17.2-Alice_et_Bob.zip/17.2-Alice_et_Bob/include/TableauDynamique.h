#ifndef TABLEAUDYNAMIQUE_H
#define TABLEAUDYNAMIQUE_H

char *  CreerTableau(int nTaille) ;
void    LibererTableau1D(char * sTableau) ;

#endif // TABLEAUDYNAMIQUE_H
