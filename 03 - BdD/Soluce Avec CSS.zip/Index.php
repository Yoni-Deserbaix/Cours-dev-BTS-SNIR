<html>
	 <head>
		<meta http-equiv="content-type" content="text/html;charset=UTF-8"><title>Connexion au complexe sportif de la Cholière</title>
		<link charset="UTF-8" href="MesStyles.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		
		<P class="centre bas moyen">
			Bienvenue au
		</P>
		<P class="centre bas grand">
				Complexe sportif de la Choli&egrave;re.
		</P>
		<P class="centre bas"><BR/>
		</P>
		<P class="centre bas moyen">
				Pour r&eacute;server un cours de tennis, veuillez vous identifier.
		</P>
		<P class="centre bas"><BR/>
		</P>
		
		<?php include('Connexion.html'); ?>

	</body>
 </html>