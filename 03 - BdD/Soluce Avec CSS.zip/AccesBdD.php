<?php
$Nom=$_POST['nom'] ;
$Prenom=$_POST['prenom'] ;
$MotDePasse=$_POST['motdepasse'] ;

if(empty($Nom) || empty($Prenom) || empty($MotDePasse))
{ // si un des champs n'est pas rempli
   print ("<h4>Erreur !</h4>");
   print ("<p>Vous devez remplir <b>correctement<b> et <b>obligatoirement<b> tous les champs.</p>");
	include('Connexion.html');
   exit() ;
}

$ServeurBdD = "127.0.0.1" ;
$PortBdD = "3307";
$User = "root" ;
$Password = "" ;
$BdD = "Acces" ;
	// Connexion au serveur de la base de données
	$bConnect = mysqli_connect(
								$ServeurBdD.":".$PortBdD,
								$User,
								$Password,
								$BdD) ;
	if(!$bConnect)
	{
		Echo '<BR/><BR/><B>Connexion au serveur de Base de Données impossible</B><BR/>' ;
		exit() ;
	}

	// instructions et requêtes sur la base de données
	$Requete = "SELECT MotDePasse FROM Passwords WHERE Nom=\"".$Nom."\" AND Prenom = \"".$Prenom."\" ;" ;
	//echo $Requete ;
	$Resultat = mysqli_query($bConnect,$Requete) ;
	// echo mysqli_error($bConnect) ;
	if(mysqli_num_rows($Resultat) <> 0)
	{	
		$MotDePasseOK = false ;
		while (($Enregistrement=mysqli_fetch_array($Resultat)) && ($MotDePasseOK == false))
		{
			$MotDePasseBdD = $Enregistrement['MotDePasse'] ;
			if($MotDePasseBdD == $MotDePasse)
			{
				$MotDePasseOK = true ;
			}
		}

		if($MotDePasseOK == true)
		{
			echo "<B>Bienvenue</B>, $Nom $Prenom<BR/><BR/>" ;
			include('Disponibilites.html') ;
		}
		else
		{
			echo "<BR/><B>Mot de passe incorrect.</B> Veuillez le ressaisir.<BR/><BR/>" ;
			include('Connexion.html');
		}
	}
	else
	{
	
			echo "<BR/><B>Cet utilisateur ne m'est pas connu.</B> Veuillez vous identifier à nouveau.<BR/><BR/>" ;
			include('Connexion.html');
	}
	mysqli_close($bConnect) ;

?>