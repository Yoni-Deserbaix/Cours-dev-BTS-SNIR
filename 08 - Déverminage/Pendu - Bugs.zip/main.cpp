#include <time.h>
#include <iostream>
using namespace std ;


int main()
{
    char   sMotATrouver[13][20]  =   {"brouillamini",
                                   "capitouls",
                                   "coruscant",
                                   "exhereder",
                                   "digitule",
                                   "hypocras",
                                   "kaolin",
                                   "lacrymule",
                                   "padischah",
                                   "smaragdin",
                                   "tympanon",
                                   "vicesimal",
                                   "zingolin"
                                  } ;
    int     nHasard             (0) ;
    char    sMotDecouvert[100+1] ;
    int     nTaille             (0) ;
    char    cLettre             ('\0') ;
    bool    bLettreUtilisee[26] ;
    int     nNbreDeCoup         (0) ;
    bool    bLettreDecouverte   (false) ;
    int     nNbreErreur         (0) ;
    int     nNbreErreurMax      (9) ;
    bool    bMotTrouve          (false) ;
    int     i                   (0) ;

    srand(time(nullptr)) ;
    nHasard = rand() % 13 ;

    // Initialisation des variables et tableauxx
    while(sMotATrouver[nHasard][nTaille] != '\0')
    {
        nTaille ++ ;
    }
    for (i = 0; i <= 100; i++)
    {
        if(i < nTaille)
        {
            sMotDecouvert[i] = '_' ;
        }
        else
        {
            sMotDecouvert[i] = '\0' ;
        }
    }
    for (i = 0; i < 26; i++)
    {
        bLettreUtilisee[i] = false ;
    }

    // Le jeu se poursuit jusqu'à ce que le nombre d'erreur égale ou dépasse
    // le max autorisé OU que le mot à trouvé est découvert !
    do
    {
        // Affichage du mot découvert en cours de route et du nombre d'erreurs
        system("CLS") ;
        cout << sMotDecouvert << "\t\t" ;
        cout << "Nombre d'erreur : " << nNbreErreur << "/" << nNbreErreurMax << endl ;
        cout << endl ;

        // Saisie de la lettre minuscule
        do
        {
            cout << "Proposez une lettre minuscule (hors accentuees) :" << endl ;
            cin >> cLettre ;
        }
        while(!(    'a' <= cLettre || cLettre <= 'z'    )) ;

        // Mémorisation de la lettre saisie
        bLettreUtilisee[cLettre - 'a'] = true ;

        // On a joué un coup de plus !
        nNbreDeCoup ++ ;

        // Recherche de la lettre dans le mot à découvir et remplacement
        // du '_' dans le mot découvert si elle y est !
        bLettreDecouverte = false ;
        i = 0 ;
        do
        {
            if(sMotATrouver[nHasard][i] == cLettre)
            {
                sMotDecouvert[i] = cLettre ;

            }
            i++ ;
        }
        while(!(    i >= nTaille     )) ;

        // La lettre saisie n'est pas dans le mot à trouver… C'est une erreur !
        if(!bLettreDecouverte)
        {
            nNbreErreur ++ ;
        }

        // Validation du mot découvert complet ou non
        bMotTrouve = true ;

        do
        {
            if(sMotDecouvert[i] == '-')
            {
                bMotTrouve = false ;
            }
            i++ ;
        }
        while(    i >= nTaille     ) ;

    }
    while(!(    (nNbreErreur >= nNbreErreurMax) || bMotTrouve     )) ;


    // Affichage du résultat !
    system("CLS") ;
    if (bMotTrouve)
    {
        cout << "Bien joue !" << endl << "Vous avez decouvert le mot \"" ;
        cout << sMotATrouver[nHasard] << "\" en " << nNbreDeCoup << " coups " ;
        cout << " et " << nNbreErreurMax << " erreurs !" << endl ;
    }
    else
    {
        cout << "Dommage !" << endl << "Vous n'avez pas decouvert le mot \"" ;
        cout << sMotATrouver[nHasard] << "\" avant de faire " << nNbreErreurMax << " erreurs !" << endl ;
    }

    // Affichage des lettres utilisées
    cout << "vous avez propose les lettres :" << endl ;
    for (int i = 0; i < 26; i++)
    {
        if(bLettreUtilisee[i])
        {
            cout << 'a' + i << " " ;
        }
    }

    cout << endl << endl ;

    return 0;
}
