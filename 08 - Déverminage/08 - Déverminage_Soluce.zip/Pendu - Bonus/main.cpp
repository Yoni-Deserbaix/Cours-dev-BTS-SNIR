#include <time.h>
#include <iostream>
using namespace std ;


int main()
{
    char   sMotATrouver[13][20]  =   {"brouillamini",
                                   "capitouls",
                                   "coruscant",
                                   "exhereder",
                                   "digitule",
                                   "hypocras",
                                   "kaolin",
                                   "lacrymule",
                                   "padischah",
                                   "smaragdin",
                                   "tympanon",
                                   "vicesimal",
                                   "zingolin"
                                  } ;
    int     nHasard                 (0) ;
    char    sMotDecouvert[100+1] ;
    int     nTaille                 (0) ;
    char    cLettre                 ('\0') ;
    bool    bLettreUtilisee[26] ;
    int     nNbreDeCoup             (0) ;
    bool    bLettreDecouverte       (false) ;
    int     nNbreErreur             (0) ;
    int     nNbreErreurMax          (9) ;
    bool    bMotTrouve              (false) ;
    int     i                       (0) ;
    bool    bLettreIndiceProposee   (false) ;
    char    cLettreIndice           ('\0') ;
    int     nPlace                  (0) ;

    srand(time(nullptr)) ;
    nHasard = rand() % 13 ;
    cout << sMotATrouver[nHasard] << endl ;
    // Initialisation des variables et tableauxx
    while(sMotATrouver[nHasard][nTaille] != '\0')
    {
        nTaille ++ ;
    }
    for (i = 0; i <= 100; i++)
    {
        if(i < nTaille)
        {
            sMotDecouvert[i] = '_' ;
        }
        else
        {
            sMotDecouvert[i] = '\0' ;
        }
    }
    for (i = 0; i < 26; i++)
    {
        bLettreUtilisee[i] = false ;
    }

    // Le jeu se poursuit jusqu'à ce que le nombre d'erreur égale ou dépasse
    // le max autorisé OU que le mot à trouvé est découvert !
    do
    {
        // Affichage du mot découvert en cours de route et du nombre d'erreurs
        system("CLS") ;
        cout << sMotDecouvert << "\t\t" ;
        cout << "Nombre de coups : " << nNbreDeCoup << "\t\tNombre d'erreur : " << nNbreErreur << "/" << nNbreErreurMax << endl ;
        cout << endl ;
        // Saisie de la lettre minuscule
        do
        {
            cout << "Proposez une lettre minuscule (hors accentuees) :" << endl ;
            cin >> cLettre ;
        }
        while(!(    ('a' <= cLettre && cLettre <= 'z') &&  !bLettreUtilisee[cLettre - 'a']   )) ;

        // Mémorisation de la lettre saisie
        bLettreUtilisee[cLettre - 'a'] = true ;

        // On a joué un coup de plus !
        nNbreDeCoup ++ ;

        // Recherche de la lettre dans le mot à découvir et remplacement
        // du '_' dans le mot découvert si elle y est !
        bLettreDecouverte = false ;
        i = 0 ;
        do
        {
            if(sMotATrouver[nHasard][i] == cLettre)
            {
                sMotDecouvert[i] = cLettre ;
                bLettreDecouverte = true ;
            }
            i++ ;
        }
        while(!(    i >= nTaille     )) ;

        // La lettre saisie n'est pas dans le mot à trouver… C'est une erreur !
        if(!bLettreDecouverte)
        {
            nNbreErreur ++ ;
            // Proposition d'une lettre indice
            if(nNbreErreur > 6 && !bLettreIndiceProposee)
            {
                cout << "Vous avez fait " << nNbreErreur << " erreurs !" << endl ;
                cout << "Voulez-vous une lettre indice ? (O/N)" << endl ;
                do
                {
                    cin >> cLettreIndice ;
                } while(!(  cLettreIndice == 'O' || cLettreIndice == 'N'    )) ;
                if (cLettreIndice == 'O')
                {
                    // Recherche d'une lettre du mot non utilisée
                    bLettreIndiceProposee = true ;
                    do
                    {
                        nPlace = rand() % nTaille ;
                    }
                    while(!(  sMotDecouvert[nPlace] == '_' || nPlace >= nTaille )) ;
                    if (nPlace <= nTaille)
                    {
                        cLettreIndice = sMotATrouver[nHasard][nPlace] ;
                        bLettreUtilisee[cLettreIndice - 'a'] = true ;
                        // Affichage et insertion de cette lettre dans le mot
                        cout << "Voici votre lettre indice : " << cLettreIndice << endl ;
                        i = 0 ;
                        do
                        {
                            if(sMotATrouver[nHasard][i] == cLettreIndice)
                            {
                                sMotDecouvert[i] = cLettreIndice ;
                            }
                            i++ ;
                        }
                        while(!(    i >= nTaille     )) ;
                    }
                }
            }
        }

        // Validation du mot découvert complet ou non
        bMotTrouve = true ;
        i = 0 ;
        do
        {
            if(sMotDecouvert[i] == '_')
            {
                bMotTrouve = false ;
            }
            i++ ;
        }
        while(!(    i >= nTaille     )) ;

    }
    while(!(    (nNbreErreur >= nNbreErreurMax) || bMotTrouve     )) ;


    // Affichage du résultat !
    system("CLS") ;
    if (bMotTrouve)
    {
        cout << "Bien joue !" << endl << "Vous avez decouvert le mot \"" ;
        cout << sMotATrouver[nHasard] << "\" en " << nNbreDeCoup << " coups " ;
        cout << " et " << nNbreErreur << " erreurs !" << endl ;
    }
    else
    {
        cout << "Dommage !" << endl << "Vous n'avez pas decouvert le mot \"" ;
        cout << sMotATrouver[nHasard] << "\" avant de faire " << nNbreErreurMax << " erreurs !" << endl ;
    }

    // Affichage des lettres utilisées
    cout << "vous avez propose les lettres :" << endl ;
    for (int i = 0; i < 26; i++)
    {
        if(bLettreUtilisee[i])
        {
            cout << static_cast<char>('a' + i) << " " ;
        }
    }

    cout << endl << endl ;

    return 0;
}
