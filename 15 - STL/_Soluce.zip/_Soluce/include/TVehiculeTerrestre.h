#if !defined(_TVehiculeTerrestre_H)
#define _TVehiculeTerrestre_H
#include    <ostream>

class TVehiculeTerrestre
{
public:
    TVehiculeTerrestre();
    TVehiculeTerrestre(const TVehiculeTerrestre & oObjetACopier);
    TVehiculeTerrestre( unsigned int    Puissance,
                        unsigned int    Poids,
                        unsigned int    VitesseMaxi
                        );
    ~TVehiculeTerrestre();
    TVehiculeTerrestre & operator=(const TVehiculeTerrestre & oObjetACopier);

    unsigned int    get_VitesseActuelle() ;
    unsigned int    get_Puissance() ;
    unsigned int    get_Poids() ;
    unsigned int    get_VitesseMaxi() ;
    void            set_VitesseActuelle(unsigned int VitesseActuelle) ;
    void            set_Puissance(unsigned int Puissance) ;
    void            set_Poids(unsigned int Poids) ;
    void            set_VitesseMaxi(unsigned int VitesseMaxi) ;

    //class ostream;
    friend std::ostream & operator<<(std::ostream &a,const TVehiculeTerrestre &b);

private :
    unsigned int    VitesseActuelle ;
    unsigned int    Puissance ;
    unsigned int    Poids ;
    unsigned int    VitesseMaxi ;

};




#endif  //_TVehiculeTerrestre_H
