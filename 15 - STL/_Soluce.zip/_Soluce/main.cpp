#include    <vector>
#include    <iostream>
#include    <stdlib.h>

#include    "TVehiculeTerrestre.h"

using namespace std ;

int main()
{
    TVehiculeTerrestre                      oVT1 ;
    oVT1.set_VitesseActuelle(50) ;
    oVT1.set_Puissance(500) ;
    oVT1.set_Poids(1000) ;
    oVT1.set_VitesseMaxi(150) ;
    cout << oVT1 << endl ;


//    TVehiculeTerrestre                      oVT2            (oVT1) ;
//    cout << oVT2 << endl ;

//    TVehiculeTerrestre                      oVT3            (600, 1000, 150) ;
//    cout << oVT3 << endl ;

    vector<TVehiculeTerrestre>              VecteurVT ;
    unsigned int                            nNbreElement    (0) ;


//    oVT3 = oVT2 ;
//    cout << oVT3 << endl ;
    //VecteurVT.reserve(100) ;          // Capacit� est port�e � 100
    //VecteurVT.resize(200) ;         // Capacit� port�e � 200

    VecteurVT.push_back(oVT1) ;
//    VecteurVT.push_back(oVT2) ;
//    VecteurVT.push_back(oVT3) ;

    nNbreElement = static_cast<unsigned int>(VecteurVT.size()) ;
    cout << "Taille : " << nNbreElement << endl ;
    for (unsigned int i=0; i<nNbreElement; i++)   // Affichage par indexation (25)
    {
        cout << VecteurVT[i] ;
        cout << " ";
    }
     cout << endl;


/*
    vector<TVehiculeTerrestre>::iterator    iElemCourant ;

    iElemCourant = VecteurVT.begin();				// L�it�rateur est plac� sur le premier �l�ment
    while (iElemCourant != VecteurVT.end())
    {
        cout << *iElemCourant << endl ;									// On r�cup�re l��l�ment index�
        ++ iElemCourant;													// On passe � l��l�ment suivant
    }
*/

/*    VecteurVT.pop_back() ;
    //VecteurVT.erase(VecteurVT.end()) ;

    iElemCourant = VecteurVT.begin();				// L�it�rateur est plac� sur le premier �l�ment
    while (iElemCourant != VecteurVT.end())
    {
        cout << *iElemCourant << endl ;									// On r�cup�re l��l�ment index�
        ++ iElemCourant;													// On passe � l��l�ment suivant
    }
*/

//    cout << *VecteurVT.begin() ;    // it�rateur sur le premier �l�ment
//    cout << VecteurVT.front() ;     // r�f�rence du premier �l�ment
//    cout << VecteurVT.back() ;      // r�f�rence du dernier �l�ment
//    cout << *VecteurVT.end() ;      // it�rateur sur l'�lement apr�s le dernier



     //pop_back() et erase()
     nNbreElement = static_cast<unsigned int>(VecteurVT.size()) ;
    cout << "Taille : " << nNbreElement << endl ;

    system("PAUSE") ;
    return 0;
}
