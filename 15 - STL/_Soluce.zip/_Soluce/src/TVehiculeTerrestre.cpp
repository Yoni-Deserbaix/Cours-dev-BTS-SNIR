#include <iostream>
using namespace std ;
#include "TVehiculeTerrestre.h"

TVehiculeTerrestre::TVehiculeTerrestre() :
    VitesseActuelle (0),
    Puissance       (0),
    Poids           (0),
    VitesseMaxi     (0)
{
    cout << this << " : Constructeur par defaut" << endl ;
}

TVehiculeTerrestre::TVehiculeTerrestre(const TVehiculeTerrestre & oObjetACopier) :
    VitesseActuelle (0),
    Puissance       (0),
    Poids           (0),
    VitesseMaxi     (0)
{
    this->VitesseActuelle   = const_cast<TVehiculeTerrestre &>(oObjetACopier).get_VitesseActuelle() ;
    this->Puissance         = const_cast<TVehiculeTerrestre &>(oObjetACopier).get_Puissance() ;
    this->Poids             = const_cast<TVehiculeTerrestre &>(oObjetACopier).get_Poids() ;
    this->VitesseMaxi       = const_cast<TVehiculeTerrestre &>(oObjetACopier).get_VitesseMaxi() ;

    cout << this << " : Constructeur par recopie (param : " << &oObjetACopier << ")"<< endl ;
}

TVehiculeTerrestre::TVehiculeTerrestre(unsigned int    Puissance,
                    unsigned int    Poids,
                    unsigned int    VitesseMaxi
                    ) :
       VitesseActuelle (0),
       Puissance       (0),
       Poids           (0),
       VitesseMaxi     (0)

{
    this->Puissance         = Puissance ;
    this->Poids             = Poids ;
    this->VitesseMaxi       = VitesseMaxi ;

    cout << this << " : Constructeur avec parametres" << endl ;

}


TVehiculeTerrestre::~TVehiculeTerrestre()
{
    cout << this << " : Destructeur" << endl ;

}

TVehiculeTerrestre & TVehiculeTerrestre::operator=(const TVehiculeTerrestre & oObjetACopier)
{
    if( this != &oObjetACopier )
	{
		this->VitesseActuelle   = const_cast<TVehiculeTerrestre &>(oObjetACopier).get_VitesseActuelle() ;
		this->Puissance         = const_cast<TVehiculeTerrestre &>(oObjetACopier).get_Puissance() ;
		this->Poids             = const_cast<TVehiculeTerrestre &>(oObjetACopier).get_Poids() ;
		this->VitesseMaxi       = const_cast<TVehiculeTerrestre &>(oObjetACopier).get_VitesseMaxi() ;
		cout << this << " : Affectation par l'objet " << &oObjetACopier << endl ;
	}
    return *this ;
}

std::ostream & operator<<(std::ostream &a,const TVehiculeTerrestre &b)
{
    a << "______________________________________________________________" << std::endl ;
    a << "Atributs de l'objet instance de TVehiculeTerrestre (" << &b <<")" << std::endl ;
    a << "Vitesse actuelle :\t" << const_cast<TVehiculeTerrestre &>(b).get_VitesseActuelle() << std::endl  ;
    a << "Puissance :\t\t"      << const_cast<TVehiculeTerrestre &>(b).get_Puissance() << std::endl  ;
    a << "Poids :\t\t\t"        << const_cast<TVehiculeTerrestre &>(b).get_Poids() << std::endl  ;
    a << "Vitesse maximale :\t" << const_cast<TVehiculeTerrestre &>(b).get_VitesseMaxi() << std::endl  ;
    a << std::endl << std::endl ;

    return a;
}

unsigned int    TVehiculeTerrestre::get_VitesseActuelle()
{
    return  this->VitesseActuelle ;
}
unsigned int    TVehiculeTerrestre::get_Puissance()
{
    return  this->Puissance ;
}
unsigned int    TVehiculeTerrestre::get_Poids()
{
    return  this->Poids ;
}
unsigned int    TVehiculeTerrestre::get_VitesseMaxi()
{
    return  this->VitesseMaxi ;
}

void            TVehiculeTerrestre::set_VitesseActuelle(unsigned int VitesseActuelle)
{
    this->VitesseActuelle = VitesseActuelle ;
}
void            TVehiculeTerrestre::set_Puissance(unsigned int Puissance)
{
    this->Puissance = Puissance ;
}
void            TVehiculeTerrestre::set_Poids(unsigned int Poids)
{
    this->Poids = Poids ;
}
void            TVehiculeTerrestre::set_VitesseMaxi(unsigned int VitesseMaxi)
{
    this->VitesseMaxi = VitesseMaxi ;
}

