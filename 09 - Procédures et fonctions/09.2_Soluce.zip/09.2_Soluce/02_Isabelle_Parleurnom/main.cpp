//------------------------------------------------------------------------------
/** @file       main.cpp
* @brief        Programme principal
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019-01-07
* @version      1.0
* @date         2019-01-07
*
* Fabrication   Isabelle_Parleurnom.pro
*
*/
//------------------------------------------------------------------------------

#include <iostream>
#include	"Tricoter.h"

using namespace std;



/** Ce programme demande à l'utilisateur les dimensions de son échantillon de
* tricot. Elles sont exprimées en nombre de mailles (colonnes) et en nombre de
* rangs (lignes) et doivent correspondre à une taille d'échantillon de 10 × 10
* cm.<br/>
* Il demande ensuite à l'utilisateur de choisir le type de calcul à réaliser :<br/>
*<ol><li>Calculer le nombre de maille à faire</li>
*<li>Calculer le nombre de rang à faire</li></ol>
*Il demande ensuite la taille (en cm) à obtenir et appelle la fonction adéquate.<br/>
* Le résultat est affiché finalement !<br/>
* Ce programme travaille en boucle, jusqu'à ce que la valeur 0 est saisie.
*
* @see          CalculerNbreMaille, CalculerNbreRang
*/
int main()
{
    unsigned int    nNbreMailleEchantillon  (0) ;
    unsigned int    nNbreMailleAFaire       (0) ;
    float           fLargeurAFaire          (0.0) ;

    unsigned int    nNbreRangEchantillon    (0) ;
    unsigned int    nNbreRangAFaire         (0) ;
    float           fHauteurAFaire          (0.0) ;

    char            cChoix                  ('\0') ;

    bool            bFin                    (false) ;

    cout << "Saisissez le nombre de mailles obtenu pour 10 cm = " ;
    cin >> nNbreMailleEchantillon ;
    cout << "Saisissez le nombre de rangs obtenu pour 10 cm = " ;
    cin >> nNbreRangEchantillon ;

    do
    {
        cout << "Voulez-vous connaitre un nombre de mailles (1) ou de rangs (2) ? " ;
        cout << endl << "(Tapez 0 pour quitter ce programme !) ";
        cin >> cChoix ;

        switch(cChoix)
        {
            case '0' :  bFin = true ;
                        break ;

            case '1' :
                        cout << "Saisissez la largeur que vous souhaitez obtenir :" ;
                        cin >> fLargeurAFaire ;

                        nNbreMailleAFaire = CalculerNbreMaille(fLargeurAFaire, nNbreMailleEchantillon) ;

                        cout << "Pour obtenir une largeur de " << fLargeurAFaire <<" cm, " ;
                        cout << "il vous faut faire " << nNbreMailleAFaire << " mailles." ;
                        cout << endl ;
                        break ;

            case '2' :
                        cout << "Saisissez la hauteur que vous souhaitez obtenir :" ;
                        cin >> fHauteurAFaire ;

                        nNbreRangAFaire = CalculerNbreRang(fHauteurAFaire, nNbreRangEchantillon) ;

                        cout << "Pour obtenir une hauteur de " << fHauteurAFaire <<" cm, " ;
                        cout << "il vous faut faire " << nNbreRangAFaire << " rangs." ;
                        cout << endl ;
                        break ;
            default :
                        cout << "Je n'ai pas compris votre choix, desole !" << endl ;
        }

	}
	while(!(bFin == true)) ;

    cout << "Au revoir !" << endl ;
    return 0;
}

