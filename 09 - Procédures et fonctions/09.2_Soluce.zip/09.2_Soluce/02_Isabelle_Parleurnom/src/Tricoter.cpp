//------------------------------------------------------------------------------
/** @file       Tricoter.cpp
* @brief        Librairie de gestion des mesures d'échantillons de tricot.
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019-01-07
* @version      1.0
* @date         2019-01-07
*
* Cette bibliothèque propose deux fonctions permettant le calcul automatisé
* du nombre de mailles et/ou de rangs à réaliser pour obtenir un ouvrage à
* la dimension souhaitée, à partir d'un échantillon réalisé à la taille
* 10 × 10 cm.
*
* Fabrication   Isabelle_Parleurnom.pro
*
*/
//------------------------------------------------------------------------------

#include	<math.h>
#include	"Tricoter.h"


/** Fonction de calcul du nombre de mailles à réaliser pour obtenir une largeur
* de tricot précise.<br/>
* Elle utilise simplement une règle de trois.<br/>
*
*
* @param[in]    fLargeurAFaire largeur du tricot que la tricoteuse veut obtenir
*               finalement. Cette donnée est exprimée en cm.
* @param[in]    nNbreMailleEchantillon Nombre de mailles que la tricoteuse a
*               du réaliser pour avoir 10 cm de largeur de tricot.
*
* @return       nNbreMailleAFaire Pour obtenir réellement <code>fLargeurAFaire</code>
*               cm, la tricoteuse devra tricoter ce nombre de mailles !
*
* @note         Le nombre de mailles à tricoter doit être forcément un entier !
*               La fonction va donc retourner l'entier le plus proche du
*               résultat de son calcul, soit en arrondissant à l'inférieur, soit
*               au supérieur.
*
* @see          floor, ceil.
*/
unsigned int CalculerNbreMaille(float fLargeurAFaire, unsigned int nNbreMailleEchantillon)
{
	unsigned int    nNbreMailleAFaire       (0) ;
	float           fNbreMailleReel         (0.0) ;
	float           fDecimales              (0.0) ;

	fNbreMailleReel = (nNbreMailleEchantillon * fLargeurAFaire) / 10.0 ;

	fDecimales = fNbreMailleReel - floor(fNbreMailleReel);
	if (fDecimales< 0.5)
	{
		nNbreMailleAFaire = floor(fNbreMailleReel);
	}
	else
	{
		nNbreMailleAFaire = ceil(fNbreMailleReel);
	}

	return(nNbreMailleAFaire) ;
}

/** Fonction de calcul du nombre de rangs à réaliser pour obtenir une hauteur
* de tricot précise.<br/>
* Elle utilise simplement une règle de trois.<br/>
*
*
* @param[in]    fHauteurAFaire hauteur du tricot que la tricoteuse veut obtenir
*               finalement. Cette donnée est exprimée en cm.
* @param[in]    nNbreRangEchantillon Nombre de rangs que la tricoteuse a
*               du réaliser pour avoir 10 cm de hauteur de tricot.
*
* @return       nNbreRangAFaire Pour obtenir réellement <code>fHauteurAFaire</code>
*               cm, la tricoteuse devra tricoter ce nombre de rangs !
*
* @note         Le nombre de rangs à tricoter doit être forcément un entier !
*               La fonction va donc retourner l'entier le plus proche du
*               résultat de son calcul, soit en arrondissant à l'inférieur, soit
*               au supérieur.
*
* @see          floor, ceil.
*/
unsigned int CalculerNbreRang(float fHauteurAFaire, unsigned int nNbreRangEchantillon)
{
	unsigned int    nNbreRangAFaire       (0) ;
	float           fNbreRangReel         (0.0) ;
	float           fDecimales            (0.0) ;

	fNbreRangReel = (nNbreRangEchantillon * fHauteurAFaire) / 10.0 ;

	fDecimales = fNbreRangReel - floor(fNbreRangReel);
	if (fDecimales< 0.5)
	{
		nNbreRangAFaire = floor(fNbreRangReel);
	}
	else
	{
		nNbreRangAFaire = ceil(fNbreRangReel);
	}

	return(nNbreRangAFaire) ;
}
