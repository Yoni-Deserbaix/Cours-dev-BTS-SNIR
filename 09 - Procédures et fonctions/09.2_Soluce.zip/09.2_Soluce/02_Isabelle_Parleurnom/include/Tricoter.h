// Tricoter.h      1.0       2019-01-07      Ch. Cruzol
#ifndef TRICOTER_H
#define TRICOTER_H

unsigned int CalculerNbreMaille(float fLargeurAFaire, unsigned int nNbreMailleEchantillon) ;
unsigned int CalculerNbreRang(float fHauteurAFaire, unsigned int nNbreRangEchantillon) ;

#endif // TRICOTER_H
