// CalculerDistance.h      1.0       2019-01-07      Ch. Cruzol

#ifndef CALCULERDISTANCE_H
#define CALCULERDISTANCE_H

float   CalculerDistance(float fX1, float fY1, float fX2, float fY2) ;

#endif // CALCULERDISTANCE_H
