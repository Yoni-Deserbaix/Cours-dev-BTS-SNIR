//------------------------------------------------------------------------------
/** @file       Main.cpp
* @brief        Programme principal
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019-01-07
* @version      1.0
* @date         2019-01-07
*
* Amandine Ozaur doit calculer les distances entre plusieurs points de son repère cartésien. Elle
* trouve la méthode très rébarbative et souhaiterait que vous lui fassiez un programme pour
* l’optimiser. Amandine voudrait pouvoir saisir les coordonnées des deux points concerné, (X1,Y1)
* et (X2,Y2) et que le programme lui calcule cette satanée distance ! Seul impératif : utiliser une
* procédure ou une fonction de façon à avoir un module logiciel réutilisable.*
* Fabrication   Amandine_Ozaur.pro
*
*/
//------------------------------------------------------------------------------

#include <iostream>
#include "CalculerDistance.h"

using namespace std;



/** Programme permettant la saisie des coordonnées cartésienne de deux points.
* Il calcule ensuite la distance entre ces deux points en appelant une fonction
* et affiche le résultat !
*
*/
int main()
{

    float   fX1   (0.0) ;
    float   fY1   (0.0) ;
    float   fX2   (0.0) ;
    float   fY2   (0.0) ;
    float   fDistance   (0.0) ;

    cout << "Saisissez la coordonne X1 = " ;
    cin >> fX1 ;
    cout << "Saisissez la coordonne Y1 = " ;
    cin >> fY1 ;
    cout << "Saisissez la coordonne X2 = " ;
    cin >> fX2 ;
    cout << "Saisissez la coordonne Y2 = " ;
    cin >> fY2 ;

    fDistance = CalculerDistance(fX1, fY1, fX2, fY2) ;

    cout << "La distance entre le point 1 (" << fX1 << "," << fY1 << ")" ;
    cout << " et le point 2 (" << fX2 << "," << fY2 << ")" ;
    cout << " est de " << fDistance << endl;

    return 0;
}

