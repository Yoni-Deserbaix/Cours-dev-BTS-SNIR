//------------------------------------------------------------------------------
/** @file       CalculerDistance.cpp
* @brief        Librairie de gestion de coordonnées cartésienne de points.
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019-01-07
* @version      1.0
* @date         2019-01-07
*
* Elle propose seulement une fonction : CalculerDistance.
*
* Fabrication   Amandine_Ozaur.pro
*
* @see          CalculerDistance
*/
//------------------------------------------------------------------------------
#include	<math.h>
#include	"CalculerDistance.h"

/** Fonction de calcul de la distance entre deux points repérés sur un plan
* au moyen de leurs coordonnées cartésiennes.<br/>
* Elle utilise le théorème de Pytagore sur la longueur de l'hypoténuse d'un
* triangle rectangle. Pour ça, elle fait intervenir la fonction <code>sqrt</code>
* déclarée dans <code>math.h</code>
*
* @param[in]    fX1 abscisse du premier point
* @param[in]    fY1 ordonnée du premier point
* @param[in]    fX2 abscisse du second point
* @param[in]    fY2 ordonnée du second point
*
* @return       fDistance La distance entre les deux points renseignés en
*               paramètres
*
* @note         Il n'est pas essentiel de connaître l'unité des coordonnées
*               fournies… ce peut être des cm, de kilomètres, des pixels…
* @note         Il n'est pas important d'ordonner les points : la formule
*               utilisant une mise au carré,
*               <code>(fX2-fX1)*(fX2-fX1) = (fX1-fX2)*(fX1-fX2)</code> !
*
* @see          sqrt
*/
float   CalculerDistance(float fX1, float fY1, float fX2, float fY2)
{
	float   fDistance   (0.0) ;

	fDistance = sqrt(((fX2-fX1)*(fX2-fX1)) + ((fY2-fY1)*(fY2-fY1) )) ;

	return(fDistance) ;
}
