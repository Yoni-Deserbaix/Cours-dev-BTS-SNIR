//------------------------------------------------------------------------------
/** @file       main.cpp
* @brief        Programme principal
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019-01-07
* @version      1.0
* @date         2019-01-07
*
* Monsieur Kiroul, ingénieur du son, doit faire une centaine de mesures sonores
* en divers emplacements d’une salle de spectacle, visualiser l’ensemble des
* données, puis en rechercher la valeur la plus petite, la valeur la plus grande
* et faire une moyenne de toutes les valeurs. Pierre, de son prénom, requiert
* votre aide pour l’aider dans son travail, ou du moins, pour lui proposer un
* programme qui serait facile à utiliser. Votre exceptionnelle maîtrise
* algorithmique vous pousse à découper ce programme complexe en procédures ou
* fonctions :
* <ul><li>une pour initialiser la totalité du tableau à la valeur 0 ;</li>
* <li>une pour réaliser la saisie d’une seule valeur sonore (ici, simulée et
* générée aléatoirement entre 20 et 150) ;</li>
* <li>une pour afficher l’ensemble des acquisitions ;</li>
* <li>une pour rechercher la plus petite valeur ;</li>
* <li>une pour la plus grande ;</li>
* <li>une dernière pour calculer la moyenne globale.</li></ul>
* N’oubliez pas que Pierre doit se déplacer entre deux mesures et qu’il doit
* lui-même déclencher l’acquisition.
*
* Fabrication   Pierre_Kiroul.pro
*
*/
//------------------------------------------------------------------------------

#include    <iostream>  // cout, cin
#include    <conio.h>   // getch
#include    <stdlib.h>  // srand, rand
#include    <time.h>    // time
#include    "GererTab1D.h"

using namespace std;

/** Ce programme permet à Pierre la saisie d'une centaine de mesures sonores
* dans une salle de spectacle.<br/>
* Il commence par initialiser le tableau de mesure à <code>0</code>.<br/>
* On passe alor à la série de la centaine d'acquisition (appel de la fonction
* <code>AcquerirUneMesureSonore</code>) sur un appui de touche, et valide
* l'aquisition.<br/>
* Lorsque les 100 mesures ont été prises, les emplacements de la mesure la plus
* faible et la plus puisante sont recherchés (au moyen des fonctions
* <code>RechercherEmplacementPlusPetit1D</code> et
* <code>RechercherEmplacementPlusGrand1D</code>) puis affichés.<br/>
* Pour avoir une bonne idée de la répartition des mesures sonores, la moyenne
* est indiquée à Pierre.
*
* @see          InitialiserTableau1D, AcquerirUneMesureSonore, AfficherTableau1D,
*               RechercherEmplacementPlusPetit1D, RechercherEmplacementPlusGrand1D,
*               CalculerMoyenne1D
*/
int main()
{
    float           fMesuresSonores[10] ;
    unsigned int    nNbreDeMesures      (10) ;      // 10 mesures pour les tests !
    unsigned int    nEmplacementMinimum (0.0) ;
    unsigned int    nEmplacementMaximum (0.0) ;
    float           fMoyenne            (0.0) ;
    bool            bAcquisition        (false) ;

    // srand(time(NULL)) ; // Génère des warnings
    // srand(static_cast<unsigned int>(time(nullptr))) ;
    srand(2001) ;

    InitialiserTableau1D(fMesuresSonores, nNbreDeMesures, 0) ;

    for(unsigned int i = 0; i < nNbreDeMesures ; i++)
    {
        cout << "Appuyez sur une touche pour realiser l'acquisition numero " ;
        cout << i+1 << "..." << endl ;
        getch() ;

        do
        {
            bAcquisition = AcquerirUneMesureSonore(i,
                                                   fMesuresSonores,
                                                   nNbreDeMesures) ;
            if(bAcquisition == false)
            {
                cout << "ARRGGG ! Acquisition impossible !" << endl ;
            }
        }
        while(!(bAcquisition == true)) ;
    }
    AfficherTableau1D(fMesuresSonores, nNbreDeMesures) ;

    nEmplacementMinimum = RechercherEmplacementPlusPetit1D(fMesuresSonores, nNbreDeMesures) ;
    cout << "l'emplacement de la plus petite mesure : " << nEmplacementMinimum+1 << endl ;

    nEmplacementMaximum = RechercherEmplacementPlusGrand1D(fMesuresSonores, nNbreDeMesures) ;
    cout << "l'emplacement de la plus grande mesure : " << nEmplacementMaximum+1 << endl ;

    fMoyenne = CalculerMoyenne1D(fMesuresSonores, nNbreDeMesures) ;
    cout << "la moyenne de toutes les mesures : " << fMoyenne << endl ;

    return 0;
}

