// GererTab1D.h      1.0       2019-01-07      Ch. Cruzol
#ifndef GERERTAB1D_H
#define GERERTAB1D_H

void    InitialiserTableau1D    (float fTab1D[],
                                 unsigned int nNbreDeCases,
                                 float fValeurInitiale) ;

void    AfficherTableau1D       (const float fTab1D[],
                                unsigned int nNbreDeCases) ;

bool    AcquerirUneMesureSonore (unsigned int nNumCase,
                                float fTab1D[],
                                unsigned int nNbreDeCases) ;

float   RechercherPlusPetit1D   (const float fTab1D[],
                                unsigned int nNbreDeCases) ;

unsigned int     RechercherEmplacementPlusPetit1D   (const float fTab1D[],
                                unsigned int nNbreDeCases) ;

float   RechercherPlusGrand1D   (const float fTab1D[],
                                unsigned int nNbreDeCases) ;

unsigned int     RechercherEmplacementPlusGrand1D   (const float fTab1D[],
                                unsigned int nNbreDeCases) ;

float   CalculerMoyenne1D       (const float fTab1D[],
                                unsigned int nNbreDeCases) ;

#endif // GERERTAB1D_H
