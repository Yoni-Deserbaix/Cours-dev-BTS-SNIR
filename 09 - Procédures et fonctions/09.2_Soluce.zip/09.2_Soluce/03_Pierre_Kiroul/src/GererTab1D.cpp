//------------------------------------------------------------------------------
/** @file       GererTab1D.cpp
 * @brief       Bibliothèque de gestion d'un tableau 1D.
 *
 * @author      Ch. Cruzol
 * @author      STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
 * @since       2019-01-07
 * @version     1.0
 * @date        2019-01-07
 *
 * Cette bibliothèque propose les procédures et fonctions d'initialisation d'un
 * tableau à une dimension, d'affichage, de recherche de la plus petite et plus
 * grande valeur contenue dans ce tableau, et aussi du calcul de la moyenne des
 * valeurs.
 *
 * Fabrication   Pierre_Kiroul.pro
 *
 */
//------------------------------------------------------------------------------
#include    <iostream>  // cout
#include    <stdlib.h>  // srand, rand
#include    <time.h>    // time
#include    "GererTab1D.h"

using namespace std;

/** Procédure d'initailisation de chaque case d'un tableau à 1 dimension à une
 * valeur (unique et identique pour chaque case).
 *
 * @pre          Le tableau passé en paramètre est correctement créé et la taille
 *               fournie sont cohérents et associés !
 * @post         Le tableau est initialisé à la valeur désirée !
 *
 * @param[in]    nNbreDeCases Indique le nombre de case total du tableau à
 *               initialiser.
 * @param[in]    fValeurInitiale Valeur à utiliser pour initialiser chaque case
 *               du tableau.
 * @param[out]   fTab1D le tableau dont on veut initialiser toutes les cases à la
 *               valeur <code>fValeurInitiale</code>.
 *
 * @note         Cette procédure ne gère pas les erreurs du programme appelant…
 *               il est tenu de respecter les passages de paramètres : le tableau
 *               founi et la taille doivent être conformes !
 */
void InitialiserTableau1D(float fTab1D[],
                          unsigned int nNbreDeCases,
                          float fValeurInitiale)
{
    for(unsigned int i = 0; i < nNbreDeCases; i++)
    {
        fTab1D[i] = fValeurInitiale ;
    }
}

/** Affichage d'un tableau 1D !
 *
 * @param[in]    fTab1D Le tableau à afficher…
 * @param[in]    nNbreDeCases Le nombre de case constituant le tableau.
 *
 * @note         Cette procédure fait partie des méthodes IHM : elle ne fait
 *               aucun traitement hormis de l'affiche, ce n'est donc pas une
 *               procédure métier !
 */
void AfficherTableau1D(const float fTab1D[],
                       unsigned int nNbreDeCases)
{
    for(unsigned int i = 0; i < nNbreDeCases; i++)
    {
        cout << fTab1D[i] ;
        if(i != nNbreDeCases-1)
        {
            cout << ", " ;
        }
        else
        {
            cout << endl ;
        }
    }
    cout << endl ;
}

/** Fonction d'acquisition de la mesure sonore. Elle permet de lire sur le port
 * d'entrée/sortie matérielle du CAN la valeur du niveau sonore. Ces valeurs
 * sont comprises entre 20 et 150 dB.<br/>
 * La valeur acquise est placée dans le tableau de sauvegarde à la place
 * désignée. Si cette emplacement est déjà occupé par une autre donnée,
 * l'acquisition n'est pas prose en compte et elle est perdue.
 *
 * @param[in]   nNumCase Numéro de la case du tableau qui va recevoir la valeur
 *              du niveau sonore.
 * @param[in]   nNbreDeCases Nombre de cases total du tableau.
 * @param[out]  fTab1D Tableau de stockage des acquisitions sonores.
 *
 * @return      La valeur <code>true</code> dans le cas où l'acquisition a
 *              été sauvegardée dans le tableau et <code>false</code> dans les
 *              autres cas (emplacement déjà occupé, emplacement sortant des
 *              bornes du tableau…)
 *
 * @note         N'ayant pas, pour ce TP de carte d'acquisition, les mesures sont
 *               simulées par un générateur aléatoire, tirant au hasard des
 *               valeurs de type réel comprises entre 20 et 150.
 *
 * @see          rand
 */
bool AcquerirUneMesureSonore(unsigned int nNumCase,
                             float fTab1D[],
                             unsigned int nNbreDeCases)
{
    float   fMin            (20.0) ;
    float   fMax            (150.0) ;
    bool    bAcquisition    (false) ;

    if((nNumCase < nNbreDeCases)
       && (fTab1D[nNumCase] == 0.0)
       && (nNbreDeCases >= 1))
    {
        fTab1D[nNumCase] = (rand() % static_cast<int>((fMax - fMin)*100.0) + fMin*100.0)/100.0 ;
        bAcquisition = true ;
    }

    return(bAcquisition) ;
}

/** Recherche de la plus petite valeur contenue dans un tableau.
 *
 * @pre         Le tableau est défini est rempli !
 *
 * @param[in]   fTab1D Tableau à scruter pour trouver sa plus petite valeur.
 * @param[in]   nNbreDeCases Nombre de cases total de ce tableau.
 *
 * @return      La plus petite valeur contenue par le tableau.
 */
float RechercherPlusPetit1D(const float fTab1D[], unsigned int nNbreDeCases)
{
    float    fPlusPetit  (0.0) ;

    if (nNbreDeCases >= 1)
    {
        fPlusPetit = fTab1D[0] ;

        for(unsigned int i = 1; i < nNbreDeCases; i++)
        {
            if(fTab1D[i] < fPlusPetit)
            {
                fPlusPetit = fTab1D[i] ;
            }
        }
    }

    return (fPlusPetit) ;
}

/** Recherche de l'emplacement de la plus petite valeur contenue dans un tableau.
 *
 * @pre         Le tableau est défini est rempli !
 *
 * @param[in]   fTab1D Tableau à scruter pour trouver sa plus petite valeur.
 * @param[in]   nNbreDeCases Nombre de cases total de ce tableau.
 *
 * @return      L'emplacement de la plus petite valeur contenue par le tableau
 *              ou -1 si le tableau n'a pas une taille suffisante.
 */
unsigned int RechercherEmplacementPlusPetit1D(const float fTab1D[], unsigned int nNbreDeCases)
{
    float           fPlusPetit  (0.0) ;
    unsigned int    nPlace      (-1) ;

    if (nNbreDeCases >= 1)
    {
        fPlusPetit = fTab1D[0] ;

        for(unsigned int i = 1; i < nNbreDeCases; i++)
        {
            if(fTab1D[i] < fPlusPetit)
            {
                fPlusPetit = fTab1D[i] ;
                nPlace = i ;
            }
        }
    }

    return (nPlace) ;
}

/** Recherche de la plus grande valeur contenue dans un tableau.
 *
 * @pre          Le tableau est défini est rempli !
 *
 * @param[in]   fTab1D Tableau à scruter pour trouver sa plus petite valeur.
 * @param[in]   nNbreDeCases Nombre de cases total de ce tableau.
 *
 * @return      La plus grande valeur contenue par le tableau.
 */
float RechercherPlusGrand1D(const float fTab1D[], unsigned int nNbreDeCases)
{
    float    fPlusGrand  (0.0) ;

    if (nNbreDeCases >= 1)
    {
        fPlusGrand = fTab1D[0] ;

        for(unsigned int i = 1; i < nNbreDeCases; i++)
        {
            if(fPlusGrand < fTab1D[i])
            {
                fPlusGrand = fTab1D[i] ;
            }
        }
    }

    return (fPlusGrand) ;
}

/** Recherche de l'emplacement de la plus grande valeur contenue dans un tableau.
 *
 * @pre          Le tableau est défini est rempli !
 *
 * @param[in]   fTab1D Tableau à scruter pour trouver sa plus petite valeur.
 * @param[in]   nNbreDeCases Nombre de cases total de ce tableau.
 *
 * @return      La plus grande valeur contenue par le tableau.
 */
unsigned int RechercherEmplacementPlusGrand1D(const float fTab1D[], unsigned int nNbreDeCases)
{
    float           fPlusGrand  (0.0) ;
    unsigned int    nPlace      (-1) ;

    if (nNbreDeCases >= 1)
    {
        fPlusGrand = fTab1D[0] ;

        for(unsigned int i = 1; i < nNbreDeCases; i++)
        {
            if(fPlusGrand < fTab1D[i])
            {
                fPlusGrand = fTab1D[i] ;
                nPlace = i ;
            }
        }
    }

    return (nPlace) ;
}


/** Calcul de la moyenne de toutes les valeurs contenues dans un tableau.
 *
 * @pre          Le tableau est défini est rempli !
 *
 * @param[in]   fTab1D Tableau à scruter pour trouver sa plus petite valeur.
 * @param[in]   nNbreDeCases Nombre de cases total de ce tableau.
 *
 * @return       La moyenne de toutes les valeurs contenues dans ce tableau
 *
 */
float CalculerMoyenne1D(const float fTab1D[], unsigned int nNbreDeCases)
{
    float   fMoyenne    (0.0) ;
    float   fSomme      (0.0) ;

    for(unsigned int i = 1; i < nNbreDeCases; i++)
    {
        fSomme = fSomme + fTab1D[i] ;
    }
    fMoyenne = fSomme / static_cast<float>(nNbreDeCases) ;

    return (fMoyenne) ;
}

