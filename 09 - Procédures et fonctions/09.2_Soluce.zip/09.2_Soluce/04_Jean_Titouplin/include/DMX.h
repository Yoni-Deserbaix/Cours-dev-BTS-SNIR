// DMX.h      1.0       2019-01-07      Ch. Cruzol

#ifndef DMX_H
#define DMX_H

/** @struct _TDMX
 *  @brief _TDMX est une structure permettant de stocker une couleur RVB selon
 *          ses composantes RVB, ainsi que l'intensité de la liminosité du
 *          spot.
 */
/** @typedef    TDMX
*  @brief       Redéfinition du type (@ref _TDMX)
*/
typedef struct  _TDMX {
    unsigned char   nR ;         ///Composante Rouge de la couleur RVB
    unsigned char   nV ;         ///Composante Verte de la couleur RVB
    unsigned char   nB ;         ///Composante Bleu de la couleur RVB
    unsigned char   nIntensite ; ///Intensité de la luminosité
} TDMX ;

void    InitialiserDMX          (TDMX * stDMX) ;
void    InitialiserDMX          (TDMX & stDMX) ;

void    AfficherDMX             (TDMX stDMX) ;

void    SaisirDMX               (TDMX * stDMX) ;
void    SaisirDMX               (TDMX & stDMX) ;

#endif // DMX_H
