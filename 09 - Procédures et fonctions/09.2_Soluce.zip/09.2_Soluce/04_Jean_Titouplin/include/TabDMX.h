// TabDMX.h      1.0       2019-01-07      Ch. Cruzol

#ifndef TabDMX_H
#define TabDMX_H

#include    <DMX.h>

void    InitialiserTableauDMX   (TDMX nTab1D[],
                                 unsigned int nNbreDeCases) ;

void    AfficherScenettes       (const TDMX nTab1D[],
                                 unsigned int nNbreDeCases,
                                 unsigned int nDureeScenette) ;

bool    EnregistrerUneScenette  (TDMX UneScenette,
                                 unsigned int nNumeroScenette,
                                 TDMX nTab1D[],
                                 unsigned int nNbreDeCases) ;

#endif // TabDMX_H
