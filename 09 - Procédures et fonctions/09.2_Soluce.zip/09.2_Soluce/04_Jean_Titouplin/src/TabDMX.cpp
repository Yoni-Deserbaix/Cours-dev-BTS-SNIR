//------------------------------------------------------------------------------
/** @file       DMX.cpp
 * @brie        <Description rapide du fichier>
 *
 * @author       Ch. Cruzol
 * @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
 * @since        2019-01-07
 * @version      1.0
 * @date         2019-01-07
 *
 * Description détaillée du fichier
 *
 * Fabrication   Jean_Titouplin.pro
 *
 */
//------------------------------------------------------------------------------
#include    <iostream>      // cout
#include    <windows.h>     // Sleep
#include    "DMX.h"

using namespace std ;

/** Cette procédure intialise un tableau dont chaque case est de type structuré.
 *  La façon la plus simple est d'appeler la procédure qui inititalise un
 *  élément, <code>InitialiserDMX</code> !
 *
 * @param[in]   nNbreDeCases    Nombre de case total du tableau à initialiser !
 * @param[out]  nTab1D          Le tableau, créé par le module appelant, qu'il
 *              faut initialiser.
 *
 * @note        Ce module n'est pas responsable des erreurs d'appel : tableau
 *              non conforme à la taille passée, non créé dynamiquement…
*/
void InitialiserTableauDMX(TDMX nTab1D[], unsigned int nNbreDeCases)
{
    for(unsigned int i = 0; i < nNbreDeCases; i++)
    {
        //InitialiserDMX(&nTab1D[i]) ;    // Par adresse
        InitialiserDMX(nTab1D[i]) ;    // Par référence
    }

}

/** Cette procédure affiche les scénettes (leur configuration) directement sous
 *  la forme du tableau qui les mémorise. Chaque scénette est affichée
 *  périodiquement en fonctionde la durée de chaque scénette, soit toute en
 *  secondes, soit en minutes.
 *
 * @param[in]    nTab1D Le tableau contenant les scénettes. Bien que passé par
 *              adresse (on n'a pas le choix pour un tableau !) ce dernier ne
 *              sera pas modifié par ce module !
 * @param[in]   nNbreDeCases    La taille du tableau, soit le nombre de scénettes.
 * @param[in]   nDureeScenette  Durée d'une scénette exprimée en untité de base !
 *
*/
void AfficherScenettes(const TDMX nTab1D[],
                       unsigned int nNbreDeCases,
                       unsigned int nDureeScenette)
{
    const   unsigned int    SECONDE             (1000) ;
    const   unsigned int    MINUTE              (SECONDE * 60) ;
            unsigned int    nUniteTemporelle    (SECONDE) ;

    for(unsigned int i = 0; i < nNbreDeCases; i++)
    {
        AfficherDMX(nTab1D[i]) ;
        cout << "\07" << endl ;
        Sleep(nDureeScenette * nUniteTemporelle) ;
    }

}

/** Description détaillée de la méthode
 *
 * @pre          <Description des préconditions nécessaires à la méthode>
 * @post         <Description des postconditions nécessaires à la méthode>
 *
 * @param        <Liste des paramètres de la méthode et de leur rôle>
 * @param[in]    <Liste des paramètres qui ne sont qu'en lecture dans la méthode et de leur rôle>
 * @param[out]   <Liste des paramètres qui seront modifiés par de la méthode et de leur rôle>
 *
 * @retval       <Valeurs retournées dans les paramètres>
 * @return       <Explication de la valeur de retour de la fonction>
 *
 * @test         <Explication de la procédure de test ouréférence à la fiche de test associée.>
 *
 * @see          <Liste des autres méthodes et attributsutilisés par la méthode>
*/
bool EnregistrerUneScenette(TDMX UneScenette, unsigned int nNumeroScenette,
                            TDMX nTab1D[], unsigned int nNbreDeCases)
{
    bool            bEnregistrement    (false) ;

    nNumeroScenette -= 1 ;

    if(nNumeroScenette < nNbreDeCases)
    {
        nTab1D[nNumeroScenette].nR         = UneScenette.nR ;
        nTab1D[nNumeroScenette].nV         = UneScenette.nV ;
        nTab1D[nNumeroScenette].nB         = UneScenette.nB ;
        nTab1D[nNumeroScenette].nIntensite = UneScenette.nIntensite ;
        bEnregistrement = true ;
    }

    return(bEnregistrement) ;
}
