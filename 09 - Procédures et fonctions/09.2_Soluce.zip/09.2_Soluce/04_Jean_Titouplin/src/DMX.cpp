//------------------------------------------------------------------------------
/** @file       DMX.cpp
 * @brie        <Description rapide du fichier>
 *
 * @author       Ch. Cruzol
 * @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
 * @since        2019-01-07
 * @version      1.0
 * @date         2019-01-07
 *
 * Description détaillée du fichier
 *
 * Fabrication   Jean_Titouplin.pro
 *
 */
//------------------------------------------------------------------------------
#include    <iostream>      // cout
#include    "DMX.h"

using namespace std ;


/** Cette procédure permet d'initialiser un élémént de type stucturé TDMX aux
 *  valeurs 0, par défaut.
 *
 * @param[out]  stDMX  un élément de type structuré dont chaque champ va être
 *              placé à la valeur 0. Le paramètre réel, passé en paramètre par
 *              adresse sera modifié par cette procédure !
 *
 * @note        Remarquez l'utilisation de l'opérateur *, des paremthèses et
 *              du point pour accéder à chaque champ de la structure !
*/
void    InitialiserDMX(TDMX * stDMX)
{
    (*stDMX).nR            = 0 ;
    (*stDMX).nV            = 0 ;
    (*stDMX).nB            = 0 ;
    (*stDMX).nIntensite    = 0 ;
}
void    InitialiserDMX(TDMX & stDMX)    // La même avec passage par référence
{
    stDMX.nR            = 0 ;
    stDMX.nV            = 0 ;
    stDMX.nB            = 0 ;
    stDMX.nIntensite    = 0 ;
}

/** Cette procédure affiche les champs de l'élément structuré de type TDMX passé
 *  en paramètre.
 *
 * @param[in]   stDMX  Un élément structuré de type TDMX. Chacun de ses champs
 *              sera affiché.
 *
 * @note        Remarquez l'utilisation de l'opérateur point pour accéder à
 *              chaque champ de la structure !
 * @note        L'utilisation du transtypage forcé <code>(int)</code> n'est
 *              pas nécessaire, mais indispensable… pour le fun !
*/
void    AfficherDMX(TDMX stDMX)
{
    cout << "Couleur : (" << static_cast<int>(stDMX.nR) << ", " ;
    cout << static_cast<int>(stDMX.nV) << ", " ;
    cout << static_cast<int>(stDMX.nB) << ")" ;
    cout << "\tIntensite : " << static_cast<int>(stDMX.nIntensite) << endl ;
}

/** Cette procédure réalise la saisie des données permettant de remplir un
 *  élément structuré de type TDMX soit au clavier, soit automatiquement.
 *
 * @param[out]  stDMX   L'élémént structuré qui doit recevoir les données
 *              saisies. Le paramètre réel, passé en paramètre par
 *              adresse sera modifié par cette procédure !
 *
 * @note        La variable statique nNumero garde sa valeur d'un appel de la
 *              procédure à un autre. Le premier appel initialise sa valeur à
 *              0 puis l'algo l'incrémente de 1. L'appel suivant va donc
 *              récupérer la dernière valeur qui lui a été donnée (1) puis
 *              l'utilise en l'incrémentant à son tour (2). Au troisième appel,
 *              Une variable déclarée <code>static</code> garde sa valeur entre
 *              deux appel du module qui la déclare !
 */
void    SaisirDMX(TDMX * stDMX)
{
            bool            bSaisieAutomatique  (false) ;
    static  unsigned int    nNumero (0) ;

    if(bSaisieAutomatique == false)
    {
        cout << "Veuillez saisir la composante ROUGE pour la scenette : " ;
        do
        {
            cin >> nNumero ;
        } while(!(  nNumero <= 255  )) ;
        (*stDMX).nR = static_cast<unsigned char>(nNumero) ;

        cout << "Veuillez saisir la composante VERTE pour la scenette : " ;
        do
        {
            cin >> nNumero ;
        } while(!(  nNumero <= 255  )) ;
        (*stDMX).nV = static_cast<unsigned char>(nNumero) ;

        cout << "Veuillez saisir la composante BLEUE pour la scenette : " ;
        do
        {
            cin >> nNumero ;
        } while(!(  nNumero <= 255  )) ;
        (*stDMX).nB = static_cast<unsigned char>(nNumero) ;

        cout << "Veuillez saisir l'intensité pour la scenette : " ;
        do
        {
            cin >> nNumero ;
        } while(!(  nNumero <= 255  )) ;
        (*stDMX).nIntensite = static_cast<unsigned char>(nNumero) ;

    }
    else
    {
        cout << "Mode automatique" << endl ;
        nNumero++ ;
        (*stDMX).nR            = nNumero ;
        (*stDMX).nV            = nNumero ;
        (*stDMX).nB            = nNumero ;
        (*stDMX).nIntensite    = nNumero ;
    }
}
void    SaisirDMX(TDMX & stDMX)         // La même avec passage par référence
{
            bool            bSaisieAutomatique  (false) ;
    static  unsigned int    nNumero (0) ;

    if(bSaisieAutomatique == false)
    {
        cout << "Veuillez saisir la composante ROUGE pour la scenette : " ;
        do
        {
            cin >> nNumero ;
        } while(!(  nNumero <= 255  )) ;
        stDMX.nR = static_cast<unsigned char>(nNumero) ;

        cout << "Veuillez saisir la composante VERTE pour la scenette : " ;
        do
        {
            cin >> nNumero ;
        } while(!(  nNumero <= 255  )) ;
        stDMX.nV = static_cast<unsigned char>(nNumero) ;

        cout << "Veuillez saisir la composante BLEUE pour la scenette : " ;
        do
        {
            cin >> nNumero ;
        } while(!(  nNumero <= 255  )) ;
        stDMX.nB = static_cast<unsigned char>(nNumero) ;

        cout << "Veuillez saisir l'intensité pour la scenette : " ;
        do
        {
            cin >> nNumero ;
        } while(!(  nNumero <= 255  )) ;
        stDMX.nIntensite = static_cast<unsigned char>(nNumero) ;
    }
    else
    {
        cout << "Mode automatique" << endl ;
        nNumero++ ;
        stDMX.nR            = nNumero ;
        stDMX.nV            = nNumero ;
        stDMX.nB            = nNumero ;
        stDMX.nIntensite    = nNumero ;
    }
}
