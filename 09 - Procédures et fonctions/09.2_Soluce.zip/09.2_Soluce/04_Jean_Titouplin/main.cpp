//------------------------------------------------------------------------------
/** @file        main.cpp
 * @brief        Programme principal
 *
 * @author       Ch. Cruzol
 * @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
 * @since        2019-01-07
 * @version      1.0
 * @date         2019-01-07
 *
 * Fabrication   Jean_Titouplin.pro
 *
 */
//------------------------------------------------------------------------------

#include    <iostream>      // cout
#include    <conio.h>       // getch
#include    <windows.h>     // Sleep
#include    "DMX.h"
#include    "TabDMX.h"

using namespace std ;


/** Programme principal… servant seulement ici pour les tests !
 *
*/
int main()
{
    unsigned int   nDureeSpectacle      (30) ;
    unsigned int   nDureeScenette       (5) ;
    unsigned int   nNbreScenettes       (nDureeSpectacle/nDureeScenette) ;
    bool           bEnregistrementOK    (false) ;

    TDMX    UneScenette ;
    TDMX    tabCouleurScenette[6] ;

    InitialiserTableauDMX(tabCouleurScenette, nNbreScenettes) ;

    for(unsigned int nNumeroScenette=1; nNumeroScenette <= nNbreScenettes ; nNumeroScenette++)
    {
        cout << "Programmation de la scenette numero " << nNumeroScenette << " : " << endl ;

        do
		{
			//SaisirDMX(&UneScenette) ;       // Par adresse
			SaisirDMX(UneScenette) ;        // Par référence
            bEnregistrementOK = EnregistrerUneScenette(UneScenette,
                                                       nNumeroScenette,
                                                       tabCouleurScenette,
                                                       nNbreScenettes) ;
		}
		while(!(	bEnregistrementOK	)) ;
		
    }

    cout << "Appuyez sur une touche pour lancer le spectacle..." ;
    getch() ;           // Ou system("PAUSE") ;
    system("CLS") ;

    AfficherScenettes(tabCouleurScenette, nNbreScenettes, nDureeScenette) ;

    cout << "Ca vous a plu ???" << endl ;
    return 0;
}

