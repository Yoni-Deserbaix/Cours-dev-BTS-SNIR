//------------------------------------------------------------------------------
/** @file       Factorielle.cpp
* @brief        Fonction de calcul de la factorielle d'un nombre
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019/01/03
* @version      1.0
* @date         2019/01/03
*
* Fabrication   Phil_Trahuile.pro
*
*/
//------------------------------------------------------------------------------

#include "Factorielle.h"

/** Cette fonction doit calculer la factorielle du nombre passé en paramètre.
*   Le passage s'effectue par valeur puisque le paramètre réel ne doit pas être
*   modifié par le traitement de la fonction.
*
* @param       wValeurFormel contient le nombre duquel on recherche la factorielle
*
* @return      Le résultat du calcul de la factorielle !
*
* @note        Le type de la valeur de retour (<code>int</code>) nous limite dans
*              le calcul de la factorielle. Par exemple <code>Factorielle(18)</code>
*              ne retourne pas un résultat cohérent, car la valeur dépasse la
*              capacité maximale de gestion d'un entier !
*/
unsigned int Factorielle(unsigned int wValeurFormel)
{
	unsigned int wRetour (0) ;

	wRetour = 1 ;
	for(unsigned int i = 2 ; i <= wValeurFormel ; i++)
	{
		wRetour = wRetour * i ;
	}

	return wRetour ;
}
