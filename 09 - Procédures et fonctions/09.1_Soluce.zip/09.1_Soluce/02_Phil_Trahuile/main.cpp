//------------------------------------------------------------------------------
/** @file       main.cpp
* @brief        Programme principal
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019/01/03
* @version      1.0
* @date         2019/01/03
*
* Phil Trahuile, le joueur de tiercé du TP qui va avec, n’est pas satisfait du programme que vous
* lui avez développé : Il trouve que le programme a trop de ligne de codes qui se répètent ! Le
* calcul de factorielle notamment. Reprenez cet exercice et faites-lui une version utilisant une
* procédure/fonction <code>Factorielle(…)</code> de votre cru !
*
* Fabrication   Phil_Trahuile.pro
*
*/
//------------------------------------------------------------------------------

#include <iostream>
#include "Factorielle.h"
using namespace std ;



int main()
{
    unsigned int	wValeurReel		(0) ;
    unsigned int	wC              (0) ;
    unsigned int	wJ              (0) ;
    unsigned int	wChance         (0) ;
    unsigned int	wFactorielle	(0) ;

    // Test de la fonction !
    cout << "Saisissez la valeur dont vous voulez calculer la factorielle : " ;
	cin >> wValeurReel ;

	cout << "Attention ! Je vais calculer la factorielle de " << wValeurReel ;
	cout << " !" << endl << endl ;

	/* Notez l'affectation de la variable wFactorielle par le résultat
	*  de l'appel de la fonction Factorielle()
	*/
	wFactorielle = Factorielle(wValeurReel) ;

    cout << "Tadaaaah... voici le resultat de mon travail : " ;
	cout << wValeurReel << "! = " << wFactorielle << endl ;

    cout << "Et maintenant, les choses serieuses !!!" << endl << endl ;

    // Le programme pour Phil Trahuile
    cout << "Combien y-a-t'il de chevaux au depart de la course ?" ;
    cin >> wC ;

    do
    {
        cout << "Combien de chevaux avez-vous joues ?" << endl ;
        cin >> wJ ;

        if(wJ > wC)
        {
            cout <<  "Vous ne pouvez pas parier sur " ;
            cout <<  wJ ;
            cout <<  " chevaux, alors qu'il n'y en a que " ;
            cout <<  wC ;
            cout <<  " au depart !" << endl ;
            cout <<  "Banane !" << endl ;
        }
        else
        {
            if(wJ < 3)
            {
                cout <<  "Vous ne pouvez pas parier sur un tierce de moins de 3 chevaux !" << endl ;
                cout <<  "Banane !" << endl ;
            }
        }
    }
    while(!(  (wJ >= 3) && ( wJ <= wC)  )) ;

    wChance = Factorielle(wC) / Factorielle(wC-wJ) ;
    cout << endl << "Vos chances de gagner ce tierce dans l'ordre sont d'une contre " ;
    cout << wChance << endl ;;

    wChance = Factorielle(wC) / (Factorielle(wJ) * Factorielle(wC-wJ)) ;
    cout << "et de le gagner dans le desordre sont d'une contre " ;
    cout << wChance << endl ;



	return 0 ;
}
