// Factorielle.h      1.0       2019/01/03      Ch. Cruzol
#ifndef FACTORIELLE_H
#define FACTORIELLE_H


unsigned int Factorielle(unsigned int wValeurFormel) ;

#endif // FACTORIELLE_H
