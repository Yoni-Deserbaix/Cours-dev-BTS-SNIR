//------------------------------------------------------------------------------
/** @file       main.cpp
* @brief        Programme principal
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019/01/03
* @version      1.0
* @date         2019/01/03
*
* Le Docteur Parre doit faire une étude poussée surle nombre de taches présentes sur le pelage
* de certains fauves. Léo sait que la série de <b>Fibonacci</b> peut s’appliquer mais il lui manque un outil
* de calcul des nombres de cette suite ! Il a besoin d’un module logiciel, réutilisable à volonté,
* <code>Fibo(…)</code>, qui fournit les deux valeurs suivantes aux deux valeurs passées en paramètre.
*
* Fabrication   Leo_Parre.pro
*
*/
//------------------------------------------------------------------------------

#include <iostream>
#include "Fibonacci.h"
#include "Echanger.h"
using namespace std ;



int main()
{
	unsigned int	wValeur1Reel	(0) ;
	unsigned int	wValeur2Reel	(0) ;
	unsigned int	wValeur3Reel	(0) ;
	unsigned int	wValeur4Reel	(0) ;

    do
    {
        cout << "Saisissez la valeur 1 : " ;
        cin >> wValeur1Reel ;

        cout << wValeur1Reel << (EstDansFibo(wValeur1Reel) ? " est" : " n'est pas") ;
        cout << " un terme de Fibonacci" << endl ;

        cout << "Saisissez la valeur 2 : " ;
        cin >> wValeur2Reel ;

        cout << wValeur2Reel << (EstDansFibo(wValeur2Reel) ? " est" : " n'est pas") ;
        cout << " un terme de Fibonacci" << endl << endl ;

        if (wValeur1Reel > wValeur2Reel)
        {
            cout << "Vous avez saisi des valeurs mal ordonnees... Laissez_moi les permuter !" << endl << endl ;
            EchangerReference(wValeur1Reel, wValeur2Reel) ;
        }

        cout << wValeur1Reel << " et " << wValeur2Reel ;
        cout << (SontConsecutifs(wValeur1Reel,  wValeur2Reel) ? " sont" : " ne sont pas") ;
        cout << " des termes consecutifs de Fibonacci" << endl << endl ;
    }
    while(!( SontConsecutifs(wValeur1Reel,  wValeur2Reel) )) ;


	FibDeuxSuivant(wValeur1Reel,  wValeur2Reel,
						&wValeur3Reel, wValeur4Reel) ;

	cout << "J'ai calcule les deux termes suivants !" << endl ;
	cout << "Voici votre serie : " << wValeur1Reel << ", " ;
	cout << wValeur2Reel << ", " ;
	cout << wValeur3Reel << ", " ;
	cout << wValeur4Reel << endl << endl ;

	return 0 ;
}
