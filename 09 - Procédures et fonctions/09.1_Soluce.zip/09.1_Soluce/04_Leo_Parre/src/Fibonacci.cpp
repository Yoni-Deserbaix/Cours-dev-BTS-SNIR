//------------------------------------------------------------------------------
/** @file       Fibonacci.cpp
* @brief        Gestion de la suite de Fibonacci
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019/01/03
* @version      1.0
* @date         2019/01/03
*
* Cette bibliothèque permet de gérer la suite de Fibonacci.
* Pour rappel, un membre de cette suite est la somme des deux membres le
* précédant. Les deux premiers termes de cette suite sont toujours 0 et 1 :
* 0, 1, 1, 2, 3, 5, 8, 13, 21...
*
* Fabrication   Leo_Parre.pro
*
*/
//------------------------------------------------------------------------------

#include "Fibonacci.h"
#include "Echanger.h"

/** Ce module permet de calculer les deux termes de la suite de Fibonacci
*
* @pre          Les paramètres <code><b>wFib1Formel</b></code> et
*				<code><b>wFib2Formel</b></code> doivent être correctement
*				ordonnés pour que cette procédure fonctionne. Toutefois, une
*               validation est faite, et si ils ne sont pas bien ordonnés, on
*               les permute…
*
* @param[in]    wFib1Formel contient le premier terme donné par l'utilisateur.
*				Ce paramètre n'a pas a être modifié par cette procédure : on
*				utilise donc un passage par valeur !
* @param[in]    wFib2Formel contient le second terme donné par l'utilisateur.
*				Ce paramètre n'a pas a être modifié par cette procédure : on
*				utilise donc un passage par valeur !
*
* @param[out]   pFib3Formel pointeur qui contient l'adresse du paramètre réel à
*				mettre à jour avec le premier terme de Fibonacci suivant
*				<code><b>wFib2Formel</b></code>.
*				Notez qu'ici le passage par adresse aurait pu être remplacé par
*				un passage par référence, comme pour le paramètre suivant
*				<code><b>wFib4Formel</b></code>.
* @param[out]   wFib4Formel référence au paramètre réel à mettre à jour avec le
*				second terme de Fibonacci suivant <code><b>wFib2Formel</b></code>.
*				Notez qu'ici le passage par référence aurait pu être remplacé par
*				un passage par adresse, comme pour le paramètre précédant
*				<code><b>pFib3Formel</b></code>.
*
*/
void FibDeuxSuivant(unsigned int   wFib1Formel, unsigned int   wFib2Formel,
					unsigned int * pFib3Formel, unsigned int & wFib4Formel)
{

    if (wFib1Formel > wFib2Formel)
    {
        EchangerReference(wFib1Formel, wFib2Formel) ;
    }

	if(		EstDansFibo(wFib1Formel)
	   &&	EstDansFibo(wFib2Formel)
	   &&	SontConsecutifs(wFib1Formel, wFib2Formel))
	{
		*pFib3Formel	= wFib1Formel + wFib2Formel ;
		wFib4Formel		= *pFib3Formel + wFib2Formel ;
	}
	else
	{
		// Un des nombres passé en paramètre n'est pas un terme de Fibonacci
		// On retourne des valeurs nulles pour indiquer l'erreur !
		*pFib3Formel	= 0 ;
		wFib4Formel		= 0 ;
	}
}

/** Ce module permet de vérifier que les deux valeurs passées en paramètre sont
*   bien des termes de termes de la suite de Fibonacci et surtout qu'ils sont
*   consécutifs.
*
* @pre          Les paramètres <code><b>wFib1Formel</b></code> et
*				<code><b>wFib2Formel</b></code> doivent être correctement
*				ordonnés pour que cette procédure fonctionne.
*
* @param[in]    wFib1Formel contient le premier terme donné par l'utilisateur.
*				Ce paramètre n'a pas a être modifié par cette procédure : on
*				utilise donc un passage par valeur !
* @param[in]    wFib2Formel contient le second terme donné par l'utilisateur.
*				Ce paramètre n'a pas a être modifié par cette procédure : on
*				utilise donc un passage par valeur !
*
* @return		Une valeur vraie (<code><b>true</b></code>) si les termes sont
*				effectivement de Fibonacci ET consécutifs.
*
*/
bool SontConsecutifs(unsigned int wFib1Formel, unsigned int wFib2Formel)
{
	/* Cette variable, bTrouve, permet de savoir si wFib1Formel est un terme de
	 * Fibonacci.
	 * Elle est positionnée à true si c'est le cas, ce qui permet de valider
	 * ensuite que le terme suivant dans Fibonacci est égal à wFib2Formel…
	 */
	bool			bTrouve			(false) ;

	/* … et si c'est la cas, bConsecutif est positionné à true, indiquant que
	 * wFib1Formel et wFib2Formel sont consécutifs !
	 */
	bool			bConsecutifs	(false) ;

	unsigned int	wFib1			(1) ;
	unsigned int	wFib2			(1) ;
	unsigned int	wFibPrecedent	(0) ;
	unsigned int	wFib			(0) ;

	if(wFib1Formel != 1 && wFib2Formel > 2)
	{
		do
		{
			wFib = wFib1 + wFib2 ;
			if(wFib == wFib1Formel)
			{
				wFibPrecedent = wFib2 ;
				bTrouve = true ;
			}
			else
			{
				wFib1 = wFib2 ;
				wFib2 = wFib ;
			}
		}
		while(!( (bTrouve==true) || (wFib > wFib1Formel)  )) ;

		if (bTrouve==true)
		{
			if (wFib1Formel+wFibPrecedent == wFib2Formel)
			{
				bConsecutifs=true ;
			}
		}
	}
	else
	{
		bConsecutifs=true ;
	}

	return bConsecutifs ;
}

/** Ce module permet de vérifier que la valeur passée en paramètre est un terme
*   de la suite de Fibonacci.
*
* @param[in]    wNombreAVerifier contient la valeur fournie par l'utilisateur.
*				Ce paramètre n'a pas a être modifié par cette procédure : on
*				utilise donc un passage par valeur !
*
* @return		Une valeur vraie (<code><b>true</b></code>) si le terme est
*				effectivement de Fibonacci.
*
*/
bool EstDansFibo(unsigned int wNombreAVerifier)
{
	bool			bTrouve	(false) ;
	unsigned int	wFib1	(1) ;
	unsigned int	wFib2	(1) ;
	unsigned int	wFib	(0) ;

    if(wNombreAVerifier != 1 && wNombreAVerifier != 0)
	{
		do
		{
			wFib = wFib1 + wFib2 ;
			if(wFib == wNombreAVerifier)
			{
				bTrouve = true ;
			}
			else
			{
				wFib1 = wFib2 ;
				wFib2 = wFib ;
			}
		}
		while(!( (bTrouve==true) || (wFib > wNombreAVerifier)  )) ;
	}
	else
	{
		bTrouve = true ;
	}

	return	bTrouve ;
}
