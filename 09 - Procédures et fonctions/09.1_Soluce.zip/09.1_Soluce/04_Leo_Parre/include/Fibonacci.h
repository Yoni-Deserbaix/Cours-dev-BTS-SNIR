// Fibonacci.h      1.0       2019/01/03      Ch. Cruzol
#ifndef FIBONACCI_H
#define FIBONACCI_H


void FibDeuxSuivant(unsigned int   wFib1Formel, unsigned int   wFib2Formel,
					unsigned int * wFib3Formel, unsigned int & wFib4Formel) ;
bool EstDansFibo(unsigned int wNombreAVerifier) ;
bool SontConsecutifs(unsigned int wFib1Formel, unsigned int wFib2Formel) ;

#endif // FIBONACCI_H
