//------------------------------------------------------------------------------
/** @file       GestionTableau1D.cpp
* @brief        Librairie de gestion d'un tableau à 1 dimension
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019/01/03
* @version      1.0
* @date         2019/01/03
*
* Cette librairie regroupe les procédures et fonctions de gestion minimale
* de tableaux à 1 dimension. Elle simplifie l'initialisation et l'affichage…
*
* Fabrication   Thea_Louest.pro
*
*/
//------------------------------------------------------------------------------

#include <iostream>			// cout, cin
#include <time.h>			// time()
#include "GestionTableau1D.h"

using namespace std ;

/** Cette procédure permet d'initialiser chacune des cases du tableau à 1
*   dimension passé en paramètre à la valeur 0
*
* @param       pTabFormel contient l'adresse de la première case du tableau
*              (paramètre réel). Ce paramètre est passé par adresse parce que
*              le contenu du paramètre réel doit être modifié... de toute façon,
*              ce doit être obligatoirement un pointeur puisque nous passons un
*              tableau ! Il est possible de noter
*              <code><b>unsigned int pTabFormel[]</b></code> à la place comme
*              c'est fait pour la procédure d'affichage...
* @param       wTailleFormel contient la taille maximale du tableau. Il s'agit
*              d'un passage par valeur : le paramètre réel ne doit pas être
*              modifié par la procédure.
*
* @retval      pTabFormel a vu ses cases positionnées à la valeur 0 !
*/
void InitTab1D(unsigned int * pTabFormel, unsigned int wTailleFormel)
{
	for(unsigned int i = 0 ; i < wTailleFormel ; i++)
	{
		pTabFormel[i] = 0 ;
	}
}

/** Cette procédure permet d'initialiser chacune des cases du tableau à 1
*   dimension passé en paramètre à une valeur aléatoire comprise entre 1 et
*   wTailleFormel.
*
* @param       pTabFormel contient l'adresse de la première case du tableau
*              (paramètre réel). Ce paramètre est passé par adresse parce que
*              le contenu du paramètre réel doit être modifié... de toute façon,
*              ce doit être obligatoirement un pointeur puisque nous passons un
*              tableau ! Il est possible de noter
*              <code><b>unsigned int pTabFormel[]</b></code> à la place comme
*              c'est fait pour la procédure d'affichage...
* @param       wTailleFormel contient la taille maximale du tableau. Il s'agit
*              d'un passage par valeur : le paramètre réel ne doit pas être
*              modifié par la procédure.
*
* @retval      pTabFormel a vu ses cases positionnées à une valeur aléatoire
*              cohérente !
*/
void InitAleatoireTab1D(unsigned int * pTabFormel, unsigned int wTailleFormel)
{
    // srand(time(NULL)) ; // Génère des warnings
    // srand(static_cast<unsigned int>(time(nullptr))) ;
    srand(2018) ;
	for(unsigned int i = 0 ; i < wTailleFormel ; i++)
	{
		pTabFormel[i] = rand()%wTailleFormel + 1 ;
	}
}

/** Cette procédure permet d'afficher chacune des cases du tableau à 1
*   dimension passé en paramètre.
*
* @param       pTabFormel contient l'adresse de la première case du tableau
*              (paramètre réel). Même si le contenu du tableau ne doit pas être
*              modifié par cette procédure, ce paramètre est obligatoirement
*              passé par adresse puisque nous passons un tableau ! Il est
*              possible de noter <code><b>unsigned int * pTabFormel</b></code>
*              à la place comme c'est fait pour la procédure d'initialisation...
*              En ajoutant le mot clef <code><b>const</b></code> devant le type,
*              on indique que le paramètre ne peut pas être modifié dans la
*              procédure.
* @param       wTailleFormel contient la taille maximale du tableau. Il s'agit
*              d'un passage par valeur : le paramètre réel ne doit pas être
*              modifié par la procédure.
*
*/
void AfficherTab1D(const unsigned int pTabFormel[], unsigned int wTailleFormel)
{
	for(unsigned int i = 0 ; i < wTailleFormel ; i++)
	{
		cout << pTabFormel[i] << " " ;
	}
	cout << endl << endl ;
}


