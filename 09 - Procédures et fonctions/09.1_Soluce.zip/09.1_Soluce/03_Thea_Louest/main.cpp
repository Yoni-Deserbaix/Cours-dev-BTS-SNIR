//------------------------------------------------------------------------------
/** @file       main.cpp
* @brief        Programme principal
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019/01/03
* @version      1.0
* @date         2019/01/03
*
* Théa Louest (prof d’un précédent TP) a toujours des problèmes avec ses moyennes : elle n’arrive
* pas à remettre son tableau de note à 0 en début de chaque trimestre ! Préparez-lui une
* procédure/fonction <code>InitTab1D(…)</code> qui lui remettra toutes les cases du tableau passéen
* paramètre à 0. Et quitte à y être, proposez-lui un module d’affichage du tableau !
*
* Fabrication   Thea_Louest.pro
*
*/
//------------------------------------------------------------------------------

#include <iostream>
#include "GestionTableau1D.h"
using namespace std ;



int main()
{
	unsigned int	wTailleReel	(20) ;
	unsigned int	wTableauReel[20] ;

	cout << "Attention ! Je vais initialiser le tableau a 0 !" << endl << endl ;

	InitTab1D(wTableauReel, wTailleReel) ;

	cout << "Hopla... voici le resultat de mon travail :" << endl ;

	AfficherTab1D(wTableauReel, wTailleReel) ;

	cout << "Attention ! Je vais initialiser le tableau aleatoirement !" << endl << endl ;

	InitAleatoireTab1D(wTableauReel, wTailleReel) ;

	cout << "Tadaaaah... voici le resultat de mon travail :" << endl ;

	AfficherTab1D(wTableauReel, wTailleReel) ;

	return 0 ;
}
