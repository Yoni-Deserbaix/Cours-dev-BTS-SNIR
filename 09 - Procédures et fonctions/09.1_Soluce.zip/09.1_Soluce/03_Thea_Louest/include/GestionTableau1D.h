// GestionTableau1D.h      1.0       2019/01/03      Ch. Cruzol
#ifndef GESTIONTABLEAU1D_H
#define GESTIONTABLEAU1D_H


void InitTab1D(unsigned int * pTabFormel, unsigned int wTailleFormel) ;
void InitAleatoireTab1D(unsigned int * pTabFormel, unsigned int wTailleFormel) ;
void AfficherTab1D(const unsigned int pTabFormel[], unsigned int wTailleFormel) ;



#endif // GESTIONTABLEAU1D_H
