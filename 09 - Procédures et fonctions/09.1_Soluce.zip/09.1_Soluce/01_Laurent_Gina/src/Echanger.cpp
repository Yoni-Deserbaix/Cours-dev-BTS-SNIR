//------------------------------------------------------------------------------
/** @file       Echanger.cpp
* @brief        Permutation du contenu de deux variables
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019/01/03
* @version      1.0
* @date         2019/01/03
*
* Cette fonction échange le contenu de deux variables fournies par le module
* appelant !
*
* Fabrication   Laurent_Gina.pro
*
*/
//------------------------------------------------------------------------------

#include "Echanger.h"

/** Cette procédure permet d'échanger le contenu de deux variables passées
*   en paramètre par le module logiciel qui l'appelle. Il est ici important de
*   faire un passage de paramètre par référence (ou par adresse) pour que
*   les paramètres réels soient effectivement modifiés !
*
* @param       wAFormel contient la première valeur
* @param       wBFormel contient la seconde valeur
*
* @retval       Les deux paramètres ont vu leur valeur permutée
*/
void EchangerReference(unsigned int & wAFormel, unsigned int & wBFormel)
{
	unsigned int wDitto (0) ;

	wDitto = wAFormel ;
	wAFormel = wBFormel ;
	wBFormel = wDitto ;
}


/** Cette procédure permet d'échanger le contenu de deux variables passées
*   en paramètre par le module logiciel qui l'appelle. Il est ici important de
*   faire un passage de paramètre par adresse pour que les paramètres réels
*   soient effectivement modifiés !
*
* @param       pAFormel contient l'adresse de la première valeur
* @param       pBFormel contient l'adresse de la seconde valeur
*
* @retval       Les deux paramètres ont vu leur valeur permutée
*/
void EchangerAdresse(unsigned int * pAFormel, unsigned int * pBFormel)
{
	unsigned int wDitto (0) ;

	wDitto = *pAFormel ;
	*pAFormel = *pBFormel ;
	*pBFormel = wDitto ;
}
