//------------------------------------------------------------------------------
/** @file       main.cpp
* @brief        Programme principal
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2019/01/03
* @version      1.0
* @date         2019/01/03
*
* Laurent Gina doit réaliser un module logiciel nommé Echanger(…), prenant deux paramètres, et
* devant échanger les valeurs contenues dans les paramètre réels passés pour les afficher ensuite
* dans le programme principal. Seuls problèmes : doit-il réaliser une procédure ou une fonction ?
* Et surtout quel type de passage de paramètres doit-il utiliser ? Il est tellement secoué par le
* problème qu’il vous demande conseil ! Réalisez ce module pour lui !
*
* Fabrication   Laurent_Gina.pro
*
*/
//------------------------------------------------------------------------------

#include <iostream>
#include "Echanger.h"
using namespace std ;



int main()
{
	unsigned int	wAReel	(0) ;
	unsigned int	wBReel	(0) ;

	cout << "Saisissez la premiere valeur A : " ;
	cin >> wAReel ;
	cout << "Saisissez la seconde valeur B : " ;
	cin >> wBReel ;

	cout << endl << "Vous avez saisi..." << endl ;
	cout << "A = " << wAReel << endl ;
	cout << "B = " << wBReel << endl << endl ;

	cout << "Attention ! Je vais permuter ces deux valeurs par reference !" << endl << endl ;

	EchangerReference(wAReel, wBReel) ;

	cout << "Hopla... voici le resultat de mon travail :" << endl ;
	cout << "A = " << wAReel << endl ;
	cout << "B = " << wBReel << endl << endl ;

	cout << "Maintenant, j'echange a nouveau mais par adresse !" << endl << endl ;

	EchangerAdresse(&wAReel, &wBReel) ;

	cout << "Tadaaaah... voici le resultat de mon travail :" << endl ;
	cout << "A = " << wAReel << endl ;
	cout << "B = " << wBReel << endl ;

	return 0 ;
}
