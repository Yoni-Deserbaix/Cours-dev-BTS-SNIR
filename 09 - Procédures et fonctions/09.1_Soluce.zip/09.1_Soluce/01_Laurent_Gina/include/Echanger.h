// Echanger.h      1.0       2019/01/03      Ch. Cruzol
#ifndef ECHANGER_H
#define ECHANGER_H


void EchangerReference(unsigned int & wAFormel, unsigned int & wBFormel) ;
void EchangerAdresse(unsigned int * pAFormel, unsigned int * pBFormel) ;

#endif // ECHANGER_H
