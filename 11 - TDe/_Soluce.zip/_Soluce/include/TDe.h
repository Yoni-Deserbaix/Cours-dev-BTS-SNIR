// TDe.h     1.0         2019/03/10          Ch. CRUZOL

#ifndef TDe_H
#define TDe_H

#include <iostream>
using namespace std ;

class TDe
{
public:
    // COPLIEN
    TDe();
    TDe(const TDe & oDeARecopier);
    ~TDe();
    TDe &                   operator = (const TDe & oDeARecopier);

    friend ostream &        operator <<(ostream & oFlux, const TDe & oDeAAfficher) ;

    // Constructeurs paramètrés
    TDe(unsigned int nInitNbreDeFace);

    // Accesseurs et mutateurs
    unsigned int            Get_nNbreDeFace() ;
    void                    Set_nNbreDeFace(unsigned int nParamNbreFace) ;
    unsigned int            Get_nDerniereValeur() ;

    // Méthodes de métier
    unsigned int            Lancer() ;

    // Méthodes de développement
    bool                    ValiderProba(unsigned int nNbreTirage) ;

private:
    void                    Set_nDerniereValeur(unsigned int nParamDerniereValeur) ;
    unsigned int            nNbreDeFace ;
    unsigned int            nDerniereValeur ;
};

#endif // TDe_H
