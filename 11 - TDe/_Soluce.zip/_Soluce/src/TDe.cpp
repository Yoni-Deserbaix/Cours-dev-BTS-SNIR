//------------------------------------------------------------------------------
/*
* @file     TDe.cpp
* @brief    Modélisation d'un dé à jouer
*
* @author   Ch. CRUZOL
* @author   STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since    2019/03/10
* @version  1.0
* @date     2019/03/10
*
* Cette classe modélise un dé à jouer. Le nombre de faces peut être configuré à
* la création de l'objet, et doit être un entier positif supérieur ou égal à 2.
* S'il n'est pas précisé à la création du dé, il sera positionné à 6.
* Il est possible de connaître ce nombre de faces grâce à un accesseur.
* Pour utiliser ensuite le dé, il suffit de le lancer !
*
* Fabrication   TDe.pro
*
* @todo         Rien
*
* @bug          Aucun
*/
//------------------------------------------------------------------------------
#include <time.h>               // Pour time()
#include <stdlib.h>             // Pour srand, rand(), nullptr
#include "TDe.h"
#include "Tab1D_Dynamique.h"    // Pour le tableau dynamique de la validation

/*------------------------------------------------------------------------------
 *
 *      CONSTRUCTEURS
 *
 *----------------------------------------------------------------------------*/
/** COPLIEN : Constructeur par défaut du dé.
*   Initialise le nombre de faces à 6.
*
* @post     L'objet est instancié et utilisable.
* @see      TDe(unsigned int nInitNbreDeFace)
*           TDe(const TDe & oDeACopier)
*           Set_nNbreDeFace(unsigned int nParamNbreFace)
*/
TDe::TDe() :
    nNbreDeFace   (6) ,
    nDerniereValeur   (0)
{
    srand(static_cast<unsigned int>(time(nullptr))) ;
}

/** Constructeur paramétré du dé.
*   Initialise le nombre de faces en fonction d'une valeur passée en paramètre.
*   Si le nombre de faces n'est pas cohérent (inférieur à 2), le dé sera créé
*   par défaut avec 6 faces.
*
* @param    nInitNbreDeFace : Nombre de faces que doit avoir le dé.
* @post     L'objet est instancié et utilisable.
* @see      TDe()
*           TDe(const TDe & oDeACopier)
*           Set_nNbreDeFace(unsigned int nParamNbreFace)
*/
TDe::TDe(unsigned int nInitNbreDeFace) :
    nNbreDeFace   (0) ,
    nDerniereValeur   (0)
{
    srand(static_cast<unsigned int>(time(nullptr))) ;
    this->Set_nNbreDeFace(nInitNbreDeFace) ;
}

/** COPLIEN : Constructeur de recopie du dé.
*   Initialise le nombre de faces en fonction d'un autre objet passé en paramètre.
*
* @pre      Ici, on considère que le dé reçu est valide.
* @param    oDeACopier : Le dé que l'on doit recopier à l'identique.
* @post     L'objet est instancié et utilisable.
* @see      TDe()
*           TDe(unsigned int nInitNbreDeFace)
*           Set_nNbreDeFace(unsigned int nParamNbreFace)
*/
TDe::TDe(const TDe & oDeACopier) :
    nNbreDeFace   (0) ,
    nDerniereValeur   (0)
{
    srand(static_cast<unsigned int>(time(nullptr))) ;

    this->Set_nNbreDeFace(oDeACopier.nNbreDeFace) ;
    this->Set_nDerniereValeur(oDeACopier.nDerniereValeur) ;
}

/*------------------------------------------------------------------------------
 *
 *      DESTRUCTEUR
 *
 *----------------------------------------------------------------------------*/
/** COPLIEN : Destructeur du dé.
*   Réinitialise les valeurs de tous les attributs à des valeurs par défaut.
*
* @post     L'espace mémoire utilisé par l'objet a été réinitialisé et
*           l'objet n'est plus instancié.
* @see      TDe()
*           TDe(unsigned int nInitNbreDeFace)
*           TDe(const TDe & oDeACopier)
*/
TDe::~TDe()
{
    this->nNbreDeFace       = 0 ;
    this->nDerniereValeur   = 0 ;
}


/** COPLIEN : Opérateur d'affectation.
*   Réinitialise les valeurs de tous les attributs à des valeurs par défaut, puis
*   initialise le nombre de faces en fonction d'un autre objet passé en paramètre.
*
* @pre      On considère que le dé reçu est valide.
* @param    oDeACopier : Le dé que l'on doit recopier à l'identique.
* @return   Une référence sur l'objet lui-même (<code>return *this</code>).
* @post     L'objet est instancié et utilisable. Il est parfaitement identique
*            à celuipassé en paramère
* @see      TDe()
*           TDe(unsigned int nInitNbreDeFace)
*           TDe(const TDe & oDeACopier)
*           ~TDe()
*/
TDe &   TDe::operator =(const TDe & oDeACopier)
{
    if( this != &oDeACopier )
	{
		// Code du destructeur
		this->nNbreDeFace       = 0 ;
		this->nDerniereValeur   = 0 ;

		// code du constructeur de recopie
		this->Set_nNbreDeFace(oDeACopier.nNbreDeFace) ;
		this->Set_nDerniereValeur(oDeACopier.nDerniereValeur) ;
	}
    // Retourne la référence sur l'objet courant.
    return (*this) ;
}

/** Opérateur ami d'affichage dans un flux de sortie.
*
* @param    oFlux : référence sur le flux de sortie à utiliser. Généralement il
*           s'agit de cout… Mais ce peut être aussi un fichier…
* @param    oDeAAfficher : référence sur l'objet à afficher.
* @return   Une référence sur le flux utilisé (<code>return oFlux</code>).
*
* @note     Cette méthode n'est pas membre de la classe (pas d'appartenance TDe::
*           à utiliser !
* @note     Elle est amie de la classe… FRIEND n'apparaît que dans le .H !
*
*/
ostream &   operator <<(ostream & oFlux, const TDe & oDeAAfficher)
{
    oFlux << "Je suis le de d'adresse " << &oDeAAfficher << endl ;
    oFlux << "\t\tnNbreDeFace\t= " << oDeAAfficher.nNbreDeFace << endl ;
    oFlux << "\t\tnDerniereValeur\t= " << oDeAAfficher.nDerniereValeur << endl ;

    return oFlux ;
}


/*------------------------------------------------------------------------------
 *
 *      ACCESSEURS
 *
 *----------------------------------------------------------------------------*/
/** Accesseur.
*   Renseigne sur le nombre de faces que possède le dé.
*
* @pre      L'objet est instancié et le nombre de face est valide.
* @return   Le nombre de faces que possède le dé.
*/
unsigned int TDe::Get_nNbreDeFace()
{
    return (this->nNbreDeFace) ;
}

/** Mutateur.
*   Initialise le nombre de face du dé. Si le nombre de faces passé en paramètre
*   n'est pas valide, un dé à 6 face sera proposé.
*
* @pre      Le dé est instancié.
* @post     Le nombre de faces a été modifié.
* @param    nParamNbreFace : Nombre de faces que doit avoir le dé.
*/
void TDe::Set_nNbreDeFace(unsigned int nParamNbreFace)
{
    if(nParamNbreFace >= 2)
    {
        this->nNbreDeFace = nParamNbreFace ;
    }
    else
    {
        this->nNbreDeFace = 6 ;
    }
}



/** Accesseur.
*   Renseigne sur la dernière valeur sortie par le dé.
*
* @pre      L'objet est instancié et le nombre de face est valide.
* @pre      Le dé a dû être lancé.
* @return   La dernière valeur sortie par le dé si il a déjà été lancé… 0 sinon.
*/
unsigned int TDe::Get_nDerniereValeur()
{
    return this->nDerniereValeur ;
}

/** Mutateur.
*   Initialise la dernière valeur tirée par le dé. Si la valeur passée en paramètre
*   n'est pas valide, la valeur de l'attribut n'est pas modifiée.
*
* @pre      Le dé est instancié.
* @post     La dernière valeur tirée a été modifiée, si la valeur passée en
*           paramètre est valide.
* @param    nParamDerniereValeur : Dernière valeur que doit avoir le dé.
*/
void TDe::Set_nDerniereValeur(unsigned int nParamDerniereValeur )
{
    if((nParamDerniereValeur >= 2)
        && (nParamDerniereValeur <= this->nNbreDeFace))
    {
        this->nDerniereValeur = nParamDerniereValeur ;
    }
}


/*------------------------------------------------------------------------------
 *
 *      MÉTHODES DE MÉTIERS
 *
 *----------------------------------------------------------------------------*/
/** Lancer du dé.
*   L'une des faces de dé est tirée au sort et retournée.
*
* @pre      Le dé est instancié et fonctionnel.
* @return   L'une des faces du dé tirée au sort.
*/
unsigned int TDe::Lancer()
{

    this->nDerniereValeur = (static_cast<unsigned int>(rand()) % this->nNbreDeFace) + 1 ;

    return (this->nDerniereValeur) ;
}



/*------------------------------------------------------------------------------
 *
 *      MÉTHODES DE DÉVELOPPEMENT
 *
 *----------------------------------------------------------------------------*/
/** Validation de l'équilibrage du dé.
*   Un nombre suffisant de tirages est efectué. Le nombre de fois que chaque
*   valeur sort est mémorisé dans un tableau adapté. La validation que le nombre
*   de sortie de chacune des valeurs est bien dans un créneau fixé à +/- 5% de
*   la probabilité théorique indique que le dé est équilibré. Si seulement
*   une des valeur ne répond pas à ce critère… le dé est considéré pipé !
*
* @pre      Le dé est instancié et fonctionnel.
* @param    nNbreTirage : Nombre de tirage à effectuer pour valider le dé.
*
* @return   VRAI si le dé est équilibré. FAUX sinon !
*/
bool TDe::ValiderProba(unsigned int nNbreTirage)
{
     unsigned int    nValeur         (0) ;
     unsigned int *  nSortie         (nullptr) ;
     unsigned int    nTaille         (0) ;
     float           fProba          (0.0) ;
     float           fErreur         (0.0) ;
     float           bDePipe         (false) ;

     nTaille = this->Get_nNbreDeFace() ;
     nSortie = CreerTab1D(nTaille) ;
     for (unsigned int i = 0; i < nNbreTirage; i++)
     {
         nValeur = this->Lancer() ;
         nSortie[nValeur-1] ++ ;
     }
     AfficherTab1D(nSortie, nTaille) ;

     fProba = static_cast<float>(nNbreTirage)/static_cast<float>(nTaille) ;
     fErreur = (fProba * 5.0)/100.0 ;
     bDePipe = false ;
     for (unsigned int i = 0; i < nTaille; i++)
     {
         if (    ((fProba-fErreur) <= static_cast<float>(nSortie[i]))
             &&  (static_cast<float>(nSortie[i]) <= (fProba+fErreur)) )
         {
             cout << "La valeur " << i+1 << " a une probabilite de sortie acceptable." << endl ;
         }
         else
         {
             cout << "La valeur " << i+1 << " n'a pas une probabilite de sortie acceptable." << endl ;
             bDePipe = true ;
         }
     }
     LibererTab1D(nSortie, nTaille) ;

     return bDePipe ;
}
