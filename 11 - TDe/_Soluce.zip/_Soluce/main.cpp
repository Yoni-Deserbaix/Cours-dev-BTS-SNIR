#include <iostream>
#include "TDe.h"
#include "Tab1D_Dynamique.h"
using namespace std;

int main()
{

    TDe             oMonDe6Faces ;
    TDe             oMonDe20Faces   (20) ;
    TDe             oMonDe100Faces  (100) ;
    unsigned int    nValeur         (0) ;
    unsigned int    nNbreTirage     (100000) ;
    bool            bDePipe         (false) ;


    cout << "Nombre de face de oMonDe6Faces = " << oMonDe6Faces.Get_nNbreDeFace() << endl ;
    /*
       oMonDe6Faces.Set_nNbreDeFace(100) ;
       cout << "Nombre de face de oMonDe6Faces = " << oMonDe6Faces.Get_nNbreDeFace() << endl ;
    */
    nValeur = oMonDe6Faces.Lancer() ;
    cout << "Dernier lancer de oMonDe6Faces = " << nValeur << endl ;
    cout << "Dernier lancer de oMonDe6Faces (attribut) = " << oMonDe6Faces.Get_nDerniereValeur() << endl ;

    // Validation
    bDePipe = oMonDe6Faces.ValiderProba(nNbreTirage) ;
    cout << "Le oMonDe6Faces " << (bDePipe ? "est " : "n'est pas ") << "pipe !" << endl ;

/*
    cout << endl << endl ;
    bDePipe = oMonDe20Faces.ValiderProba(nNbreTirage) ;
    cout << "Le oMonDe20Faces " << (bDePipe ? "est " : "n'est pas ") << "pipe !" << endl ;
*/

/*
    cout << endl << endl ;
    bDePipe = oMonDe100Faces.ValiderProba(nNbreTirage*5) ;
    cout << "Le oMonDe100Faces " << (bDePipe ? "est " : "n'est pas ") << "pipe !" << endl ;
*/

    return 0;
}

