#include <iostream>
#include <stdlib.h>
#include <errno.h>
#include <windows.h>
#include <conio.h>      // getch()
#include <stdio.h>
using namespace std ;

// Deux lignes utiles seulement pour supprimer un warning !
extern HANDLE  hEvent ;
extern HANDLE  hSemaphore ;



/* Question 12 - point 1
  */
HANDLE  hEvent ;


/* Question 14
  */
HANDLE  hSemaphore ;

/***************************
  Question 1
  **************************/
DWORD MethodeThread(void * lpParameter)
{
/* Question 8

    for(int i=0; i<10; i++)
    {
        cout << "Valeur : " << static_cast<int>(*(static_cast<int *>(lpParameter))) << endl ;
        Sleep(500) ;
    }
*/

/* Question 10

    while(true)
    {
        cout << "Valeur : " << static_cast<int>(*(static_cast<int *>(lpParameter))) << endl ;
        Sleep(500) ;
    }
*/


/* Question 12 - 2
*/
    while(WaitForSingleObject(hEvent,0) != WAIT_OBJECT_0)
    {
        /* Question 15
          */
        WaitForSingleObject(hSemaphore,INFINITE);
        /* Question 1
		  */
		cout << "Valeur : " << static_cast<int>(*(static_cast<int *>(lpParameter))) << endl ;
        /* Question 16
          */
        ReleaseSemaphore(hSemaphore,1,nullptr);
        Sleep(500) ;
    }

    // Question 13
    ResetEvent(hEvent) ;
    return(0L) ;
}

int main()
{

	// Question 3
    HANDLE  hHandle ;                       // Question 3
    int     nEntier         (8) ;           // Question 3
    DWORD   nIdThread       (0L) ;          // Question 3

    bool    bPrioriteOK     (false) ;       // Question 6
    DWORD   wLancementOK    (0L) ;          // Question 7


    HANDLE  hHandle2 ;                      // Question 13
    int     nAutreEntier    (4) ;           // Question 13

    bool    bRetour         (false) ;


// Question 1
//    wLancementOK = MethodeThread(&nEntier) ;

/* Question 14
  */
    hSemaphore = CreateSemaphore(
                                nullptr,    // pointer to security attributes
                                1,          // initial count
                                1,          // maximum count
                                (LPCTSTR)"ECRAN" // pointer to semaphore-object name
                        ) ;
    WaitForSingleObject(hSemaphore,INFINITE);
    cout << "Handle hSemaphore " << (hSemaphore != nullptr ?"OK":"KO") << endl ;
    cout << "hSemaphore = " << hSemaphore << endl ;
    ReleaseSemaphore(hSemaphore,1,nullptr);


    /* Question 12 - point 1
    */
    hEvent = CreateEvent(
                                nullptr,    // pointer to security attributes
                                true,       // flag for manual-reset event
                                false,      // flag for initial state
                                (LPCTSTR)"EVENEMENT" // pointer to event-object name
                    ) ;
    WaitForSingleObject(hSemaphore,INFINITE);
    cout << "Handle hEvent " << (hEvent != nullptr ?"OK":"KO") << endl ;
    ReleaseSemaphore(hSemaphore,1,nullptr);


    // Question 4
    hHandle = CreateThread(
                    nullptr,                                // pointer to thread security attributes
                    0,                                      // initial thread stack size, in bytes
                    (LPTHREAD_START_ROUTINE)MethodeThread,  // pointer to thread function
                    &nEntier,                               // argument for new thread
                    CREATE_SUSPENDED,                       // creation flags
                    &nIdThread                              // pointer to returned thread identifier
                    ) ;
    WaitForSingleObject(hSemaphore,INFINITE);
    cout << "Handle hHandle=" << (hHandle != nullptr ?"OK":"KO") << endl ;
    ReleaseSemaphore(hSemaphore,1,nullptr);

    // Question 6
    bPrioriteOK = SetThreadPriority(hHandle, THREAD_PRIORITY_NORMAL) ;
    if(!bPrioriteOK)
    {
        /* Question 15
          */
        WaitForSingleObject(hSemaphore,INFINITE);
        cout << "Impossible de configurer la priorite du thread !" << endl ;
        // Bonus : Afficher le code et la cha�ne de caract�res de la derni�re erreur
        /* Question 16
          */
        ReleaseSemaphore(hSemaphore,1,nullptr);
    }


    // Question 7
    wLancementOK = ResumeThread(hHandle) ;
    if(wLancementOK == 0xFFFFFFFF)
    {
        WaitForSingleObject(hSemaphore,INFINITE);
       cout << "Impossible de lancer le thread !" << endl ;
        // Bonus : Afficher le code et la cha de caract貥s de la derni貥 erreur
        /* Question 16
          */
        ReleaseSemaphore(hSemaphore,1,nullptr);
    }

/* Question 13
*/
    hHandle2 = CreateThread(
                    nullptr,                                    // pointer to thread security attributes
                    0,                                          // initial thread stack size, in bytes
                    (LPTHREAD_START_ROUTINE)MethodeThread,      // pointer to thread function
                    &nAutreEntier,                              // argument for new thread
                    CREATE_SUSPENDED,                           // creation flags
                    &nIdThread                                  // pointer to returned thread identifier
                    ) ;
    WaitForSingleObject(hSemaphore,INFINITE);
    cout << "Handle hHandle2 " << (hHandle2 != nullptr ?"OK":"KO") << endl ;
    ReleaseSemaphore(hSemaphore,1,nullptr);

    bPrioriteOK = SetThreadPriority(hHandle2, THREAD_PRIORITY_NORMAL) ;
    if(!bPrioriteOK)
    {
        /* Question 15
          */
        WaitForSingleObject(hSemaphore,INFINITE);
        cout << "Impossible de configurer la priorite du thread 2 !" << endl ;
        // Bonus : Afficher le code et la cha�ne de caract�res de la derni�re erreur
        /* Question 16
          */
        ReleaseSemaphore(hSemaphore,1,nullptr);
    }

    wLancementOK = ResumeThread(hHandle2) ;
    if(wLancementOK == 0xFFFFFFFF)
    {
        /* Question 15
          */
        WaitForSingleObject(hSemaphore,INFINITE);
        cout << "Impossible de lancer le thread 2 !" << endl ;
        // Bonus : Afficher le code et la cha�ne de caract�res de la derni�re erreur
        /* Question 16
          */
        ReleaseSemaphore(hSemaphore,1,nullptr);
    }


/* Question 13
  */
    WaitForSingleObject(hHandle, 5000) ;
    SuspendThread(hHandle) ;
    /* Question 15
      */
    WaitForSingleObject(hSemaphore,INFINITE);
    cout << "Appuyez sur une touche pour continuer..." << endl ;
    /* Question 16
      */
    ReleaseSemaphore(hSemaphore,1,nullptr);
    while(!getche()) ;
    ResumeThread(hHandle) ;
    WaitForSingleObject(hHandle, 3000) ;
    SignalObjectAndWait(hEvent, hHandle, INFINITE, true) ;

/* Question 12 - point 3

    WaitForSingleObject(hHandle, 3000) ;
    SignalObjectAndWait(hEvent, hHandle, INFINITE, true) ;
  */


    // Question 9
    //WaitForSingleObject(hHandle, 10000) ;
    

    /* Question 10 - Soluce 1

        Sleep(5000) ;
        SuspendThread(hHandle) ;
        cout << "Appuyez sur une touche pour continuer..." << endl ;
        while(!getche()) ;
        ResumeThread(hHandle) ;
        Sleep(3000) ;
        SuspendThread(hHandle) ;
      */
    /* Question 10 - Soluce 2

        WaitForSingleObject(hHandle, 5000) ;
        SuspendThread(hHandle) ;
        cout << "Appuyez sur une touche pour continuer..." << endl ;
        while(!getche()) ;

        ResumeThread(hHandle) ;
        WaitForSingleObject(hHandle, 3000) ;
        SuspendThread(hHandle) ;
      */

/* Question 11 - point 1
    // TerminateThread() marche depuis l'ext�rieur du thread !

    bool    bThreadTue  (false) ;
    Sleep(5000) ;

    bThreadTue = TerminateThread(
                                    hHandle,            // handle to the thread
                                    -1L                 // exit code for the thread
                                   );
    if(!bThreadTue)
    {
        // Question 15
        WaitForSingleObject(hSemaphore,INFINITE);
        cout << "Impossible de tuer le thread par TerminateThread() !" << endl ;
        // Bonus : Afficher le code et la cha�ne de caract�res de la derni�re erreur
        // Question 16
        ReleaseSemaphore(hSemaphore,1,NULL);
    }
*/
/* Question 11 - point 2
    // ExitThread() ne marche que pour le thread dans lequel elle est utilis�e !

    Sleep(5000) ;

    ExitThread(-1L);                 // exit code for the thread
*/





    /* Question 15
      */
    WaitForSingleObject(hSemaphore,INFINITE);
    // Question 2
    cout << "Fin du main !!!" << endl ;
    cout << "Appuyez sur une touche pour continuer..." << endl ;
    /* Question 16
      */
    ReleaseSemaphore(hSemaphore,1,nullptr);
    while(!getche()) ;

    // Question 13
    SignalObjectAndWait(hEvent, hHandle2, INFINITE, true) ;

    // Question 5
    bRetour = CloseHandle(hHandle) ;      // Question 5
    WaitForSingleObject(hSemaphore,INFINITE);
    cout << "Fermeture hHandle " << (bRetour ?"OK":"KO") << endl ;
    ReleaseSemaphore(hSemaphore,1,nullptr);

    bRetour = CloseHandle(hHandle2) ;     // Question 13
    WaitForSingleObject(hSemaphore,INFINITE);
    cout << "Fermeture hHandle2 " << (bRetour ?"OK":"KO") << endl ;
    ReleaseSemaphore(hSemaphore,1,nullptr);

    bRetour = CloseHandle(hEvent) ;       // Question 12
    WaitForSingleObject(hSemaphore,INFINITE);
    cout << "Fermeture hEvent " << (bRetour ?"OK":"KO") << endl ;
    ReleaseSemaphore(hSemaphore,1,nullptr);

    bRetour = CloseHandle(hSemaphore) ;       // Question 12
    cout << "Fermeture hSemaphore " << (bRetour ?"OK":"KO") << endl ;


    return(errno) ;
}
