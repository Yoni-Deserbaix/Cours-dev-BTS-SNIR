//------------------------------------------------------------------------------
/** @file		main.cpp
*
*  @brief		Decription rapide !
*
*  @author		Ch. Cruzol
*  @author		STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
*  @since		20aa-mm-jj
*  @version		1.0
*  @date		20aa-mm-jj
*
*  Description détaillée du fichier
*
*  Fabrication MonProjet.pro
*
*  @todo		Rien
*
*  @bug			Aucun
*/
//------------------------------------------------------------------------------
#include "TProf.h"

TProf::TProf():
	pEtudiantEnCours	(nullptr),
	sNom				("Nimbus")
{

}

TProf::TProf(string sNom):
	pEtudiantEnCours	(nullptr),
	sNom				("Nimbus")
{
	if(sNom != "")
	{
		this->sNom = sNom ;
	}
}

TProf::~TProf()
{
	this->sNom = "" ;
	this->pEtudiantEnCours = nullptr ;
}

string TProf::Get_sNom()
{
	return this->sNom ;
}

bool TProf::AccepterEnClasse(TEtudiant * pEtudiant)
{
	bool	bAcceptOK	(false) ;
	if((pEtudiant != nullptr ) && (this->pEtudiantEnCours == nullptr))
	{
		this->pEtudiantEnCours = pEtudiant ;
		bAcceptOK = true ;
	}
	return bAcceptOK ;
}

bool TProf::RepondreALaQuestion(unsigned int nQuestion)
{
	bool	bReponseOK	(false) ;
	string	sReponses[] = {	"Rep 1",
							"Rep 2",
							"Rep 3",
							"Rep 4"
						 } ;

	if(this->pEtudiantEnCours != nullptr)
	{
		if(nQuestion<4)
		{
			cout << "Voici ma reponse, Monsieur " << this->pEtudiantEnCours->Get_sNom() << " :" << endl ;
			cout << sReponses[nQuestion] << endl ;
			bReponseOK = true ;
		}
		else
		{
			cout << "Je n'ai pas la reponse a cette question !" << endl ;
		}
	}
	else
	{
		cout << "Je n'ai pas d'etudiant a qui repondre !" << endl ;
	}
	return bReponseOK ;
}

bool TProf::DonnerUnExercice()
{
	bool	bExoOK		(false) ;
	string	sExos[] = {	"Exo 1",
						"Exo 2",
						"Exo 3",
						"Exo 4"
							} ;
	unsigned int	nNumExo	(0) ;

	if(this->pEtudiantEnCours != nullptr)
	{
		nNumExo = rand() % 4 ;
		cout << "Monsieur " << this->pEtudiantEnCours->Get_sNom() ;
		cout << ", vous devez faire cet exercice :" << endl ;
		cout << sExos[nNumExo] << endl << endl ;
		bExoOK = this->pEtudiantEnCours->RepondreALExercice(nNumExo) ;
	}
	else
	{
		cout << "Je n'ai pas d'étudiant a qui proposer un exercice !" << endl<< endl ;
	}
	return bExoOK ;
}

bool TProf::FinirLeCours()
{
	bool	bFinCoursOK	(false) ;

	if(this->pEtudiantEnCours != nullptr)
	{

		cout << "Le Cours est termine, Monsieur " << this->pEtudiantEnCours->Get_sNom() <<  endl ;
		bFinCoursOK = this->pEtudiantEnCours->QuitterLeCours() ;
		this->pEtudiantEnCours = nullptr ;
	}
	else
	{
		cout << "Je ne donne pas de cours en ce moment !" << endl ;
	}
	return bFinCoursOK ;
}

void TProf::Afficher()
{
	cout << "Je m'appelle Professeur " << this->sNom << " (" << this << ") " ;
	if(this->pEtudiantEnCours!=nullptr)
	{
		cout << "et je suis en cours avec Monsieur " << this->pEtudiantEnCours->Get_sNom() ;
	}
	else
	{
		cout << "et je ne donne aucun cours en ce moment.." ;
	}
	cout << "." << endl ;

}
