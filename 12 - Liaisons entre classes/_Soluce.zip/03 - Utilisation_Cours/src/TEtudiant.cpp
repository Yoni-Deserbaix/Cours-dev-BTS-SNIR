//------------------------------------------------------------------------------
/** @file		main.cpp
*
*  @brief		Decription rapide !
*
*  @author		Ch. Cruzol
*  @author		STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
*  @since		20aa-mm-jj
*  @version		1.0
*  @date		20aa-mm-jj
*
*  Description détaillée du fichier
*
*  Fabrication MonProjet.pro
*
*  @todo		Rien
*
*  @bug			Aucun
*/
//------------------------------------------------------------------------------


#include "TEtudiant.h"

TEtudiant::TEtudiant():
	pProfActuel	(nullptr),
	sNom		("Lambda")
{
}

TEtudiant::TEtudiant(string sNom):
	pProfActuel	(nullptr),
	sNom		("Lambda")
{
	if(sNom != "")
	{
		this->sNom = sNom ;
	}
}

TEtudiant::~TEtudiant()
{
	this->sNom = "" ;
	this->pProfActuel = nullptr ;
}

string TEtudiant::Get_sNom()
{
	return this->sNom ;
}

bool TEtudiant::ParticiperAuCoursDe(TProf * pProf)
{
	bool	bCoursOK	(false) ;
	if((pProf != nullptr) && (this->pProfActuel == nullptr))
	{
		this->pProfActuel = pProf ;
		bCoursOK = this->pProfActuel->AccepterEnClasse(this) ;
	}
	return bCoursOK ;
}

bool TEtudiant::PoserUneQuestion()
{
	bool	bQuestionOK		(false) ;
	string	sQuestions[] = {	"Quest 1",
								"Quest 2",
								"Quest 3",
								"Quest 4"
							} ;
	unsigned int	nNumQuestion	(0) ;

	if(this->pProfActuel != nullptr)
	{
		nNumQuestion = rand() % 4 ;
		cout << "Monsieur " << this->pProfActuel->Get_sNom() ;
		cout << ", j'ai cette question pour vous :" << endl ;
		cout << sQuestions[nNumQuestion] << endl << endl ;
		bQuestionOK = this->pProfActuel->RepondreALaQuestion(nNumQuestion) ;
	}
	else
	{
		cout << "Je n'ai pas de prof a qui poser une question !" << endl<< endl ;
	}
	return bQuestionOK ;
}

bool TEtudiant::RepondreALExercice(unsigned int nExercice)
{
	bool	bSoluceOK	(false) ;
	string	sSoluces[] = {	"Soluce 1",
							"Soluce 2",
							"Soluce 3",
							"Soluce 4"
						 } ;

	if(this->pProfActuel != nullptr)
	{
		if(nExercice<4)
		{
			cout << "Voici ma reponse, Monsieur " << this->pProfActuel->Get_sNom() << " :" << endl ;
			cout << sSoluces[nExercice] << endl ;
			bSoluceOK = true ;
		}
		else
		{
			cout << "Je n'ai pas la soluce a cet exercice !" << endl ;
		}
	}
	else
	{
		cout << "Je n'ai pas de pProf a qui rendre un exercice !" << endl ;
	}
	return bSoluceOK ;
}

bool TEtudiant::QuitterLeCours()
{
	bool	bQuitteOK	(false) ;

	if(this->pProfActuel != nullptr)
	{
		cout << "Au revoir, Monsieur " << this->pProfActuel->Get_sNom() <<  endl ;
		this->pProfActuel = nullptr ;
		bQuitteOK = true ;
	}
	else
	{
		cout << "Je ne suis aucun cours de prof en ce moment !" << endl ;
	}
	return bQuitteOK ;
}

void TEtudiant::Afficher()
{
	cout << "Je m'appelle " << this->sNom << " (" << this << ") " ;
	if(this->pProfActuel != nullptr)
	{
		cout << "et je suis en cours avec Monsieur " << this->pProfActuel->Get_sNom() ;
	}
	else
	{
		cout << "et je ne suis aucun cours en ce moment.." ;
	}
	cout << "." << endl ;
}
