//------------------------------------------------------------------------------
/** @file	main.cpp
*
*  @brief	Programme de mise au point et de test des diverses fonctionnalités.
*
*  @author	Ch. Cruzol
*  @author	STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
*  @since	2015-11-06
*  @version	1.0
*  @date	2016-05-06
*
* Description détaillée du fichier
*
*  @todo	Rien
*
*  @bug	Aucun
*/

#include <iostream>
#include <time.h>
#include "TEtudiant.h"
#include "TProf.h"
using namespace std ;

int main()
{
	TEtudiant	oUnEtudiant	;
	TEtudiant	oUnAutreEtudiant	("Philibert") ;
	TProf		oLeProf ;
	TProf		oLAutreProf			("Choron") ;
	bool		bRetour				(false) ;

	srand(static_cast<unsigned int>(time(nullptr))) ;
	// srand(2023) ;

	oUnEtudiant.Afficher() ;
	oLeProf.Afficher() ;

	bRetour = oUnEtudiant.ParticiperAuCoursDe(&oLeProf) ;
	if(bRetour)
	{
		cout << "L'etudiant " << oUnEtudiant.Get_sNom() << " s'est inscrit au cours du Professeur " ;
		cout << oLeProf.Get_sNom() << " qui l'a accepte en classe !" << endl<< endl ;
	}
	else
	{
		cout << "L'etudiant " << oUnEtudiant.Get_sNom() << " n'a pas pu s'inscrit au cours du Professeur " ;
		cout << oLeProf.Get_sNom() << " qui ne l'accepte pas en classe DU COUP !" << endl<< endl ;
	}

	oUnEtudiant.Afficher() ;
	oLeProf.Afficher() ;

	bRetour = oUnEtudiant.PoserUneQuestion() ;
	if(bRetour)
	{
		cout << "La question posee a eu une reponse..." << endl ;
	}
	else
	{
		cout << "La question posee n'a pas eu une reponse..." << endl ;
	}

	bRetour = oLeProf.FinirLeCours() ;

	cout << endl << endl ;




	bRetour = oUnAutreEtudiant.ParticiperAuCoursDe(&oLAutreProf) ;
	if(bRetour)
	{
		cout << "L'etudiant " << oUnAutreEtudiant.Get_sNom() << " s'est inscrit au cours du Professeur " ;
		cout << oLAutreProf.Get_sNom() << " qui l'a accepte en classe !" << endl<< endl ;
	}
	else
	{
		cout << "L'etudiant " << oUnAutreEtudiant.Get_sNom() << " n'a pas pu s'inscrit au cours du Professeur " ;
		cout << oLAutreProf.Get_sNom() << " qui ne l'accepte pas en classe DU COUP !" << endl<< endl ;
	}

	bRetour = oLAutreProf.DonnerUnExercice() ;
	if(bRetour)
	{
		cout << "L'exercice demande a ete correctement fait..." << endl ;
	}
	else
	{
		cout << "L'exercice demande n'a ete fait..." << endl ;
	}
	bRetour = oUnAutreEtudiant.QuitterLeCours() ;
	return 0 ;
}
