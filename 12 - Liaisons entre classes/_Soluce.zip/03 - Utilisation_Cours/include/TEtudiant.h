// nom.h	num.version		date de création	Développeur


#if !defined(_TETUDIANT_H)
#define _TETUDIANT_H

class TEtudiant ;

#include <string>
#include <iostream>
#include "TProf.h"
using namespace std ;

class TEtudiant {
public:
	TEtudiant();
	TEtudiant(string sNom);
	~TEtudiant();
	string Get_sNom() ;
	bool ParticiperAuCoursDe(TProf * pProf);
	bool PoserUneQuestion();
	bool RepondreALExercice(unsigned int nExercice);
	bool QuitterLeCours();
	void Afficher() ;
private:
	TProf * pProfActuel;
	string sNom;
};

#endif  //_TETUDIANT_H
