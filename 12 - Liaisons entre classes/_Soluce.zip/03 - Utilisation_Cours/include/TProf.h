// nom.h	num.version		date de création	Développeur


#if !defined(_TPROF_H)
#define _TPROF_H

class TProf ;

#include <string>
#include <iostream>
#include "TEtudiant.h"
using namespace std ;

class TProf {
public:
	TProf();
	TProf(string sNom);
	~TProf();
	string Get_sNom() ;
	bool AccepterEnClasse(TEtudiant * pEtudiant);
	bool RepondreALaQuestion(unsigned int nQuestion);
	bool DonnerUnExercice();
	bool FinirLeCours();
	void Afficher() ;
private:
	TEtudiant * pEtudiantEnCours;
	string sNom;
};

#endif  //_TPROF_H
