//------------------------------------------------------------------------------
/** @file	main.cpp
*
*  @brief	Programme de mise au point et de test des diverses fonctionnalités.
*
*  @author	Ch. Cruzol
*  @author	STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
*  @since	2015-11-06
*  @version	1.0
*  @date	2016-05-06
*
* Description détaillée du fichier
*
*  @todo	Rien
*
*  @bug	Aucun
*/

#include <iostream>
#include "TCanette.h"
#include "TDistributeur.h"

using namespace std ;

int main()
{
	TCanette		oCanetteMystere ;
	TCanette		oCanette		("Super Bulle") ;
	TDistributeur	oDistributeur ;
	bool			bAjoutOK		(false) ;
	bool			bRetraitOK		(false) ;

	oCanetteMystere.Afficher() ;
	oCanette.Afficher() ;

	cout << "Intitule de oCanette : " << oCanette.Get_sIntitule() << endl ;
	oDistributeur.Afficher() ;
	bAjoutOK = oDistributeur.AjouterUneCanette(&oCanetteMystere) ;
	if (bAjoutOK)
	{
		cout << "La canette a pu etre ajoutee au distributeur !" << endl ;
	}
	else
	{
		cout << "La canette n'a pu etre ajoutee : le distributeur est plein !" << endl ;
	}
	bAjoutOK = oDistributeur.AjouterUneCanette(&oCanette) ;
	if (bAjoutOK)
	{
		cout << "La canette a pu etre ajoutee au distributeur !" << endl ;
	}
	else
	{
		cout << "La canette n'a pu etre ajoutee : le distributeur est plein !" << endl ;
	}
	oDistributeur.Afficher() ;

	bRetraitOK = oDistributeur.RetirerUneCanette("Super Bulle") ;
	if (bRetraitOK)
	{
		cout << "Vous pouvez prendre votre boisson !" << endl ;
	}
	else
	{
		cout << "Desole, cette boisson est en rupture de stock..." << endl;
	}
	oDistributeur.Afficher() ;


	bRetraitOK = oDistributeur.RetirerUneCanette("Giga Geyser") ;
	if (bRetraitOK)
	{
		cout << "Vous pouvez prendre votre boisson !" << endl ;
	}
	else
	{
		cout << "Desole, cette boisson est en rupture de stock..." << endl;
	}
	oDistributeur.Afficher() ;




	return 0 ;



}
