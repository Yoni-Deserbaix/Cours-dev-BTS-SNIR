//------------------------------------------------------------------------------
/** @file		main.cpp
*
*  @brief		Decription rapide !
*
*  @author		Ch. Cruzol
*  @author		STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
*  @since		20aa-mm-jj
*  @version		1.0
*  @date		20aa-mm-jj
*
*  Description détaillée du fichier
*
*  Fabrication MonProjet.pro
*
*  @todo		Rien
*
*  @bug			Aucun
*/
//------------------------------------------------------------------------------

#include <iostream>
#include "TDistributeur.h"
using namespace std ;

TDistributeur::TDistributeur()
{
	for (unsigned int i (0); i < 10; i++)
	{
		this->pCanettes[i] = nullptr ;
	}
}

TDistributeur::~TDistributeur()
{
	for (unsigned int i (0); i < 10; i++)
	{
		this->pCanettes[i] = nullptr ;
	}
}

bool TDistributeur::AjouterUneCanette(TCanette * pCanette)
{
	bool			bAjoutOK	(false) ;
	unsigned int	i			(0) ;

	i = 0 ;
	while( (this->pCanettes[i] != nullptr) && (i < 10)	)
	{
		i++ ;
	}
	if(this->pCanettes[i] == nullptr)
	{
		this->pCanettes[i] = pCanette ;
		bAjoutOK = true ;
	}
	return bAjoutOK ;
}

bool TDistributeur::RetirerUneCanette(string sIntitule)
{
	bool	bRetraitOK		(false) ;
	int		i				(0) ;
	bool	bIntituleTrouve	(false) ;
	i = -1 ;
	do
	{
		i++ ;
		if(this->pCanettes[i] != nullptr)
		{
			if(sIntitule == this->pCanettes[i]->Get_sIntitule())
			{
				bIntituleTrouve = true ;
			}
		}
	}
	while(!( (bIntituleTrouve) || (i >= 9) ));

	if(bIntituleTrouve)
	{
		this->pCanettes[i] = nullptr ;
		bRetraitOK = true ;
	}
	return bRetraitOK ;
}

void TDistributeur::Afficher()
{
	unsigned int	nNbreCanette	(0) ;
	for (unsigned int i (0); i < 10; i++)
	{
		if(this->pCanettes[i] != nullptr)
		{
			nNbreCanette++ ;
		}
	}
	cout << "Je suis le distributeur " << this << " et " ;
	if(nNbreCanette != 0)
	{
		cout << "j'ai " << nNbreCanette << " canette(s) disponible(s) :" <<endl ;
		for (unsigned int i (0); i < 10; i++)
		{
			if(this->pCanettes[i] != nullptr)
			{
				cout << "\t" ;
				this->pCanettes[i]->Afficher() ;
			}
		}
	}
	else
	{
		cout << "je n'ai pas de canette disponible !" << endl ;
	}

}

