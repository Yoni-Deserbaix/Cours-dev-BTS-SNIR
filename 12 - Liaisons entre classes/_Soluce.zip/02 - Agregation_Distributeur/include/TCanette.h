// nom.h	num.version		date de création	Développeur


#if !defined(_TCANETTE_H)
#define _TCANETTE_H

#include <string>
using namespace std ;

class TCanette {
public:
	TCanette();
	TCanette(string sIntitule);
	~TCanette();
	void Afficher();
	string Get_sIntitule();
private:
	string sIntitule;
};

#endif  //_TCANETTE_H
