// nom.h	num.version		date de création	Développeur
#if !defined(_TTRIANGLE_H)
#define _TTRIANGLE_H

#include "TPoint.h"

class TTriangle {
public:
	TTriangle();
	~TTriangle();
	double Get_Perimetre();
	void Afficher();
private:
	TPoint TabSommets[3];
};

#endif  //_TTRIANGLE_H
