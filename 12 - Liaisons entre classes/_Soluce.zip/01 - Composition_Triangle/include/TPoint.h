// nom.h	num.version		date de création	Développeur
#if !defined(_TPOINT_H)
#define _TPOINT_H


class TPoint {
public:
	TPoint();
	TPoint(double fX, double fY);
	TPoint(const TPoint & oPointACopier);
	~TPoint();
	double CalculerDistance(TPoint oAutrePoint);
	void Afficher();
private:
	double fX;
	double fY;
};

#endif  //_TPOINT_H
