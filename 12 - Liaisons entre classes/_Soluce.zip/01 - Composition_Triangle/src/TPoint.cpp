//------------------------------------------------------------------------------
/** @file		TPoint.cpp
*
*  @brief		Decription rapide !
*
*  @author		Ch. Cruzol
*  @author		STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
*  @since		20aa-mm-jj
*  @version		1.0
*  @date		20aa-mm-jj
*
*  Description détaillée du fichier
*
*  Fabrication MonProjet.pro
*
*  @todo		Rien
*
*  @bug			Aucun
*/
//------------------------------------------------------------------------------

#include <iostream>
#include <time.h>
#include <math.h>
#include "TPoint.h"
using namespace std ;


TPoint::TPoint() :
	fX	(0.0),
	fY	(0.0)
{
	int	nMax	(200) ;
	int	nMin	(10) ;

	this->fX = static_cast<double>((rand() % (nMax - nMin)) + nMin) / 10.0 ;
	this->fY = static_cast<double>((rand() % (nMax - nMin)) + nMin) / 10.0 ;
}

TPoint::TPoint(double fX, double fY) :
	fX	(fX),
	fY	(fY)
{
}

TPoint::TPoint(const TPoint & oPointACopier) :
	fX	(oPointACopier.fX),
	fY	(oPointACopier.fY)
{
}

TPoint::~TPoint()
{
	this->fX = 0.0 ;
	this->fY = 0.0 ;
}

double TPoint::CalculerDistance(TPoint oAutrePoint)
{
	double	fDistance	(0.0) ;

	fDistance = sqrt( (this->fX - oAutrePoint.fX)*(this->fX - oAutrePoint.fX)
					+ (this->fY - oAutrePoint.fY)*(this->fY - oAutrePoint.fY) ) ;

	return fDistance ;

}

void TPoint::Afficher()
{
	cout << "Je suis le point " << this << " aux coordonnees [ " ;
	cout << this->fX << " , " << this->fY << " ] " << endl ;
}

