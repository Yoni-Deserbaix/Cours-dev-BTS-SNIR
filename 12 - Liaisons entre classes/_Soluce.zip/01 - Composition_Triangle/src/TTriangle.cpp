//------------------------------------------------------------------------------
/** @file		TTriangle.cpp
*
*  @brief		Decription rapide !
*
*  @author		Ch. Cruzol
*  @author		STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
*  @since		20aa-mm-jj
*  @version		1.0
*  @date		20aa-mm-jj
*
*  Description détaillée du fichier
*
*  Fabrication MonProjet.pro
*
*  @todo		Rien
*
*  @bug			Aucun
*/
//------------------------------------------------------------------------------

#include <iostream>
#include "TTriangle.h"
using namespace std ;


TTriangle::TTriangle()
{
	// Rien à faire pour initialiser les cases du tableau :
	// c'est le constructeur par défaut de TPoint qui le fait !
}

TTriangle::~TTriangle()
{
	// Rien à faire pour réinitialiser les cases du tableau :
	// c'est le destructeur de TPoint qui le fait !
}

double TTriangle::Get_Perimetre()
{
	double	fPerimetre	(0.0) ;

	fPerimetre =	TabSommets[0].CalculerDistance(TabSommets[1]) ;
	fPerimetre +=	TabSommets[1].CalculerDistance(TabSommets[2]) ;
	fPerimetre +=	TabSommets[2].CalculerDistance(TabSommets[0]) ;

	return fPerimetre ;
}

void TTriangle::Afficher()
{
	cout << "Je suis le triangle " << this << " et voici la liste de mes sommets :"  << endl;
	for (unsigned int i (0); i < 3; i++)
	{
		cout << "\t" ;
		TabSommets[i].Afficher() ;
	}
	cout << "et j'ai un perimetre de : " << this->Get_Perimetre() << endl ;
}

