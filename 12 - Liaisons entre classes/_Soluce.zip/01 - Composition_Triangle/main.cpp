//------------------------------------------------------------------------------
/** @file	main.cpp
*
*  @brief	Programme de mise au point et de test des diverses fonctionnalités.
*
*  @author	Ch. Cruzol
*  @author	STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
*  @since	2015-11-06
*  @version	1.0
*  @date	2016-05-06
*
* Description détaillée du fichier
*
*  @todo	Rien
*
*  @bug	Aucun
*/

#include <iostream>
#include <time.h>
#include "TPoint.h"
#include "TTriangle.h"

using namespace std ;

int main()
{
	// srand(static_cast<unsigned int>(time(nullptr))) ;
	srand(2023) ;

	TPoint	oPoint		(2.0, 2.0) ;
	TPoint	oAutrePoint ;
	TTriangle	oTriangle ;


	oPoint.Afficher() ;
	oAutrePoint.Afficher() ;

	cout << "Distance enttre les deux points : " << oAutrePoint.CalculerDistance(oPoint) << endl ;

	oTriangle.Afficher() ;

	return 0 ;
}
