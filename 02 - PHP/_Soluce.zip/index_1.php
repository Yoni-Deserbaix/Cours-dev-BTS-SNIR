	<?php
		// r�cup�re les langues accept�es par le navigateur
		$langues = $_SERVER["HTTP_ACCEPT_LANGUAGE"];
		//echo $langues;
		if($langues != false)
		{
			// Choisit la premi�re qui est propos�e
			$langue_preferee = strtolower(substr($langues,0,2));
			//echo $sous_chaine;
			$langue=$langue_preferee ;
		}
		$fichier="Loisirs_$langue.php" ;
		// echo $fichier ;
		// ins�re le fichier qui correspond � la langue par d�faut
		include($fichier);
	?>