<html>
	<head>
		<style>
			button{
				  border: 0px;
				  background-color: transparent;
			}
		</style>
	</head>
<header>
	<?php
		include("Header.php");
	?> 
</header>
<body> 
<h1>Sélectionnez la langue de votre choix !</h1>
</body>
</html>
