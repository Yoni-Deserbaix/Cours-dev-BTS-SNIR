<?php
	$langue=$_POST['langue'];
	$fichier="Loisirs_$langue.php";
	include($fichier);
?>
