<html>
	<head>
		<title>My first page PHP</title>
		<style>
			button{
				  border: 0px;
				  background-color: transparent;
			}
		</style>
	</head>
<header>
	<?php
		include("Header.php");
	?> 
</header>
<body>
		<h1>This is my english page !</h1>
	</body>
</html>