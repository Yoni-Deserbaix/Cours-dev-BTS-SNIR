<html>
	<head>
		<title>Ma première page PHP</title>
		<style>
			button{
				  border: 0px;
				  background-color: transparent;
			}
		</style>
	</head>
<header>
	<?php
		include("Header.php");
	?> 
</header>
<body>
	<body>
		<h1>Ceci est ma page en français !</h1>
	</body>
</HTML>