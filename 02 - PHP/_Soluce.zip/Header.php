	<form method="post" ACTION="Select.php">
		<table>
			<tr>
				<td>
					<button type="submit" name="langue" value="fr">
						<img width="10%" src="fr.png" />
					</button>
				</td>
				<td>
					<button type="submit" name="langue" value="en">
						<img width="10%" src="en.png" />
					</button>
				</td>
			</tr>
		</table>
	</form>