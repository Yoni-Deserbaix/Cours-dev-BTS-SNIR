//------------------------------------------------------------------------------
/** @file        main.cpp
 * @brief        Compte et affiche les valeurs impaires contenues dans un tableau à une dimension.
 *
 * @author       Ch. Cruzol
 * @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
 * @since        2018-12-01
 * @version      1.0
 * @date         2018-12-01
 *
 * Jean Bombeur veut savoir combien il y a de nombres impairs et souhaite les afficher.
 *
 * Fabrication   03_Jean_Bombeur.pro
 *
 */
//------------------------------------------------------------------------------


#include <iostream>     // cout
#include <time.h>       // srand, rnd, time
using namespace std ;

/** Ce programme initialise le tableau à une dimension à une valeur aléatoire comprise
 * entre 1 et 100 inclus.<br/>
 * Il passe en revue ensuite chaque case et détecte si la valeur contenue est
 * impaire. Dans ce cas, il affiche cette valeur et incrémente le compteur.<br/>
 * Le nombre de valeurs impaires trouvées dans le tableau est finalement indiqué
 * à l'utilisateur
 *
 * @return       Le programme retourne la valeur 0 à la ligne de commande indiquant
 *               que tout c'est bien déroulé.
 *
 * @see          [srand](https://en.cppreference.com/w/cpp/numeric/random/srand), [rand](https://en.cppreference.com/w/cpp/numeric/random/rand)
 * @see          [time](https://en.cppreference.com/w/cpp/chrono/c/time)
*/
int main()
{
    int             nMonTableau[20] ;
    unsigned int    nNbreImpairs    (0) ;

    // 1.2 - Initaialisation avec du hazard…
    // srand(time(NULL)) ; // Génère des warnings
	srand(static_cast<unsigned int>(time(nullptr))) ;
	for(unsigned int i (0) ; i < 20 ; i++)
    {
        nMonTableau[i] = (rand() % 100) + 1 ;
    }

    // 3 - Recherche et affichage des nombres impairs
    nNbreImpairs = 0 ;
	for(unsigned int i (0) ; i < 20 ; i++)
    {
        if (nMonTableau[i]%2 == 1)
        {
            nNbreImpairs = nNbreImpairs + 1 ;
            cout << "nMonTableau[" << i << "] = " << nMonTableau[i] << endl ;
        }
    }
    cout << nNbreImpairs << " nombres impairs ont ete trouves !" << endl ;
	return 0 ;
}
