//------------------------------------------------------------------------------
/** @file        main.cpp
 * @brief        Initialisation et affichage d'un tableau à une dimension.
 *
 * @author       Ch. Cruzol
 * @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
 * @since        2018-12-01
 * @version      1.0
 * @date         2018-12-01
 *
 * Programme principal permettant l'initialisation d'un tableau 1D avec des 0,
 * puis avec une valeur aléatoire comprise entre 1 et 100 inclus.
 *
 * Fabrication   01_Init.pro
 *
 */
//------------------------------------------------------------------------------


#include <iostream>     // cout
#include <time.h>       // srand, rnd, time
using namespace std ;

/** Ce programme initialise le tableau à une dimension à 0 dans un premier temps.
 * Il affiche le contenu de chaque case à raison d'une valeur par ligne d'écran.
 * La valeur d'initialisation est ensuite ramenée à une valeur aléatoire comprise
 * entre 1 et 100 inclus.
 *
 * @return       Le programme retourne la valeur 0 à la ligne de commande indiquant
 *               que tout c'est bien déroulé.
 *
 * @see          [srand](https://en.cppreference.com/w/cpp/numeric/random/srand), [rand](https://en.cppreference.com/w/cpp/numeric/random/rand)
 * @see          [time](https://en.cppreference.com/w/cpp/chrono/c/time)
*/

int main()
{
    int             nMonTableau[20] ;

/*    // 1.1 - Initialisation avec des zéros…
	for(unsigned int i (0) ; i < 20 ; i++)
    {
        nMonTableau[i] = 0 ;
    }
*/
    // 1.2 - Initaialisation avec du hazard…
    // srand(time(NULL)) ; // Génère des warnings
    srand(static_cast<unsigned int>(time(nullptr))) ;
    //srand(2018) ;
	for(unsigned int i (0) ; i < 20 ; i++)
    {
        nMonTableau[i] = (rand() % 100) + 1 ;
    }

    // 2 - Affichage du contenu du tableau
	for(unsigned int i (0) ; i < 20 ; i++)
    {
        cout << "nMonTableau[" << i << "] = " << nMonTableau[i] << endl ;
    }

	return 0 ;
}
