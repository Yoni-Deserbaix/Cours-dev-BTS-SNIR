//------------------------------------------------------------------------------
/** @file        main.cpp
 * @brief        Saisie manuelle des valeurs contenues dans un tableau à une dimension.
 *
 * @author       Ch. Cruzol
 * @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
 * @since        2018-12-01
 * @version      1.0
 * @date         2018-12-01
 *
 * Théa Louest, professeure stagiaire, a un peu de mal à calculer la moyenne des
 * 6 notes de Max Hy, môme en CP !<br/>
 * Trois problèmes se posent à elle :
 *      <ol><li>la saisie des notes,</li>
 *      <li>leur stockage dans un tableau</li>
 *      <li>le calcul de la moyenne !</li></ol><br/>
 * Aidez cette brave débutante !
 *
 * Fabrication   04_Théa_Louest.pro
 *
 */
//------------------------------------------------------------------------------


#include <iostream>     // cout
using namespace std ;

/** Ce programme propose la saisie des valeurs contenues dans chaque case d'un
 * tableau à une dimension.<br/>
 * Chaque case correspond à une note, sur les 6, qu'a obtenue un élève. Les
 * valeurs ne peuvent donc être comprises qu'entre 0 et 20 inclus, et ce sont
 * forcément des valeurs réelles. Si une des valeurs saisies n'est pas conforme,
 * la sasie de cette note est à refaire JUSQU'À ce qu'elle corresponde aux
 * impératifs.<br/>
 * Des affichages supplémentaires guident l'utilisateur dans sa saisie.<br/>
 * Lorsque les 6 notes sont dans le tableau, celui-ci est parcouru, case par case,
 * pour calculer la somme totale de ces notes.<br/>
 * Finalement, la moyenne des notes est calculée puis affichée à l'écran.
 *
 * @return       Le programme retourne la valeur 0 à la ligne de commande indiquant
 *               que tout c'est bien déroulé.
 */
int main()
{
    float   fTabNotes[6] ;
	float   fSomme      (0.0) ;
	float   fMoyenne    (0.0) ;

    // Initialisation avec des zéros…
	for(unsigned int i (0) ; i < 6 ; i++)
    {
        fTabNotes[i] = 0.0 ;
    }

    // Saisie des notes…
	for(unsigned int i (0) ; i < 6 ; i++)
    {
        do
        {
            cout << "Saisissez la note numero " << i+1 << " : " ;
            cin >> fTabNotes[i] ;
			if ((fTabNotes[i] < 0.0f) || (fTabNotes[i] > 20.0f))
            {
                cout << "Valeur de la note numero " << i+1 << " incorecte !" << endl ;
            }
        }
		while (!((fTabNotes[i] >= 0.0f) && (fTabNotes[i] <= 20.0f))) ;
    }

    // Calcul de la moyenne…
    fSomme = 0.0 ;
	for(unsigned int i (0) ; i < 6 ; i++)
    {
        fSomme = fSomme + fTabNotes[i] ;
    }
	fMoyenne = fSomme / 6.0f ;

    // Affichage du contenu du tableau
	for(unsigned int i (0) ; i < 6 ; i++)
    {
        cout << "fTabNotes[" << i << "] = " << fTabNotes[i] << endl ;
    }

    cout << "la moyenne de ces notes est " << fMoyenne << endl ;

    return 0 ;
}
