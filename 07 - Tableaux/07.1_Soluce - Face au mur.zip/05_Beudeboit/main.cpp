//------------------------------------------------------------------------------
/** @file        main.cpp
 * @brief        Recherche et affichage des valeurs maxi et mini contenues dans un tableau à une dimension.
 *
 * @author       Ch. Cruzol
 * @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
 * @since        2018-12-01
 * @version      1.0
 * @date         2018-12-01
 *
 * L’Agent Beudeboit doit faire un rapport à son supérieur sur les montants maximum et minimum
 * des contraventions perçues durant la semaine. Les 1937 montants, compris entre 35,0 € et
 * 199,99 €, ont déjà été saisis et sont dans un tableau (remplissage aléatoire). Trouvant cette
 * tâche très fastidieuse, Beudeboit recherche un algorithme pour automatiser la recherche du
 * minimum et du maximum !
 *
 * Fabrication   05_Beudeboit.pro
 *
 */
//------------------------------------------------------------------------------


#include <iostream>     // cout
#include <time.h>       // srand, rnd, time
using namespace std ;

/** Ce programme initialise le tableau à une dimension à une valeur aléatoire comprise
 * entre 35.0 et 199.99 inclus. Chaque case contient le montant d'une contravention.
 * Ce sont donc des valeurs réelles !<br/>
 * Il passe ensuite en revue chaque case et détecte si la valeur contenue est
 * la plus petite qu'il ait trouvé jusqu'à présent.<br/>Il faut donc une variable qui
 * permettra de se souvenir de cette valeur la plus faible.<br/>Au commencement de la
 * recherche, il est nécessaire que cette variable soit initialisée, soit avec
 * une valeur plus grande que toutes celles qui peuvent se trouver dans le tableau
 * (par exemple 200.00), soit par la valeur contenue dans le première case du tableau.
 * En effet, on va considérer que c'est la plus petite de toutes…<br/>Si le parcours
 * du tableau nous en dévoile une autre valeur encore plus petite que celle que
 * nous avons trouvée depuis le début, on mémorisera cette nouvelle valeur.<br/>
 * Le principe est le même pour la recherche du maximum, hormi que la valeur
 * d'initialisation devra soit être plus petite que toutes les valeurs (par exemple
 * 34.99) soit encore une fois la première valeur du tableau.<br/>
 * Finalement, les valeurs maximales et minimales trouvées dans le tableau sont
 * affichées.
 *
 * @return       Le programme retourne la valeur 0 à la ligne de commande indiquant
 *               que tout c'est bien déroulé.
 *
 * @see          [srand](https://en.cppreference.com/w/cpp/numeric/random/srand), [rand](https://en.cppreference.com/w/cpp/numeric/random/rand)
 * @see          [time](https://en.cppreference.com/w/cpp/chrono/c/time)
 */
int main()
{
    float   fTabContraventions[1937] ;
    float   fMaxi   (0.0) ;
    float   fMini   (0.0) ;

    // Initaialisation avec du hazard…
    // srand(time(NULL)) ; // Génère des warnings
    srand(static_cast<unsigned int>(time(nullptr))) ;
    // srand(2018) ;
	for(unsigned int i (0) ; i < 1937 ; i++)
    {
		fTabContraventions[i] = (static_cast<float>(rand() % (19999-3500)) + 3500)/100.0f ;
    }

    // Recherche du mini et du maxi…
    //fMaxi = 34.99 ;       // Init avec une valeur plus petite de toutes…
	fMaxi = fTabContraventions[0] ; // La première valeur est plus grande !
	for(unsigned int i (1) ; i < 1937 ; i++)
	{
		if (fTabContraventions[i] > fMaxi)
		{
			fMaxi = fTabContraventions[i] ;
		}
	}

	//fMini = 200.0 ;       // Init avec une valeur plus grande de toutes…
	fMini = fTabContraventions[0] ; // La première valeur est plus petite !
	for(unsigned int i (1) ; i < 1937 ; i++)
	{
		if (fTabContraventions[i] < fMini)
		{
			fMini = fTabContraventions[i] ;
		}
	}

/*    // Affichage du contenu du tableau
	for(register unsigned int i (0) ; i < 1937 ; i++)
    {
        cout << "fTabContraventions[" << i << "] = " << fTabContraventions[i] << endl ;
    }
*/
    cout << "le maxi de ces contraventions est " << fMaxi << endl ;
    cout << "le mini de ces contraventions est " << fMini << endl ;

    return 0 ;
}
