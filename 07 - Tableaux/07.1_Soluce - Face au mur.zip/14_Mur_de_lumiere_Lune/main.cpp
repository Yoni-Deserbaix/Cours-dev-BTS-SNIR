//------------------------------------------------------------------------------
/** @file       main.cpp
* @brief        Gestion d'un mur de lumière
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2018/12/01
* @version      1.0
* @date         2018/12/01
*
* Tim Hagine, régisseur de spectacle, doit préparer un mur de lumière constitué
* d’une matrice de 20 spots par 20 spots. Chaque spot peut générer une couleur
* indépendamment des autres, selon le schéma classique RGB.<br/>
* Plusieurs actes sont prévus et pour chacun d’entre eux, Tim doit réaliser une
* mise en scène lumineuse spéciale.
*
* Fabrication   Mur_de_lumiere.pro
*
* @todo         Plein de nouveaux actes sont possibles ! À vous de les imaginer !
*
*/
//------------------------------------------------------------------------------

#include <iostream>		// cout, cin
#include <cstdlib>		// abs
#include <math.h>		// sin et cos
#include <windows.h>    // Couleurs dans la console

using namespace std ;

// Constantes symboliques pour les couleurs utilisées
/** @def	NOIR
*  @brief	Codage RGB du noir 0x000000
*/
#define	NOIR	(0x000000)


/** @def	BLANC
*  @brief	Codage RGB du blanc 0xFFFFFF
*/
#define	BLANC	(0xFFFFFF)


/** @def	LUNE
*  @brief	Codage RGB de la couleur jaune pâle de la lune 0xFFFF99
*/
#define	LUNE	(0xFFFF99)


/** @def	ROUGE
*  @brief	Codage RGB du rouge 0xFF0000
*/
#define	ROUGE	(0xFF0000)


/** @def	JAUNE
*  @brief	Codage RGB du jaune 0xFFFF00
*/
#define	JAUNE	(0xFFFF00)


/** @def	VERT
*  @brief	Codage RGB du vert 0x00FF00
*/
#define	VERT	(0x00FF00)


/** @def	BLEU
*  @brief	Codage RGB du bleu 0x0000FF
*/
#define	BLEU	(0x0000FF)



// Constantes symboliques pour l'affichage
/** @def	ETEINT
*  @brief	Symbole à afficher si le spot est éteint (de couleur NOIR)
*/
#define	ETEINT	(". ")


/** @def	ALLUME
*  @brief	Symbole à afficher si le spot est allumé (autre couleur que NOIR)
*/
#define	ALLUME	("O ")



/** Tim a prévu les actes dans l'ordre :
* ->>> Extinction du mur en initialisant la couleur de chaque spot à NOIR
* ->> Transfert (affichage) du motif stocké dans le modèle (le tableau informatique) sur le mur réel
* - Tracé du X géant vert
* - Conception du damier
* - Apparition du cadre de la toile vide…
* - … puis avec les carrés concentriques
* - Dessin du dièse des fausses notes
* ->>> Apparition de la pleine lune.
*
* @pre          Le mur de lumière est fonctionnel et connecté au PC
* @post         Chaque scène est correctement affichée sur le mur
*
* @param        Pas de paramètre dans ce programme !
*
* @return       0 est retournée au SE pour indiquer que tout c'est bien passé !
*
*/
int main()
{
	// Variables
	unsigned int	nMurDeLumiere[20][20] ;
	unsigned int	nTaille		(20) ;
	unsigned int	x			(0) ;
	unsigned int	y			(0) ;
	unsigned int	nCouleur	(0) ;

    // Q6 : Initialisation
    nCouleur = NOIR ;
	// Parcours du mur ligne par ligne puis par colonne sur une ligne
	for(y = 0 ; y < nTaille ; y++)
	{
		for(x = 0 ; x < nTaille ; x++)
		{
			nMurDeLumiere[x][y] = nCouleur ;
		}
	}

    // Q13 : Lune

	unsigned int	nCentreX	(nTaille/2) ;
	unsigned int	nCentreY	(nTaille/2) ;
	unsigned int	nRayon		(nTaille/2 - 3) ;
    unsigned int	nMini		(0) ;

	// Validation pour que la lune soit entière sur le mur...
	// et réduction du rayon sinon
	nMini = nCentreY ;
	if (nCentreX < nMini)
	{
		nMini = nCentreX ;
	}
	if ((nTaille - nCentreX) < nMini)
	{
		nMini = nTaille - nCentreX ;
	}
	if ((nTaille - nCentreY) < nMini)
	{
		nMini = nTaille - nCentreY ;
	}
	if ((nMini) < nRayon)
	{
		nRayon = nMini ;
	}

	// Dessin de la lune par tracé successif de cercles de rayon de plus en plus
	// petit. On utilise les formules du cercle en fonction de l'angle mettant
	// en oeuvre le cosinus et le sinus… Le dAngle est exprimé en degrès alors
	// que les cos() et sin() prennent une donnée angulaire exprimée en radian :
	// on doit faire une conversion !
	nCouleur = JAUNE ;
	for (int nRayonTrace (static_cast<int>(nRayon)); nRayonTrace >= 0; nRayonTrace--)
	{
		for(double dAngle = 0.0 ; dAngle <= 360.0 ; dAngle = dAngle + 1.0)
		{
			x = static_cast<unsigned int>(nCentreX + nRayonTrace*cos(dAngle * M_PI / 180.0)) ;
			y = static_cast<unsigned int>(nCentreY + nRayonTrace*sin(dAngle * M_PI / 180.0)) ;
			nMurDeLumiere[x][y] = nCouleur ;
		}
		/*
		// Mise en évidence des cercles concentriques par des couleurs différentes
		if (nRayonTrace % 2 == 0)
		{
			nCouleur = JAUNE ;
		}
		else
		{
			nCouleur = VERT ;
		}
		*/
	}

    // Q7 : Affichage
	// Parcours du mur ligne par ligne puis par colonne sur une ligne
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    for(unsigned int y = 0 ; y < 20 ; y++)
    {
        for(unsigned int x = 0 ; x < 20 ; x++)
        {
            switch(nMurDeLumiere[x][y])
            {
				case NOIR	:	SetConsoleTextAttribute(hConsole, 1);
                                cout << ETEINT ;	break ;
                case BLANC	:	SetConsoleTextAttribute(hConsole, 255);
								cout << "b " ;		break ;
                case LUNE	:	SetConsoleTextAttribute(hConsole, 238);
								cout << "l " ;		break ;
                case ROUGE	:	SetConsoleTextAttribute(hConsole, 204);
								cout << "R " ;		break ;
                case JAUNE	:	SetConsoleTextAttribute(hConsole, 238);
								cout << "J " ;		break ;
                case VERT	:	SetConsoleTextAttribute(hConsole, 170);
								cout << "V " ;		break ;
                case BLEU	:	SetConsoleTextAttribute(hConsole, 153);
								cout << "B " ;		break ;
                default		:	SetConsoleTextAttribute(hConsole, 255);
                                cout << ALLUME ;	break ;
            }
        }
        cout << endl ;
    }
	SetConsoleTextAttribute(hConsole, 15);

	cout << endl ;
	cout << endl ;
	return 0 ;
}
