//------------------------------------------------------------------------------
/** @file       main.cpp
* @brief        Gestion d'un mur de lumière
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2018/12/01
* @version      1.0
* @date         2018/12/01
*
* Tim Hagine, régisseur de spectacle, doit préparer un mur de lumière constitué
* d’une matrice de 20 spots par 20 spots. Chaque spot peut générer une couleur
* indépendamment des autres, selon le schéma classique RGB.<br/>
* Plusieurs actes sont prévus et pour chacun d’entre eux, Tim doit réaliser une
* mise en scène lumineuse spéciale.
*
* Fabrication   Mur_de_lumiere.pro
*
* @todo         Plein de nouveaux actes sont possibles ! À vous de les imaginer !
*
*/
//------------------------------------------------------------------------------

#include <iostream>		// cout, cin
#include <cstdlib>		// abs
#include <math.h>		// sin et cos
#include <windows.h>    // Couleurs dans la console

using namespace std ;

// Constantes symboliques pour les couleurs utilisées
/** @def	NOIR
*  @brief	Codage RGB du noir 0x000000
*/
#define	NOIR	(0x000000)


/** @def	BLANC
*  @brief	Codage RGB du blanc 0xFFFFFF
*/
#define	BLANC	(0xFFFFFF)


/** @def	LUNE
*  @brief	Codage RGB de la couleur jaune pâle de la lune 0xFFFF99
*/
#define	LUNE	(0xFFFF99)


/** @def	ROUGE
*  @brief	Codage RGB du rouge 0xFF0000
*/
#define	ROUGE	(0xFF0000)


/** @def	JAUNE
*  @brief	Codage RGB du jaune 0xFFFF00
*/
#define	JAUNE	(0xFFFF00)


/** @def	VERT
*  @brief	Codage RGB du vert 0x00FF00
*/
#define	VERT	(0x00FF00)


/** @def	BLEU
*  @brief	Codage RGB du bleu 0x0000FF
*/
#define	BLEU	(0x0000FF)



// Constantes symboliques pour l'affichage
/** @def	ETEINT
*  @brief	Symbole à afficher si le spot est éteint (de couleur NOIR)
*/
#define	ETEINT	(". ")


/** @def	ALLUME
*  @brief	Symbole à afficher si le spot est allumé (autre couleur que NOIR)
*/
#define	ALLUME	("O ")



/** Tim a prévu les actes dans l'ordre :
* ->>> Extinction du mur en initialisant la couleur de chaque spot à NOIR
* ->>> Transfert (affichage) du motif stocké dans le modèle (le tableau informatique) sur le mur réel
* - Tracé du X géant vert
* - Conception du damier
* - Apparition du cadre de la toile vide…
* - … puis avec les carrés concentriques
* ->>> Dessin du dièse des fausses notes
* - Apparition de la pleine lune.
*
* @pre          Le mur de lumière est fonctionnel et connecté au PC
* @post         Chaque scène est correctement affichée sur le mur
*
* @param        Pas de paramètre dans ce programme !
*
* @return       0 est retournée au SE pour indiquer que tout c'est bien passé !
*
* @note         Spéciale dédicasse à Jung Kook pour son affichage en couleur sur la console !
*/
int main()
{
	// Variables
	unsigned int	nMurDeLumiere[20][20] ;
	unsigned int	nTaille		(20) ;
	unsigned int	x			(0) ;
	unsigned int	y			(0) ;
	unsigned int	nCouleur	(0) ;

    // Q6 : Initialisation
    nCouleur = NOIR ;
	// Parcours du mur ligne par ligne puis par colonne sur une ligne
	for(y = 0 ; y < nTaille ; y++)
	{
		for(x = 0 ; x < nTaille ; x++)
		{
			nMurDeLumiere[x][y] = nCouleur ;
		}
	}

    // Q12 : Diese

	float			nX1			(0.0) ;
	float			nY1			(0.0) ;
	float			nX2			(0.0) ;
	float			nY2			(0.0) ;
	float			a			(0.0) ;
	float			b			(0.0) ;
	float			nTemp		(0.0) ;

	for(unsigned int nNbreLigne = 0 ; nNbreLigne < 4 ; nNbreLigne++)
	{
		// Paramétrage des coordonnées des coordonnées des 4 lignes du dièse
		switch (nNbreLigne)
		{
			case 0 :	nX1 = 2.0 ;		nY1 = 7.0 ;		// horizontalle haute
						nX2 = 17.0 ;	nY2 = 7.0 ;
						nCouleur = VERT ;
						break ;
			case 1 :	nX1 = 2.0 ;		nY1 = 12.0 ;	// horizontalle basse
						nX2 = 17.0 ;	nY2 = 12.0 ;
                        nCouleur = LUNE ;
						break ;
            case 2 :	nX1 = 9.0 ;		nY1 = 2.0 ;		// oblique gauche
                        nX2 = 5.0 ;		nY2 = 17.0 ;
						nCouleur = ROUGE ;
						break ;
            case 3 :	nX1 = 14.0 ;	nY1 = 2.0 ;		// oblique droite
                        nX2 = 10.0 ;	nY2 = 17.0 ;
						nCouleur = BLEU ;
						break ;
			default :	break ;
		}

		if (nX1 == nX2)	// C'est une ligne horizontale
		{
			if(nY1 > nY2)	// Permutation pour faire un POUR croissant ensuite
			{
				nTemp = nY1 ;
				nY1 = nY2 ;
				nY2 = nTemp ;
			}
			// Tracé selon des Y : X étant fixe pour la ligne !
			for (y = static_cast<unsigned int>(nY1); y <= nY2; y++)
			{
				nMurDeLumiere[static_cast<int>(nX1)][static_cast<int>(y)] = nCouleur ;
			}
		}
		else
		{
			if (nY1 == nY2)	// C'est une ligne verticale
			{
				if(nX1 > nX2)	// Permutation pour faire un POUR croissant ensuite
				{
					nTemp = nX1 ;
					nX1 = nX2 ;
					nX2 = nTemp ;

				}
				// Tracé selon des X : Y étant fixe pour la ligne !
				for (x = static_cast<unsigned int>(nX1); x <= nX2; x++)
				{
					nMurDeLumiere[x][static_cast<int>(nY1)] = nCouleur ;
				}
			}
			else
			{
				// Recherche de la plus petite oblique
				if(abs(nX2-nX1) >= abs(nY2-nY1))
				{
					// Ligne tendant vers l'horizontale
					if(nX1 > nX2)	// Permutation pour faire un POUR croissant ensuite
					{
						nTemp = nX1 ;
						nX1 = nX2 ;
						nX2 = nTemp ;

						nTemp = nY1 ;
						nY1 = nY2 ;
						nY2 = nTemp ;
					}
					// Calculs des coefs. directeurs de la ligne
					a = (nY1-nY2) / (nX1-nX2) ;
					b = nY1 - a*nX1 ;

					// Tracé selon des X pour une bonne précision
					for (x = static_cast<unsigned int>(nX1); x <= nX2; x++)
					{
						y = static_cast<unsigned int>(a*x + b) ;
						nMurDeLumiere[x][y] = nCouleur ;
					}
				}
				else
				{
					// Ligne tendant vers la verticale
					if(nY1 > nY2)	// Permutation pour faire un POUR croissant ensuite
					{
						nTemp = nX1 ;
						nX1 = nX2 ;
						nX2 = nTemp ;

						nTemp = nY1 ;
						nY1 = nY2 ;
						 nY2 = nTemp ;
					}
					// Calculs des coefs. directeurs de la ligne
					a = (nY1-nY2) / (nX1-nX2) ;
					b = nY1 - a*nX1 ;

					// Tracé selon des Y pour une bonne précision
					for (y = static_cast<unsigned int>(nY1); y <= nY2; y++)
					{
						x = static_cast<unsigned int>((y - b)/a) ;
						nMurDeLumiere[x][y] = nCouleur ;
					}
				}
			}

		}
	}

    // Q7 : Affichage
	// Modifications de l'affichage pour pourvoir afficher des couleurs sur la
	// console !
	// Merci à Jung Kook pour cette adaptation ! ;-)
	// Récupération du handle Windows de la console
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    // Parcours du mur ligne par ligne puis par colonne sur une ligne
    for(unsigned int y = 0 ; y < 20 ; y++)
	{
		for(unsigned int x = 0 ; x < 20 ; x++)
		{
			switch(nMurDeLumiere[x][y])
			{
                case NOIR	:	// Mise en couleur de l'écriture et de l'arrière
								// plan de la console pour chaque caractère
                                SetConsoleTextAttribute(hConsole, 1);
								// Affichage classique
                                cout << ETEINT ;	break ;
                case BLANC	:	SetConsoleTextAttribute(hConsole, 255);
								cout << "b " ;		break ;
                case LUNE	:	SetConsoleTextAttribute(hConsole, 238);
								cout << "l " ;		break ;
                case ROUGE	:	SetConsoleTextAttribute(hConsole, 204);
								cout << "R " ;		break ;
                case JAUNE	:	SetConsoleTextAttribute(hConsole, 238);
								cout << "J " ;		break ;
                case VERT	:	SetConsoleTextAttribute(hConsole, 170);
								cout << "V " ;		break ;
                case BLEU	:	SetConsoleTextAttribute(hConsole, 153);
								cout << "B " ;		break ;
                default		:	SetConsoleTextAttribute(hConsole, 255);
                                cout << ALLUME ;	break ;
			}
		}
		cout << endl ;
	}
	SetConsoleTextAttribute(hConsole, 15);

	cout << endl ;
	cout << endl ;
	return 0 ;
}
