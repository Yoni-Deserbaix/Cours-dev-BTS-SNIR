//------------------------------------------------------------------------------
/** @file       main.cpp
* @brief        Gestion d'un mur de lumière
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2018/12/01
* @version      1.0
* @date         2018/12/01
*
* Tim Hagine, régisseur de spectacle, doit préparer un mur de lumière constitué
* d’une matrice de 20 spots par 20 spots. Chaque spot peut générer une couleur
* indépendamment des autres, selon le schéma classique RGB.<br/>
* Plusieurs actes sont prévus et pour chacun d’entre eux, Tim doit réaliser une
* mise en scène lumineuse spéciale.
*
* Lors de la première scène, on fait connaissance avec Harry Cover.<br/>
* Le mur doit afficher un X géant vert, logo de la conserverie où il travaille.<br/>
* Seuls les spots des deux diagonales du mur seront alors allumés à cette couleur !
*
* Fabrication   Mur_de_lumiere.pro
*
* @todo         Plein de nouveaux actes sont possibles ! À vous de les imaginer !
*
*/
//------------------------------------------------------------------------------

#include <iostream>		// cout, cin
#include <cstdlib>		// abs
#include <math.h>		// sin et cos

using namespace std ;

// Constantes symboliques pour les couleurs utilisées
/** @def	NOIR
*  @brief	Codage RGB du noir 0x000000
*/
#define	NOIR	(0x000000)


/** @def	BLANC
*  @brief	Codage RGB du blanc 0xFFFFFF
*/
#define	BLANC	(0xFFFFFF)


/** @def	LUNE
*  @brief	Codage RGB de la couleur jaune pâle de la lune 0xFFFF99
*/
#define	LUNE	(0xFFFF99)


/** @def	ROUGE
*  @brief	Codage RGB du rouge 0xFF0000
*/
#define	ROUGE	(0xFF0000)


/** @def	JAUNE
*  @brief	Codage RGB du jaune 0xFFFF00
*/
#define	JAUNE	(0xFFFF00)


/** @def	VERT
*  @brief	Codage RGB du vert 0x00FF00
*/
#define	VERT	(0x00FF00)


/** @def	BLEU
*  @brief	Codage RGB du bleu 0x0000FF
*/
#define	BLEU	(0x0000FF)



// Constantes symboliques pour l'affichage
/** @def	ETEINT
*  @brief	Symbole à afficher si le spot est éteint (de couleur NOIR)
*/
#define	ETEINT	(". ")


/** @def	ALLUME
*  @brief	Symbole à afficher si le spot est allumé (autre couleur que NOIR)
*/
#define	ALLUME	("O ")



/** Tim a prévu les actes dans l'ordre :
* - >>> Extinction du mur en initialisant la couleur de chaque spot à NOIR
* - >>> Transfert (affichage) du motif stocké dans le modèle (le tableau informatique) sur le mur réel
* - >>> Tracé du X géant vert
* - Conception du damier
* - Apparition du cadre de la toile vide…
* - … puis avec les carrés concentriques
* - Dessin du dièse des fausses notes
* - Apparition de la pleine lune.
*
* Le mur est au départ totalement éteint.
*
* Une première diagonale est alors tracée. On allume les spots en VERT, dans le
* cas où il se trouve sur une même valeur de ligne et de colonne (x==y).
*
* La seconde diagonale est ensuite allumée. Il s'agit des spots dont la valeur
* de la colonne est le symétrique de celle de la ligne par rapport à la taille
* totale du mur (x==(nTaille-1)-y). Par exemple, pour la première ligne (y=0)
* le spot à allumer est celui de la dernière colonne (x=19). Le spot suivant
* est aux coordonnées x=18 et y=1… Puis celui en x=17 et y=2…
*
* Le mur est finalement affiché.
*
* @pre          Le mur de lumière est fonctionnel et connecté au PC
* @post         Chaque scène est correctement affichée sur le mur
*
* @param        Pas de paramètre dans ce programme !
*
* @return       0 est retournée au SE pour indiquer que tout c'est bien passé !
*
*/
int main()
{
	// Variables
	unsigned int	nMurDeLumiere[20][20] ;
	unsigned int	nTaille		(20) ;
	unsigned int	nCouleur	(0) ;

    // Q6 : Initialisation
    nCouleur = NOIR ;
	// Parcours du mur ligne par ligne puis par colonne sur une ligne
	for(unsigned int y (0) ; y < nTaille ; y++)
	{
		for(unsigned int x (0) ; x < nTaille ; x++)
		{
			nMurDeLumiere[x][y] = nCouleur ;
		}
	}


    // Q8 : X géant vert

    nCouleur = VERT ;
	for(unsigned int x (0) ; x < nTaille ; x++)
    {
		for(unsigned int y (0) ; y < nTaille ; y++)
        {
			if ((x==y) || ((x+y)==(nTaille-1)))
			{
                nMurDeLumiere[x][y] = nCouleur ;
            }
        }
    }

    // Q7 : Affichage
	// Parcours du mur ligne par ligne puis par colonne sur une ligne
	for(unsigned int y (0) ; y < 20 ; y++)
	{
		for(unsigned int x (0) ; x < 20 ; x++)
		{
			switch(nMurDeLumiere[x][y])
			{
				case NOIR	:	cout << ETEINT ;	break ;
				case BLANC	:	cout << "b " ;		break ;
				case LUNE	:	cout << "l " ;		break ;
				case ROUGE	:	cout << "R " ;		break ;
				case JAUNE	:	cout << "J " ;		break ;
				case VERT	:	cout << "V " ;		break ;
				case BLEU	:	cout << "B " ;		break ;
				default		:	cout << ALLUME ;	break ;
			}
		}
		cout << endl ;
	}

	cout << endl ;
	cout << endl ;
	return 0 ;
}
