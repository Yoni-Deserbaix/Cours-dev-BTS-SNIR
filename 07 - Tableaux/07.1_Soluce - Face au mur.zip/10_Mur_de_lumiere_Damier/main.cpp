//------------------------------------------------------------------------------
/** @file       main.cpp
* @brief        Gestion d'un mur de lumière
*
* @author       Ch. Cruzol
* @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
* @since        2018/12/01
* @version      1.0
* @date         2018/12/01
*
* Tim Hagine, régisseur de spectacle, doit préparer un mur de lumière constitué
* d’une matrice de 20 spots par 20 spots. Chaque spot peut générer une couleur
* indépendamment des autres, selon le schéma classique RGB.<br/>
* Plusieurs actes sont prévus et pour chacun d’entre eux, Tim doit réaliser une
* mise en scène lumineuse spéciale.
*
* L’acte suivant relate la discussion houleuse, lors d’une partie d’échecs, entre
* les deux sœurs Anfan, Hélène et Ludivine.<br/>
* Générez un damier sur le mur, en allumant en rouge un spot sur deux, en ligne
* et colonne.
*
* Fabrication   Mur_de_lumiere.pro
*
* @todo         Plein de nouveaux actes sont possibles ! À vous de les imaginer !
*
*/
//------------------------------------------------------------------------------

#include <iostream>		// cout, cin
#include <cstdlib>		// abs
#include <math.h>		// sin et cos

using namespace std ;

// Constantes symboliques pour les couleurs utilisées
/** @def	NOIR
*  @brief	Codage RGB du noir 0x000000
*/
#define	NOIR	(0x000000)


/** @def	BLANC
*  @brief	Codage RGB du blanc 0xFFFFFF
*/
#define	BLANC	(0xFFFFFF)


/** @def	LUNE
*  @brief	Codage RGB de la couleur jaune pâle de la lune 0xFFFF99
*/
#define	LUNE	(0xFFFF99)


/** @def	ROUGE
*  @brief	Codage RGB du rouge 0xFF0000
*/
#define	ROUGE	(0xFF0000)


/** @def	JAUNE
*  @brief	Codage RGB du jaune 0xFFFF00
*/
#define	JAUNE	(0xFFFF00)


/** @def	VERT
*  @brief	Codage RGB du vert 0x00FF00
*/
#define	VERT	(0x00FF00)


/** @def	BLEU
*  @brief	Codage RGB du bleu 0x0000FF
*/
#define	BLEU	(0x0000FF)



// Constantes symboliques pour l'affichage
/** @def	ETEINT
*  @brief	Symbole à afficher si le spot est éteint (de couleur NOIR)
*/
#define	ETEINT	(". ")


/** @def	ALLUME
*  @brief	Symbole à afficher si le spot est allumé (autre couleur que NOIR)
*/
#define	ALLUME	("O ")



/** Tim a prévu les actes dans l'ordre :
* - >>> Extinction du mur en initialisant la couleur de chaque spot à NOIR
* - >>> Transfert (affichage) du motif stocké dans le modèle (le tableau informatique) sur le mur réel
* - Tracé du X géant vert
* - >>> Conception du damier
* - Apparition du cadre de la toile vide…
* - … puis avec les carrés concentriques
* - Dessin du dièse des fausses notes
* - Apparition de la pleine lune.
*
* Le mur est au départ totalement éteint.
*
* Le damier est alors préparé. Il s'agit d'allumer en ROUGE un spot sur deux sur
* chaque ligne. Mais il ne faut pas que deux spots contigus sur une même colonne
* le soit aussi.<br/>
* La solution consiste à n'allumer que les spots des colonnes paires (x%2==0) lorsqu'ils
* se trouvent sur une ligne paire (y%2==0), et ceux des colonnes impaires (x%2==1)
* lorsqu'il s'agit des lignes impaires (yx%2==1).
*
* Le mur est finalement affiché.
*
* @pre          Le mur de lumière est fonctionnel et connecté au PC
* @post         Chaque scène est correctement affichée sur le mur
*
* @param        Pas de paramètre dans ce programme !
*
* @return       0 est retournée au SE pour indiquer que tout c'est bien passé !
*
*/
int main()
{
	// Variables
	unsigned int	nMurDeLumiere[20][20] ;
	unsigned int	nTaille		(20) ;
	unsigned int	nCouleur	(0) ;

    // Q6 : Initialisation
    nCouleur = NOIR ;
	// Parcours du mur ligne par ligne puis par colonne sur une ligne
	for(unsigned int y (0) ; y < nTaille ; y++)
	{
		for(unsigned int x (0) ; x < nTaille ; x++)
		{
			nMurDeLumiere[x][y] = nCouleur ;
		}
	}


    // Q9 : Damier
    nCouleur = ROUGE ;
	// Parcours de tout le mur ligne par ligne, puis par colonne dans une ligne
	for(unsigned int y (0) ; y < nTaille ; y++)
	{
		for(unsigned int x (0) ; x < nTaille ; x++)
		{
			if (   ((x%2==0) && (y%2==0))	// Lignes paires -> colonnes paires
				|| ((x%2==1) && (y%2==1)))	// Lignes impaires -> colonnes impaires
			{
				nMurDeLumiere[x][y] = nCouleur ;
			}
		}
	}


    // Q7 : Affichage
	// Parcours du mur ligne par ligne puis par colonne sur une ligne
	for(unsigned int y (0) ; y < 20 ; y++)
	{
		for(unsigned int x (0) ; x < 20 ; x++)
		{
			switch(nMurDeLumiere[x][y])
			{
				case NOIR	:	cout << ETEINT ;	break ;
				case BLANC	:	cout << "b " ;		break ;
				case LUNE	:	cout << "l " ;		break ;
				case ROUGE	:	cout << "R " ;		break ;
				case JAUNE	:	cout << "J " ;		break ;
				case VERT	:	cout << "V " ;		break ;
				case BLEU	:	cout << "B " ;		break ;
				default		:	cout << ALLUME ;	break ;
			}
		}
		cout << endl ;
	}

	cout << endl ;
	cout << endl ;
	return 0 ;
}
