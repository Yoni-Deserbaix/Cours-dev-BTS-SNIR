//------------------------------------------------------------------------------
/** @file        main.cpp
 * @brief        Prise en main des chaînes de caractères C++ sous forme de tableaux.
 *
 * @author       Ch. Cruzol
 * @author       STS SN-IR, Lycée Nicolas APPERT, ORVAULT (FRANCE)
 * @since        2018-12-18
 * @version      1.0
 * @date         2018-12-18
 *
 * Monsieur Técenfote doit résoudre de petits problèmes par rapport à des mots
 * ou de courtes phrases. En effet, Dick, dont la passion est les mots croisés
 * et autres jeux de lettres, souhaite…
 *    - … connaître la taille d’une chaîne de caractères.
 *    - … recopier une chaîne de caractères dans une autre.
 *    - … tester si une chaîne de caractère est intégralement dans une autre chaîne plus grande.
 *    - … rechercher si une chaîne de caractères est un palindrome.
 *    - … savoir combien il y a de voyelles dans une chaîne de caractères.
 *    - … créer des mots de passes automatiquement à partir d’une petite phrase.
 *
 * Fabrication   Chaines_De_Dick.pro
 *
 */
//------------------------------------------------------------------------------
#include <iostream>
using namespace std ;

/** @def	FIN_DE_CHAINE
*  @brief	Constante symbolique représentant le caractère de fin de chaîne '\0'
*/
#define     FIN_DE_CHAINE   ('\0')



/** Traitements courants de chaînes de caractères
 *
 * @return       Ce programme retourne 0 au système d'exploitation pôur indiquer
 *               que son fonctionnement s'est déroulé correctement.
 *
*/
int main()
{
    // Variables pour la Q1 et plus…
    char    sMaChaine[] =       "Bonjour" ;
    int     nTaille             (0) ;

    // Variables pour la Q2 et plus…
    char    sAutreChaine[50 + 1] ;
    char    sAutreCopie[50 + 1] ;
    int     i                   (0) ;

    // Variables pour la Q3 et plus…
    char    sMaSousChaine[] =   "jour" ;
    int     nDebut              (-1) ;
    int     j                   (0) ;

    // Variables pour la Q4
    char    sPalindrome[] =     "kayak" ;

    // Variables pour la Q5
    int     nNbreVoyelle        (0) ;

    // Variables pour la Q6
    char    sMotDePasse[100 + 1] ;





    /* Q1 : Recherche de la taille d'une chaîne de caractères
     * Ici on va choisir un TANT QUE car le contenu de la boucle, qui permet de
     * passer de caractère en caractère en incrémentant la variable nTaille, ne
     * doit pas forcément être réalisé ! C'est le cas pour les chaînes vides
     * définies par "".
     */
    while(sMaChaine[nTaille] != FIN_DE_CHAINE)
    {
        nTaille++ ;
    }

    cout << "La chaine \"" << sMaChaine << "\" possede " << nTaille << " caracteres !" << endl ;






    /* Q2 : Recopie d'une chaîne dans une autre.
     */
    /* Première solution : POUR car on connait la taille !
     * Attention : il faut aller copier le caractère de fin de chaîne qui se
     * trouve dans la case d'indice nTaille ! Donc il faut faire aller i
     * jusqu'à nTaille inclu (<=).
     */
    for(i = 0 ; i <= nTaille ; i++)
    {
        sAutreChaine[i] = sMaChaine[i] ;
    }
    cout << "La chaine recopiee par la premiere methode est \"" << sAutreChaine << "\"" << endl ;

    /* Seconde solution : REPETER JUSQU'A si on n'a pas la taille de la chaîne
     * initiale. Ici aussi, il faut pas oublier de copier le dernier caractère
     * de fin de la chaîne ! Dans tous les cas, la recopie doit être réalisée
     * au moins une fois, justement, pour cette satanée fin de chaîne, même si
     * la chaîne initiale est une chaîne vide !
     */
    i = -1 ;        // Astuce car il faut que l'incrémentation se fasse avant la copie…
    do
    {
        i++ ;
        sAutreCopie[i] = sMaChaine[i] ;
    }
    while(!(  sMaChaine[i] == FIN_DE_CHAINE  )) ;

    cout << "La chaine recopiee par la seconde methode est \"" << sAutreCopie << "\"" << endl ;






    /* Q3 : Présence d'une sous-chaîne de caractères dans une autre chaîne de
     * plus grande taille.
     */
    i = 0 ;
    do  // Cette boucle n'était pas demandée dans le TP
    {

        /* Recherche de la première occurence de la première lettre de la
         * sMaSousChaine dans la sMaChaine. On passe de car en car TQ le car
         * au rang i de la sMaChaine n'est pas identique à celui du rang 0
         * de sMaSousChaine ET qu'on n'est pas arrivé à la fin de la sMaChaine.
         */
        while( (sMaSousChaine[0] != sMaChaine[i]) && (sMaChaine[i] != FIN_DE_CHAINE) )
        {
            i++ ;
        }

        if (sMaSousChaine[0] == sMaChaine[i])
        {
            /* Si on a quitté le TQ parce que le car au rang 0 de sMaSousChaine a
             * été trouvé dans la sMaChaine…
             * On passe en revue tous les caractères de la sMaSousChaine et on
             * les compare un à un avec le car au même rang à partir de i de
             * la sMaChaine. On fait ça TQ on trouve une succession de caractères
             * identiques ET Qu'on n'est pas arrivé à la fin de la sMaSousChaine
             * NI à la fin de la sMaChaine.
             */
            j = 0 ;
            while( (sMaSousChaine[j] == sMaChaine[i+j])
                   && (sMaSousChaine[j] != FIN_DE_CHAINE)
                   && (sMaChaine[i+j] != FIN_DE_CHAINE) )
            {
                j++ ;
            }

            if (sMaSousChaine[j] == FIN_DE_CHAINE)
            {
                /* Si on a quitté le TQ parce que tous les car de sMaSousChaine
                 * ont été trouvés dans la sMaChaine, c.a.d. qu'on a atteint la
                 * fin de sMaSousChaine, on sait que le début de la sMaSousChaine
                 * est au rang i de la sMaChaine.
                 */
                nDebut = i ;
            }
            else
            {
                // Cette partie n'était pas demandée dans le TP !
                if (sMaSousChaine[j] != sMaChaine[i+j])
                {
                    /* On a quitté le TQ parce qu'un des car de sMaSousChaine
                     * pas identique à celui du même rang à partir de i dans
                     * sMaChaine. Dans ce cas, on indique que la sMaSousChaine
                     * n'a pas été trouvée dans cette partie de la sMaChaine
                     * (début n'est pas valide) et on passe à la recherche de
                     * l'occurence suivante en passant au car d'après dans
                     * la sMaChaine en incrémentant i.
                     */
                    nDebut = -1 ;
                    i++ ;
                }
            }
        }

        /* On réitère la recherche d'une autre occurence du premier car de
         * sMaSousChaine JQ ce que la sMaSousChaine ait été finalement trouvée
         * OU qu'on est arrivé à la fin de la sMaChaine
         */
    }
    while(!(  (nDebut != -1) || (sMaChaine[i] == FIN_DE_CHAINE)  )) ;

    if (nDebut != -1)
    {
        /* sMaSousChaine a été trouvée dans sMaChaine et on connait son
         * rang, on peut alors l'afficher !
         */
        cout << "\"" << sMaSousChaine << "\" est contenue dans \"" << sMaChaine<< "\""  ;
        cout << " a la place " << nDebut << endl ;
    }
    else
    {
        /* sMaSousChaine n'a pas été trouvée dans sMaChaine
         */
        cout << "\"" << sMaSousChaine << "\" n'est pas contenue dans \"" << sMaChaine << "\"" << endl ;
    }



    /* Q4 : Validation de palindrome
     */
    /* Calcul du nombre de caractères contenus dans la chaîne sPalindrome comme
     * à la question Q1 !
     */
    nTaille = 0 ;
    while(sPalindrome[nTaille] != FIN_DE_CHAINE)
    {
        nTaille++ ;
    }

    /* On compare chaque car de sPalindrome, un à un, à partir de chaque
     * extrémité ([i] pour les premiers, ceux du début de la chaîne et
     * [nTaille-1-i] pour les derniers, ceux de la fin de sPalindrome).
     * On a en effet divisé la chaîne en deux parties répartie autour du
     * milieu, en nombre de caractères !
     * Si les deux caractères sont identiques, on passe au suivant pour le début
     * de la chaîne, et au précédent pour la fin.
     * On réitère ce traitement TQ les car comparés sont identiques ET qu'on
     * n'a pas parcouru la moitié de la chaîne en entier.
     */
    i = 0 ;
    while( (i<=(nTaille/2)) && (sPalindrome[i] == sPalindrome[nTaille - 1 - i]))
    {
        i++ ;
    }

    if (sPalindrome[i] != sPalindrome[nTaille - 1 - i])
    {
        /* Si on a quitté le TQ parce que deux caractères n'étaient pas les mêmes
         * C'est donc que la chaîne n'est pas un palindrome !
         */
        cout << "\"" << sPalindrome << "\" n'est pas un palindrome !" << endl ;
    }
    else
    {
        /* Là, on est maintenant sûr que la chaîne est un palindrome !
         */
        cout << "\"" << sPalindrome << "\" est un palindrome !" << endl ;
    }



    /* Q5 : Compter le nombre de voyelles dans une chaîne de caractères.
     */
    i = 0 ;
    /* On passe en revue chaque caractère de sMaChaine, un par un, au moyen d'un
     * TQ, pour permettre de traiter correctement une chaîne vide ("")…
     * Si le caractère est une voyelle, on incrémente le compteur nNbreVoyelle !
     * À la fin du TQ, on connait et affiche le nNbreVoyelle.
     */
    while(sMaChaine[i] != FIN_DE_CHAINE)
    {
        switch (sMaChaine[i])
        {
            case 'a' :      // Le même traitement est à faire pour chaque
            case 'A' :      // voyelle : incrémenter nNbreVoyelle.
            case 'e' :      // On évite ici de recopier cette incrémentation
            case 'E' :      // dans chaque cas, en le la plaçant que dans le
            case 'i' :      // dernier cas et en supprimant tous les break
            case 'I' :      // entre les cas qui doivent avoir ce traitement !
            case 'o' :
            case 'O' :      // Notez que les accentuées ne sont pas prises en
            case 'u' :      // compte car Qt les trâite comme des car codés
            case 'U' :      // en UNICODE, c.a.d. sur deux octets et non un seul
            case 'y' :
            case 'Y' :  nNbreVoyelle++ ;
                        break ;

            default :       // Pour tous les autres caractères, on ne fait rien !
                        break ;
        }
        i++ ;
    }
    cout << "La chaine \"" << sMaChaine << "\" possede " << nNbreVoyelle << " voyelles !" << endl ;




    /* Q6 : Générateur de mot de passe !
     */
    i = 0 ;     // Parcours de sMaChaine
    j = 0 ;     // Parcours de sMotDePasse
    /* On passe en revue chaque caractère de sMaChaine, un par un, au moyen d'un
     * TQ, pour permettre de traiter correctement une chaîne vide ("")…
     * Si le caractère est une voyelle, une espace ou une ponctuation, on ne doit
     * rien en faire… Pour toutes les autres valeurs des caractères, on recopie
     * ce caractère dans sMotDePasse à la position courante j, et on se
     * déplace sur la prochaine case vide de sMotDePasse (j++).
     * À la fin du TQ, on ajoute le caractère de FIN_DE_CHAINE au sMotDePasse
     * pour avoir une vraie belle chaîne de caractères. Reste plus qu'à
     * l'afficher !
     */
    while(sMaChaine[i] != FIN_DE_CHAINE)
    {
        switch (sMaChaine[i])
        {
            case 'a' :      // Même principe qu'à la Q5 !
            case 'A' :      // Sauf qu'ici, on ne fait rien avec les voyelles
            case 'e' :      // ni les espaces et les ponctuations…
            case 'E' :
            case 'i' :
            case 'I' :
            case 'o' :
            case 'O' :
            case 'u' :
            case 'U' :
            case 'y' :
            case 'Y' :
            case ' ' :      // Espace
            case '\'' :     // Apostrophe
            case '\"' :     // Guillemets
            case '.' :      // Ponctuations…
            case ',' :
            case ';' :
            case ':' :
            case '!' :
            case '?' :  break ;

            default :   sMotDePasse[j] = sMaChaine[i] ;
                        j++ ;
                        break ;
        }
        i++ ;
    }
    sMotDePasse[j] = FIN_DE_CHAINE ;
    cout << "La chaine \"" << sMaChaine << "\" donne le mot de passe \"" << sMotDePasse << "\"" << endl ;



	return 0 ;
}
