#include <iostream>
#include <math.h>
using namespace std ;

int main()
{
    float   A       (0.0) ;
    float   B       (0.0) ;
    float   C       (0.0) ;
    float   Delta   (0.0) ;
    float   X1      (0.0) ;
    float   X2      (0.0) ;

    cout << "Donnez les coefficients de votre équation A*x*x + B*x + C : " << endl ;
    cout << "A = ..." << endl ;
    cin >> A ;
    cout << "B = ..." << endl ;
    cin >> B ;
    cout << "C = ..." << endl ;
    cin >> C ;

    Delta = B*B - 4*A*C ;
    cout << "Delta = " << Delta << " : " ;
    if (Delta == 0.0)
    {
        X1 = -B/(2.0*A) ;
        cout << "Une seule solution, X=" << X1 << endl ;
    }
    else
    {
        if (Delta < 0.0)
        {
            cout << "Pas de solution reelle" << endl ;
        }
        else
        {
            X1 = (-B+sqrt(Delta))/(2.0*A) ;
            X2 = (-B-sqrt(Delta))/(2.0*A) ;
            cout << "Deux solutions, X1=" << X1 << " et X2=" << X2 << endl ;

        }

    }

    return 0 ;
}
