#include <iostream>
using namespace std ;

int main()
{
    float   PremiereValeur   (0) ;
    float   PremierDiviseur  (0) ;
    float   SecondeValeur    (0) ;
    float   SecondDiviseur   (0) ;

    cout << "Donnez votre première valeur : " << endl ;
    cin >> PremiereValeur ;

    do
    {
        cout << "Donnez le diviseur de " << PremiereValeur << " : " << endl ;
        cin >> PremierDiviseur ;
        if(PremierDiviseur == 0)
        {
            cout << "Denominateur nul interdit" << endl ;
        }
    }
    while (!(PremierDiviseur!=0)) ;

    cout << "Donnez votre seconde valeur : " << endl ;
    cin >> SecondeValeur ;

    do
    {
        cout << "Donnez le diviseur de " << SecondeValeur << " : " << endl ;
        cin >> SecondDiviseur ;
        if(SecondDiviseur == 0)
        {
            cout << "Denominateur nul interdit" << endl ;
        }
    }
    while (!(SecondDiviseur!=0)) ;

    cout << PremiereValeur << "/" << PremierDiviseur << " = " ;
    cout << PremiereValeur/PremierDiviseur << endl ;

    cout << SecondeValeur << "/" << SecondDiviseur << " = " ;
    cout << SecondeValeur/SecondDiviseur << endl ;

    return 0 ;
}
