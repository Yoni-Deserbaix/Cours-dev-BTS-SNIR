#include <iostream>
using namespace std ;

int main()
{
    float   Temperature         (0.0) ;
    float   Somme               (0.0) ;
    float   NbreTemperature     (0.0) ;
    char    AutreTemperature    ('n') ;

    do
    {
        cout << "Donnez la temperature : " ;
        cin >> Temperature ;
        Somme = Somme + Temperature ;
        NbreTemperature++ ;

        cout << "Voulez-vous entrer une autre temperature ? (o, n) " ;
        cin >> AutreTemperature ;
    }
    while (!(AutreTemperature == 'n')) ;

    cout << "la moyenne des temperatures saisies est " << Somme/NbreTemperature << endl ;

    return 0 ;
}
