#include <iostream>
using namespace std ;

int main()
{
    int n (0) ;
    int s (0) ;
    int u (0) ;

    cout << "Donnez votre valeur maximale : " << endl ;
    cin >> n ;

/*
    // Algo mystere original :
    s = 1 ;
    u = 1 ;

    for(register unsigned int i = 1 ; i <= n-1 ; i++)
    {
        u = u + 2 ;
        s = s + u ;
    }
*/

    // Version simplifiee !
    s = n*n ;
    cout << "Le resultat de l'algo mystrere sur " << n << " est " << s << endl ;


    return 0 ;
}
