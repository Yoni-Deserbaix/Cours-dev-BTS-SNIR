#include <iostream>
using namespace std ;

int main()
{
    int a (0) ;
    int b (0) ;
    int x (0) ;
    int y (0) ;

    a = 4 ;
    b = 7 ;

    cout << "A vous de jouer" << endl ;
    cin >> x ;
    cin >> y ;
    if((x==a) && (y==b))
    {
        cout << "BOOM ! Coule !" << endl ;
    }
    else
    {
        if(     ((x==a-1) || (x==a) || (x==a+1))
           &&   ((y==b-1) || (y==b) || (y==b+1) ))
        {
            cout << "SPLASH ! Eclabousse !" << endl;
        }
        else
        {
            cout << "PLOUF ! Dans l'eau !" << endl ;
        }
    }

    return 0 ;
}
