#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main()
{

    int     Min         (1) ;
    int     Max         (50) ;
    int     NbreMystere (0) ;
    int     NbrePropose (0) ;
    int     NbreTour    (0) ;
    bool    NbreTrouve  (false) ;

    srand(time(nullptr)) ;
    NbreMystere = rand() % (Max-Min+1) + Min ;
    NbreTour    = 0 ;
    NbreTrouve  = false ;

    do
    {

        cout << "Propose-moi un nombre compris entre " << Min << " et " << Max << " : " ;
        cin >> NbrePropose ;

        NbreTour++ ;

        if( NbrePropose == NbreMystere)
        {
            NbreTrouve = true ;
        }
        else
        {
            cout << NbrePropose ;
            if( NbrePropose < NbreMystere )
            {
                cout << " est plus petit que mon nombre mystere. Essaye encore !" << endl ;
            }
                    else
            {
                cout << " est plus grand que mon nombre mystere. Essaye encore !" << endl ;
            }
        }

    }
    while(!(NbreTrouve == true)) ;

    cout << "Bravo, tu as trouve mon nombre mystere, qui etait le " ;
    cout << NbreMystere << ", en (a peine) " << NbreTour << " coups !" << endl ;

    return 0;
}

