#include <iostream>
using namespace std ;

int main()
{
	int NbreNomJour     (0) ;
	int NbreDate        (0) ;
	int	FinDuMois		(31) ;
	int NbreNomMois     (1) ;
	int	Annee			(2020) ;

	while(true)
	{
		// Traitement de changement de jour… mois… année…
		NbreNomJour++ ;
		if(NbreNomJour >= 8)
		{
			NbreNomJour = 1 ;
		}
		NbreDate++ ;
		if(NbreDate > FinDuMois)
		{
			NbreDate = 1 ;
			NbreNomMois++ ;
			if(NbreNomMois > 12)
			{
				NbreNomMois = 1 ;
				Annee++ ;
				system("PAUSE") ;
			}
			switch (NbreNomMois)
			{
				case 1 :
				case 3 :
				case 5 :
				case 7 :
				case 8 :
				case 10 :
				case 12 :	FinDuMois = 31 ;  break ;

				case 4 :
				case 6 :
				case 9 :
				case 11 :	FinDuMois = 30 ;  break ;

				case 2 :	if	(		(Annee % 400 == 0)
									||	(	(Annee % 4 == 0)
									   &&	(Annee % 100 != 0)
										)
								)
							{
								FinDuMois = 29 ;
							}
							else
							{
								FinDuMois = 28 ;
							}
							break ;

				default :       break ;
			}

		}


		// Affichage
		switch (NbreNomJour)
		{
			case 1 :    cout << "Lundi\t\t" ;		break ;
			case 2 :    cout << "Mardi\t\t" ;		break ;
			case 3 :    cout << "Mercredi\t" ;		break ;
			case 4 :    cout << "Jeudi\t\t" ;		break ;
			case 5 :    cout << "Vendredi\t" ;		break ;
			case 6 :    cout << "Samedi\t\t" ;		break ;
			case 7 :    cout << "Dimanche\t" ;		break ;
			default :	cout << "JOUR INCONNU\t" ;	break ;
		}
		cout << NbreDate << "\t" ;
		switch (NbreNomMois)
		{
			case 1 :    cout << "Janvier\t\t" ;		break ;
			case 2 :    cout << "Fevrier\t\t" ;		break ;
			case 3 :    cout << "Mars\t\t" ;		break ;
			case 4 :    cout << "Avril\t\t" ;		break ;
			case 5 :    cout << "Mai\t\t" ;			break ;
			case 6 :    cout << "Juin\t\t" ;		break ;
			case 7 :    cout << "Juillet\t\t" ;		break ;
			case 8 :    cout << "Aout\t\t" ;		break ;
			case 9 :    cout << "Septembre\t" ;		break ;
			case 10 :   cout << "Octobre\t\t" ;		break ;
			case 11 :   cout << "Novembre\t" ;		break ;
			case 12 :   cout << "Decembre\t" ;		break ;
			default :	cout << "MOIS INCONNU\t" ;	break ;
		}
		cout << Annee << endl ;


	}

	return 0 ;
}
