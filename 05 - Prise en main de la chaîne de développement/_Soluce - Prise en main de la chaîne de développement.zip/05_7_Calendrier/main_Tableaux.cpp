#include <iostream>
using namespace std ;

typedef	struct
				{
					string	sNom ;
					int		FinDuMois ;
				}	TMois ;
int main()
{
	int		NbreNomJour		(0) ;
	int		NbreDate		(0) ;
	int		NbreNomMois		(1) ;
	int		Annee			(2020) ; // Année bisextile !!!
	bool	bBisextile		(false) ;

	string	sTabJours[] = {	"INCONNU\t",
							"Lundi\t\t",
							"Mardi\t\t",
							"Mercredi\t",
							"Jeudi\t\t",
							"Vendredi\t",
							"Samedi\t\t",
							"Dimanche\t"
						  } ;
	TMois	sTabMois[] = {	{"INCONNU\t",	0} ,
							{"Janvier\t\t",	31} ,
							{"Fevrier\t\t",	28} ,
							{"Mars\t\t",	31} ,
							{"Avril\t\t",	30} ,
							{"Mai\t\t",		31} ,
							{"Juin\t\t",	30} ,
							{"Juillet\t\t",	31} ,
							{"Aout\t\t",	31} ,
							{"Septembre\t",	30} ,
							{"Octobre\t\t",	31} ,
							{"Novembre\t",	30} ,
							{"Decembre\t",	31}
						 } ;

	bBisextile =	(Annee % 400 == 0)
				 ||	( (Annee % 4 == 0) && (Annee % 100 != 0) ) ;

	while(true)
	{
		// Traitement de changement de jour… mois… année…
		NbreNomJour++ ;
		if(NbreNomJour > 7)
		{
			NbreNomJour = 1 ;
		}
		NbreDate++ ;
		if(NbreDate > sTabMois[NbreNomMois].FinDuMois + ((NbreNomMois == 2) && bBisextile ? 1 : 0))
		{
			NbreDate = 1 ;
			NbreNomMois++ ;
			if(NbreNomMois > 12)
			{
				NbreNomMois = 1 ;
				Annee++ ;
				bBisextile =	(Annee % 400 == 0)
							 ||	( (Annee % 4 == 0) && (Annee % 100 != 0) ) ;
				system("PAUSE") ;
			}
		}

		// Affichage
		cout << sTabJours[NbreNomJour] ;
		cout << NbreDate << "\t" ;
		cout << sTabMois[NbreNomMois].sNom ;
		cout << Annee << endl ;
	}

    return 0 ;
}
