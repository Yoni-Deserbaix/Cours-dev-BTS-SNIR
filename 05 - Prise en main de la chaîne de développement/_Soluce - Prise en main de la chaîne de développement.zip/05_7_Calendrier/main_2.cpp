#include <iostream>
using namespace std ;

int main()
{
    int Annee           (0) ;
    int NbreAnnee       (0) ;
    int NbreJourAnnee   (0) ;
    int NbreNomJour     (1) ;
    int NbreDate        (1) ;
    int NbreNomMois     (1) ;

    cout << "Saisissez l'annee :" ;
    cin >> Annee ;
    cout << "Saisissez le nombre d'annee :" ;
    cin >> NbreAnnee ;

	// Calcul du premier jour de l'année
	/*
	Source : https://fr.wikibooks.org/wiki/Curiosités_mathématiques/Trouver_le_jour_de_la_semaine_avec_une_date_donnée, Méthode 2
	Pour une date de la forme jour/mois/année où « jour » prend une valeur de 01 à 31,
	 « mois » de 01 à 12 et « année » de 1583 à 9999, utiliser la formule :

	c = (14 - mois)/12
	En fait, c = 1 pour janvier et février, c = 0 pour les autres mois.
	a = année - c
	m = mois + 12*c - 2
	j = ( jour + a + a/4 - a/100 + a/400 + (31*m)/12 ) mod 7

	La réponse obtenue pour j correspond alors à un jour de la semaine suivant :
	0 = dimanche, 1 = lundi, 2 = mardi, etc.

	Dans toutes les divisions « / », on ne garde que la partie entière du résultat. Par exemple, 35/4= 8.
	(en Python c'est l'opérateur // qui fait ça !)
	(en CPP c'est directement le / !)
	*/
    int c (0) ;
    int a (0) ;
    int m (0) ;
    int j (0) ;
    c = (14 - 1)/12 ;													// Janvier
	a = Annee - c ;
    m = 1 + 12*c - 2; 													// Janvier
    j = ( 1 + a + a/4 - a/100 + a/400 + (31*m)/12 ) % 7	; 		// 1er du mois
    if(j==0)						// 0 = Dimanche, mais pour moi, Dimanche = 7 !
	{
		j= 7 ;
	}
	NbreNomJour = j ;
	
	
    for(int i = 0 ; i < NbreAnnee ; i++)
    {
        NbreJourAnnee = 365 ;
        /* Une année bisextile est une année divisible par 400
          ou bien divisible par 4 mais pas par 100 en même temps !
        */
        if ((Annee%400==0) || ((Annee%4==0) && (Annee%100!=0)))
        {
            // Et un jour de plus sur une année bisextile
            NbreJourAnnee++ ;
        }

        for(int i = 0 ; i < NbreJourAnnee ; i++)
        {
            // Traitement d'une année complète
            switch (NbreNomJour)
            {
                case 1 :    cout << "Lundi\t\t" ;     break ;
                case 2 :    cout << "Mardi\t\t" ;     break ;
                case 3 :    cout << "Mercredi\t" ;  break ;
                case 4 :    cout << "Jeudi\t\t" ;     break ;
                case 5 :    cout << "Vendredi\t" ;  break ;
                case 6 :    cout << "Samedi\t\t" ;    break ;
                case 7 :    cout << "Dimanche\t" ;  break ;
                default :       break ;
            }
            cout << NbreDate << "\t" ;
            switch (NbreNomMois)
            {
                case 1 :    cout << "Janvier\t\t" ;     break ;
                case 2 :    cout << "Fevrier\t\t" ;     break ;
                case 3 :    cout << "Mars\t\t" ;  break ;
                case 4 :    cout << "Avril\t\t" ;     break ;
                case 5 :    cout << "Mai\t\t" ;  break ;
                case 6 :    cout << "Juin\t\t" ;    break ;
                case 7 :    cout << "Juillet\t\t" ;  break ;
                case 8 :    cout << "Aout\t\t" ;  break ;
                case 9 :    cout << "Septembre\t" ;  break ;
                case 10 :   cout << "Octobre\t\t" ;  break ;
                case 11 :   cout << "Novembre\t" ;  break ;
                case 12 :   cout << "Decembre\t" ;  break ;
                default :       break ;
            }
            cout << Annee << endl ;

            NbreNomJour++ ;
            if (NbreNomJour==8)
            {
                NbreNomJour = 1 ;
            }

            NbreDate++ ;
            if (
                    // Longs mois de 31 jours
                    ((NbreDate==32) && (    (NbreNomMois==1)
                                        ||  (NbreNomMois==3)
                                        ||  (NbreNomMois==5)
                                        ||  (NbreNomMois==7)
                                        ||  (NbreNomMois==8)
                                        ||  (NbreNomMois==10)
                                        ||  (NbreNomMois==12))
                     )
                ||
                    // Mois courts de 30 jours
                    ((NbreDate==31) && (    (NbreNomMois==4)
                                        ||  (NbreNomMois==6)
                                        ||  (NbreNomMois==9)
                                        ||  (NbreNomMois==11))
                                     )
                ||
                    // Février classique
                    ((NbreDate==29) && (NbreNomMois==2) && (NbreJourAnnee == 365))
                ||
                    // Février sur annee bisextile
                    ((NbreDate==30) && (NbreNomMois==2) && (NbreJourAnnee == 366))
                )
            {
                NbreDate = 1 ;
                cout << endl ;

                NbreNomMois++ ;
                if (NbreNomMois==13)
                {
                    NbreNomMois = 1 ;
                }
            }
        }
        cout << "***********************************" << endl<< endl ;
        Annee++ ;
    }



    return 0 ;
}
