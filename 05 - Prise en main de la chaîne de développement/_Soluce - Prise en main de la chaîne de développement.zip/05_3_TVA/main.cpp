#include <iostream>
using namespace std ;

int main()
{
    float   PrixHorsTaxe    (0.0) ;
    float   PrixTTC         (0.0) ;
    float   TauxTVA         (0.0) ;

    cout << "Quel est le prix hors taxes ?" << endl ;
    cin >> PrixHorsTaxe ;

    while(true)
    {

    do {
        cout << "Quel est le taux de TVA ?" << endl ;
        cin >> TauxTVA ;
    }
	while (!(    (TauxTVA == static_cast<float>(20.0))
			  || (TauxTVA == static_cast<float>(10.0))
			  || (TauxTVA == static_cast<float>(5.5))
			  || (TauxTVA == static_cast<float>(2.1))
			)) ;

    PrixTTC = PrixHorsTaxe + PrixHorsTaxe * TauxTVA / 100.0 ;
    cout << "Le prix TTC est " << PrixTTC << endl ;

    }

    return 0 ;
}
